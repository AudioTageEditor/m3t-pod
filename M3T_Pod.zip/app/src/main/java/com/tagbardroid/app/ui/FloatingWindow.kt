// File: app/src/main/java/com/tagbardroid/app/ui/FloatingWindow.kt
package com.tagbardroid.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CropSquare
import androidx.compose.material.icons.rounded.FilterNone
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt

private val MIN_WINDOW_WIDTH = 260.dp
private val MIN_WINDOW_HEIGHT = 270.dp
private val TITLE_HEIGHT = 38.dp
/** Lebar bingkai samping dan bawah; sekaligus daerah tarik tepi. */
private val FRAME = 7.dp
private val EDGE_TOUCH = 12.dp
private val TOP_EDGE_TOUCH = 7.dp
private val CORNER_TOUCH = 28.dp
private val TOP_CORNER_TOUCH = 14.dp
private val CloseRed = Color(0xFFC42B1C)
private val CloseRedPressed = Color(0xFF93200F)

/**
 * Satu jendela ala desktop: bilah judul yang bisa digeser (ketuk dua kali untuk maximize),
 * tombol Minimize, Maximize/Restore, dan Close, serta tepi dan sudut yang bisa ditarik.
 * [areaWidth] dan [areaHeight] adalah ukuran desktop dalam piksel; jendela tidak bisa keluar darinya.
 */
@Composable
internal fun FloatingWindow(
    desktop: DesktopState,
    id: PanelId,
    areaWidth: Float,
    areaHeight: Float,
    content: @Composable () -> Unit,
) {
    val window = desktop.window(id)
    if (!window.floating || window.minimized) return

    val density = LocalDensity.current
    val minWidth = with(density) { MIN_WINDOW_WIDTH.toPx() }
    val minHeight = with(density) { MIN_WINDOW_HEIGHT.toPx() }
    val initial = WindowGeometry.initial(id.ordinal > 0, areaWidth, areaHeight)

    // Selalu dibaca ulang dari status terbaru, juga di tengah gestur.
    fun current() = WindowGeometry.fit(window.rectOr(initial), areaWidth, areaHeight, minWidth, minHeight)

    val maximized = window.maximized
    val widthPx = if (maximized) {
        areaWidth
    } else {
        (if (window.width.isNaN()) initial.width else window.width).coerceIn(minOf(minWidth, areaWidth), areaWidth)
    }
    val heightPx = if (maximized) {
        areaHeight
    } else {
        (if (window.height.isNaN()) initial.height else window.height)
            .coerceIn(minOf(minHeight, areaHeight), areaHeight)
    }
    val active = desktop.active == id
    val shape = RoundedCornerShape(if (maximized) 0.dp else 8.dp)

    val move by rememberUpdatedState<(Float, Float) -> Unit> { dx, dy ->
        if (!window.maximized) window.set(WindowGeometry.move(current(), dx, dy, areaWidth, areaHeight))
    }
    val resize by rememberUpdatedState<(ResizeEdges, Float, Float) -> Unit> { edges, dx, dy ->
        window.set(
            WindowGeometry.resize(current(), edges, dx, dy, areaWidth, areaHeight, minWidth, minHeight),
        )
    }

    Box(
        modifier = Modifier
            .zIndex(desktop.order.indexOf(id).toFloat())
            .offset {
                if (window.maximized) {
                    IntOffset.Zero
                } else {
                    val rect = current()
                    IntOffset(rect.x.roundToInt(), rect.y.roundToInt())
                }
            }
            .size(with(density) { widthPx.toDp() }, with(density) { heightPx.toDp() })
            .shadow(if (active) 16.dp else 6.dp, shape)
            .clip(shape)
            .background(Classic.chrome)
            .border(1.dp, if (active) Classic.accent else Classic.border, shape)
            // Sentuhan di mana pun pada jendela membawanya ke depan, tanpa mengambil sentuhannya.
            // Modifier ini juga mencegah sentuhan menembus ke panel di belakang jendela.
            .pointerInput(id) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    desktop.bringToFront(id)
                }
            },
    ) {
        Column(Modifier.fillMaxWidth().fillMaxHeight()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(TITLE_HEIGHT)
                    .background(if (active) Classic.blueGloss else Classic.bar),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .pointerInput(id) { detectTapGestures(onDoubleTap = { desktop.toggleMaximize(id) }) }
                        .pointerInput(id) {
                            detectDragGestures { change, amount ->
                                change.consume()
                                move(amount.x, amount.y)
                            }
                        }
                        .padding(horizontal = 10.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    Text(
                        id.title,
                        style = Classic.heading.copy(color = if (active) Classic.onAccent else Classic.text),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                CaptionButton(Icons.Rounded.Remove, "Minimize") { desktop.minimize(id) }
                CaptionButton(
                    if (maximized) Icons.Rounded.FilterNone else Icons.Rounded.CropSquare,
                    if (maximized) "Restore" else "Maximize",
                ) { desktop.toggleMaximize(id) }
                CaptionButton(Icons.Rounded.Close, "Close", close = true) { desktop.close(id) }
                Box(Modifier.width(4.dp))
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(
                        start = if (maximized) 0.dp else FRAME,
                        end = if (maximized) 0.dp else FRAME,
                        bottom = if (maximized) 0.dp else FRAME,
                    )
                    .clip(RoundedCornerShape(2.dp))
                    .background(Classic.background)
                    .padding(4.dp),
            ) {
                content()
            }
        }

        if (!maximized) {
            val onResize: (ResizeEdges, Float, Float) -> Unit = { edges, dx, dy -> resize(edges, dx, dy) }
            // Tepi.
            // Tepi samping mulai di bawah bilah judul agar tidak menutupi tombol jendela.
            val side = Modifier.padding(top = TITLE_HEIGHT).width(EDGE_TOUCH).fillMaxHeight()
            ResizeArea(ResizeEdges(left = true), Alignment.CenterStart, side, onResize)
            ResizeArea(ResizeEdges(right = true), Alignment.CenterEnd, side, onResize)
            ResizeArea(ResizeEdges(top = true), Alignment.TopCenter, Modifier.height(TOP_EDGE_TOUCH).fillMaxWidth(), onResize)
            ResizeArea(ResizeEdges(bottom = true), Alignment.BottomCenter, Modifier.height(EDGE_TOUCH).fillMaxWidth(), onResize)
            // Sudut, diletakkan terakhir agar menang atas tepi.
            ResizeArea(ResizeEdges(left = true, top = true), Alignment.TopStart, Modifier.size(TOP_CORNER_TOUCH), onResize)
            ResizeArea(ResizeEdges(right = true, top = true), Alignment.TopEnd, Modifier.size(TOP_CORNER_TOUCH), onResize)
            ResizeArea(ResizeEdges(left = true, bottom = true), Alignment.BottomStart, Modifier.size(CORNER_TOUCH), onResize)
            ResizeArea(
                ResizeEdges(right = true, bottom = true),
                Alignment.BottomEnd,
                Modifier.size(CORNER_TOUCH).gripLines(Classic.dim, 6.dp),
                onResize,
            )
        }
    }
}

@Composable
private fun BoxScope.ResizeArea(
    edges: ResizeEdges,
    alignment: Alignment,
    size: Modifier,
    onResize: (ResizeEdges, Float, Float) -> Unit,
) {
    val latest by rememberUpdatedState(onResize)
    Box(
        Modifier
            .align(alignment)
            .then(size)
            .pointerInput(edges) {
                detectDragGestures { change, amount ->
                    change.consume()
                    latest(edges, amount.x, amount.y)
                }
            },
    )
}

/** Tiga garis diagonal penanda sudut yang bisa ditarik. */
private fun Modifier.gripLines(color: Color, padding: Dp): Modifier = drawBehind {
    val stroke = 1.5.dp.toPx()
    val pad = padding.toPx()
    val gap = 4.dp.toPx()
    for (i in 1..3) {
        val d = pad + gap * i
        drawLine(
            color = color,
            start = Offset(size.width - pad, size.height - d),
            end = Offset(size.width - d, size.height - pad),
            strokeWidth = stroke,
            cap = StrokeCap.Round,
        )
    }
}

/** Tombol pada bilah judul; tombol Close berwarna merah. */
@Composable
private fun CaptionButton(icon: ImageVector, description: String, close: Boolean = false, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val shape = RoundedCornerShape(4.dp)
    val surface = when {
        close -> Modifier.background(if (pressed) CloseRedPressed else CloseRed)
        pressed -> Modifier.background(Classic.metalPressed)
        else -> Modifier.background(Classic.metal)
    }
    Box(
        modifier = Modifier
            .padding(start = 3.dp)
            .size(width = 36.dp, height = 30.dp)
            .clip(shape)
            .then(surface)
            .border(1.dp, Classic.border, shape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = description,
            tint = if (close) Color.White else Classic.text,
            modifier = Modifier.size(18.dp),
        )
    }
}
