// File: app/src/main/java/com/tagbardroid/app/player/PlayerController.kt
package com.tagbardroid.app.player

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.tagbardroid.app.library.LibraryTrack

/**
 * Pemutar berbasis Media3 ExoPlayer. Hidup di ViewModel, sehingga suara tetap berjalan
 * walau overlay pemutar dikecilkan atau disembunyikan; berhenti hanya bila di-pause.
 *
 * Mendukung audio resolusi tinggi (FLAC/WAV hingga 96 kHz / 24-bit): keluaran dibuat float 32-bit,
 * jadi sampel 24-bit tidak dipotong ke 16-bit sebelum sampai ke AudioTrack, dan sample rate asli
 * file diteruskan ke sistem audio (resampling, bila perlu, dilakukan oleh sistem, bukan aplikasi).
 */
@OptIn(UnstableApi::class)
class PlayerController(private val context: Context) {

    var queue by mutableStateOf<List<LibraryTrack>>(emptyList())
        private set
    var index by mutableIntStateOf(-1)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var shuffle by mutableStateOf(false)
        private set
    var albumMode by mutableStateOf(false)
        private set
    var durationMs by mutableIntStateOf(0)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    val current: LibraryTrack? get() = queue.getOrNull(index)

    private var player: ExoPlayer? = null
    private var prepared = false
    private var original: List<LibraryTrack> = emptyList()

    /** Mulai memutar [startAt] dari daftar [tracks]. */
    fun start(tracks: List<LibraryTrack>, startAt: LibraryTrack, album: Boolean = false) {
        if (tracks.isEmpty()) return
        original = tracks
        albumMode = album
        if (shuffle && !album) {
            queue = listOf(startAt) + tracks.filter { it.documentId != startAt.documentId }.shuffled()
            index = 0
        } else {
            queue = tracks
            index = tracks.indexOfFirst { it.documentId == startAt.documentId }.coerceAtLeast(0)
        }
        load(index)
    }

    fun playIndex(i: Int) {
        if (i !in queue.indices || i == index) return
        load(i)
    }

    fun applyShuffle(on: Boolean) {
        shuffle = on
        albumMode = false
        val cur = current ?: return
        if (on) {
            queue = listOf(cur) + queue.filter { it.documentId != cur.documentId }.shuffled()
            index = 0
        } else {
            val base = original.ifEmpty { queue }
            queue = base
            index = base.indexOfFirst { it.documentId == cur.documentId }.coerceAtLeast(0)
        }
    }

    /** Mengganti antrean dengan isi album lagu yang sedang diputar, tanpa memutus suara. */
    fun playAlbum(albumTracks: List<LibraryTrack>) {
        val cur = current ?: return
        if (albumTracks.isEmpty()) return
        shuffle = false
        albumMode = true
        original = albumTracks
        val position = albumTracks.indexOfFirst { it.documentId == cur.documentId }
        if (position >= 0) {
            queue = albumTracks
            index = position
        } else {
            queue = albumTracks
            index = 0
            load(0)
        }
    }

    /** Berpindah ke album lain (pemilih album di pemutar): antrean diganti dan lagu pertamanya diputar. */
    fun playAlbumTracks(albumTracks: List<LibraryTrack>) {
        if (albumTracks.isEmpty()) return
        shuffle = false
        albumMode = true
        original = albumTracks
        queue = albumTracks
        index = 0
        load(0)
    }

    fun toggle() {
        val p = player ?: run {
            current?.let { load(index) }
            return
        }
        if (!prepared) return
        if (p.isPlaying) {
            p.pause()
            isPlaying = false
        } else {
            p.play()
            isPlaying = true
        }
    }

    fun next() {
        if (queue.isEmpty()) return
        load(if (index + 1 < queue.size) index + 1 else 0)
    }

    fun previous() {
        if (queue.isEmpty()) return
        if (positionMs() > 3000) {
            seekTo(0)
        } else {
            load((index - 1).coerceAtLeast(0))
        }
    }

    fun positionMs(): Int {
        val p = player ?: return 0
        return if (prepared) runCatching { p.currentPosition.toInt() }.getOrDefault(0).coerceAtLeast(0) else 0
    }

    fun seekTo(ms: Int) {
        val p = player ?: return
        if (prepared) runCatching { p.seekTo(ms.toLong().coerceIn(0L, durationMs.toLong().coerceAtLeast(0L))) }
    }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            val p = player ?: return
            when (state) {
                Player.STATE_READY -> {
                    prepared = true
                    if (p.duration != C.TIME_UNSET && p.duration > 0) durationMs = p.duration.toInt()
                }
                Player.STATE_ENDED -> {
                    if (index + 1 < queue.size) {
                        load(index + 1)
                    } else {
                        isPlaying = false
                        runCatching {
                            p.pause()
                            p.seekTo(0)
                        }
                    }
                }
                else -> Unit
            }
        }

        override fun onIsPlayingChanged(playing: Boolean) {
            // Selama buffering sesaat, ikon tetap "play" bila pemutar memang diminta bermain.
            isPlaying = playing || (player?.let { it.playWhenReady && it.playbackState == Player.STATE_BUFFERING } == true)
        }

        override fun onPlayerError(e: PlaybackException) {
            error = "Tidak dapat memutar ${current?.item?.displayName ?: "lagu"}"
            isPlaying = false
        }
    }

    private fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        // Keluaran float: audio 24-bit/32-bit tidak diturunkan ke 16-bit sebelum AudioTrack.
        val renderers = DefaultRenderersFactory(context)
            .setEnableAudioFloatOutput(true)
            .setEnableAudioTrackPlaybackParams(false)
        val p = ExoPlayer.Builder(context, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                false,
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.addListener(listener)
        player = p
        return p
    }

    private fun load(i: Int) {
        val track = queue.getOrNull(i) ?: return
        prepared = false
        isPlaying = false
        index = i
        error = null
        durationMs = (track.tags.durationMs).toInt()
        try {
            val p = ensurePlayer()
            p.setMediaItem(MediaItem.fromUri(track.item.uri))
            p.prepare()
            p.playWhenReady = true
        } catch (e: Exception) {
            error = e.message ?: "Tidak dapat memutar lagu"
            isPlaying = false
        }
    }

    fun release() {
        prepared = false
        isPlaying = false
        player?.let {
            runCatching { it.removeListener(listener) }
            runCatching { it.release() }
        }
        player = null
    }
}
