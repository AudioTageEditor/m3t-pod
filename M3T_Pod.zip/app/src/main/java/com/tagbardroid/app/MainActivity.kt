// File: app/src/main/java/com/tagbardroid/app/MainActivity.kt
package com.tagbardroid.app

import android.app.Application
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.tagbardroid.app.ui.IntroSplash
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tagbardroid.app.engine.AlbumGrouping
import com.tagbardroid.app.engine.AudioMetadata
import com.tagbardroid.app.engine.BatchReport
import com.tagbardroid.app.engine.CoverAction
import com.tagbardroid.app.engine.PendingRecovery
import com.tagbardroid.app.engine.ReplayGainReport
import com.tagbardroid.app.engine.TagEdit
import com.tagbardroid.app.library.AllSongsSort
import com.tagbardroid.app.library.AutoNumberOptions
import com.tagbardroid.app.library.NaturalOrder
import com.tagbardroid.app.library.normalizeKey
import com.tagbardroid.app.player.PlayerController
import com.tagbardroid.app.library.BrowserState
import com.tagbardroid.app.library.CoverRepository
import com.tagbardroid.app.library.FileAndPlaylistManager
import com.tagbardroid.app.library.FilenameToTagPreview
import com.tagbardroid.app.library.LibraryFolder
import com.tagbardroid.app.library.LibraryGroup
import com.tagbardroid.app.library.LibrarySnapshot
import com.tagbardroid.app.library.LibraryTrack
import com.tagbardroid.app.library.LibraryViewMode
import com.tagbardroid.app.library.LibraryViews
import com.tagbardroid.app.library.NumberingPreview
import com.tagbardroid.app.library.Playlist
import com.tagbardroid.app.library.PlaylistDestination
import com.tagbardroid.app.library.PlaylistExistsException
import com.tagbardroid.app.library.PlaylistFile
import com.tagbardroid.app.library.PlaylistFormat
import com.tagbardroid.app.library.RenamePreview
import com.tagbardroid.app.library.RenameStatus
import com.tagbardroid.app.library.RenamedFile
import com.tagbardroid.app.ui.ClassicTheme
import com.tagbardroid.app.ui.DesktopState
import com.tagbardroid.app.ui.MainScreen
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// =====================================================================================
// STATE UI
// =====================================================================================

enum class MainTab { LIBRARY, PLAYLIST }

/** Mode tema: Terang, Gelap, atau Dynamic Color (latar mengikuti warna dominan cover). */
enum class ThemeMode { LIGHT, DARK, DYNAMIC }

/** Keadaan overlay pemutar melayang. */
enum class PlayerMode { EXPANDED, CAPSULE, HIDDEN }

enum class InspectorField(val label: String, val numeric: Boolean = false) {
    TITLE("Title"),
    ARTIST("Artist"),
    ALBUM("Album"),
    ALBUM_ARTIST("Album Artist"),
    GENRE("Genre"),
    YEAR("Year"),
    TRACK("Track", numeric = true),
    DISC("Disc", numeric = true),
    COMMENT("Comment"),
}

data class InspectorState(
    /** documentId lagu yang sedang diedit. */
    val ids: List<String> = emptyList(),
    /** Lagu yang sampul dan info teknisnya ditampilkan. */
    val anchor: LibraryTrack? = null,
    /** Metadata lengkap lagu [anchor], tanpa byte sampul. */
    val metadata: AudioMetadata? = null,
    val cover: ImageBitmap? = null,
    val loading: Boolean = false,
    val error: String? = null,
    /** Hanya kolom yang diubah pengguna. */
    val draft: Map<InspectorField, String> = emptyMap(),
) {
    val isBatch: Boolean get() = ids.size > 1
    val isDirty: Boolean get() = draft.isNotEmpty()
}

enum class CoverScope(val label: String) {
    ONE("Lagu ini saja"),
    SELECTION("Semua lagu terpilih"),
    ALBUM("Seluruh album"),
}

sealed interface UiDialog {
    data class Confirm(
        val title: String,
        val message: String,
        val confirmLabel: String,
        val onConfirm: () -> Unit,
    ) : UiDialog

    data class Info(val title: String, val lines: List<String>) : UiDialog

    data class AutoNumber(val tracks: List<LibraryTrack>) : UiDialog

    data class FilenameToTagWizard(val tracks: List<LibraryTrack>) : UiDialog

    /** [previewPattern] adalah pola yang menghasilkan [previews]. */
    data class TagToFilenameWizard(
        val tracks: List<LibraryTrack>,
        val previewPattern: String? = null,
        val previews: List<RenamePreview> = emptyList(),
    ) : UiDialog

    data class ReplayGainResult(val report: ReplayGainReport) : UiDialog

    data class CoverOptions(val anchor: LibraryTrack, val selection: List<LibraryTrack>) : UiDialog

    data class ExportPlaylist(val format: PlaylistFormat) : UiDialog

    data class Recovery(val items: List<PendingRecovery>) : UiDialog

    data object About : UiDialog
}

data class BusyState(val title: String, val cancellable: Boolean = true)

data class ProgressState(val completed: Int = 0, val total: Int = 0, val name: String = "")

data class TechInfo(
    val stamp: String,
    val codec: String,
    val sampleRate: String,
    val bitrate: String,
    val trackGain: String,
    /** Bit depth (mis. "24") untuk format lossless; kosong bila tidak berlaku. */
    val bitDepth: String = "",
)

data class UiState(
    val snapshot: LibrarySnapshot? = null,
    val tab: MainTab = MainTab.LIBRARY,
    val viewMode: LibraryViewMode = LibraryViewMode.FOLDER,
    val browser: BrowserState = BrowserState(),
    val groupKey: String? = null,
    val query: String = "",
    /** Urutan tabel hasil tombol naik/turun (documentId). */
    val manualOrder: List<String>? = null,
    val checked: Set<String> = emptySet(),
    val focusedId: String? = null,
    val playlist: Playlist = Playlist(),
    val playlistChecked: Set<Long> = emptySet(),
    val playlistFocused: Long? = null,
    val playlistDirty: Boolean = false,
    val inspector: InspectorState = InspectorState(),
    val inspectorVisible: Boolean = true,
    val autoTechColumns: Boolean = true,
    val truePeak: Boolean = false,
    val allSort: AllSongsSort = AllSongsSort.TRACK_NUMBER,
    val shuffleSeed: Long = 0L,
    val themeMode: ThemeMode = ThemeMode.DARK,
    val playerMode: PlayerMode = PlayerMode.HIDDEN,
    // Browser sumber lagu di ruang kerja Playlist: terpisah dari tampilan tab Library.
    val pickMode: LibraryViewMode = LibraryViewMode.FOLDER,
    val pickBrowser: BrowserState = BrowserState(),
    val pickGroupKey: String? = null,
    val pickQuery: String = "",
    val busy: BusyState? = null,
    val dialog: UiDialog? = null,
    val status: String = "Pilih folder musik lewat menu File > Buka Folder.",
) {
    /** Dynamic Color memakai dasar gelap, jadi bilah sistem ikut mode gelap. */
    val darkTheme: Boolean get() = themeMode != ThemeMode.LIGHT
}

/** Isi tabel perpustakaan untuk tampilan saat ini. */
data class ViewContent(
    val title: String = "",
    val canGoUp: Boolean = false,
    val folders: List<LibraryFolder> = emptyList(),
    val playlists: List<PlaylistFile> = emptyList(),
    val groups: List<LibraryGroup> = emptyList(),
    val tracks: List<LibraryTrack> = emptyList(),
)

// =====================================================================================
// VIEWMODEL
// =====================================================================================

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val manager = FileAndPlaylistManager(application)

    var state by mutableStateOf(UiState())
        private set

    /** Intro logo hanya tampil sekali per peluncuran aplikasi. */
    var introDone by mutableStateOf(false)

    /** Dipisah dari [state] karena diperbarui sangat sering dari thread latar. */
    var progress by mutableStateOf(ProgressState())
        private set

    /** Info teknis per documentId, diisi bertahap untuk baris yang terlihat. */
    val techInfo = mutableStateMapOf<String, TechInfo>()

    private val prefs = application.getSharedPreferences("ui", android.content.Context.MODE_PRIVATE)

    val player = PlayerController(application)

    /** Jendela floating Sumber Lagu dan Susunan Playlist; posisinya diingat selama aplikasi berjalan. */
    val desktop = DesktopState()

    /** Thumbnail sampul untuk Cover Flow dan pemutar (cache memori + disk). */
    val covers = CoverRepository(application, manager.engine)

    private var latestSnapshot: LibrarySnapshot? = null
    private var latestTracks: Map<String, LibraryTrack> = emptyMap()

    private var operationJob: Job? = null
    private var inspectorJob: Job? = null
    private var techJob: Job? = null
    private val techQueue = LinkedHashMap<String, LibraryTrack>()
    private var techCacheDirty = false
    private val techCacheFile = File(application.filesDir, "tech-columns.tsv")

    private var pendingCoverTargets: List<LibraryTrack> = emptyList()
    private var pendingExport: ExportRequest? = null
    private var lastProgressAt = 0L

    private data class ExportRequest(val name: String, val format: PlaylistFormat, val includeMissing: Boolean)

    private data class ViewKey(
        val snapshot: LibrarySnapshot?,
        val mode: LibraryViewMode,
        val path: String,
        val groupKey: String?,
        val query: String,
        val order: List<String>?,
        val allSort: AllSongsSort,
        val seed: Long,
    )

    private var viewKey: ViewKey? = null
    private var viewValue = ViewContent()

    /** Beberapa tampilan terakhir disimpan, jadi bolak-balik antar menu tidak menghitung ulang. */
    private val recentContent = object : LinkedHashMap<ViewKey, ViewContent>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<ViewKey, ViewContent>?): Boolean = size > 12
    }
    private var recentSnapshot: LibrarySnapshot? = null

    // Cache terpisah untuk browser sumber lagu di ruang kerja Playlist.
    private var pickKey: ViewKey? = null
    private var pickValue = ViewContent()

    init {
        // Kunci lama "dark" (true/false) tetap dibaca supaya pilihan pengguna sebelumnya tidak hilang.
        val saved = prefs.getString("theme", null)?.let { name -> ThemeMode.entries.firstOrNull { it.name == name } }
            ?: if (prefs.getBoolean("dark", true)) ThemeMode.DARK else ThemeMode.LIGHT
        update { copy(themeMode = saved) }
        loadTechCache()
        startUp()
    }

    private fun update(change: UiState.() -> UiState) {
        state = state.change()
    }

    private fun startUp() {
        viewModelScope.launch {
            try {
                val recoveries = manager.engine.pendingRecoveries()
                val saved = manager.savedLibraryFolder()
                if (saved != null) {
                    // Daftar lagu langsung dari cache: tanpa pindai ulang otomatis. Pindai hanya sekali
                    // bila cache belum ada; selanjutnya hanya saat pengguna mengganti folder atau menekan Rescan.
                    val cached = manager.loadCachedLibrary(saved)
                    val dialog = recoveries.takeIf { it.isNotEmpty() }?.let { UiDialog.Recovery(it) }
                    if (cached != null) {
                        applySnapshot(cached, emptyList())
                        update {
                            copy(
                                dialog = dialog ?: this.dialog,
                                status = "${cached.tracks.size} lagu, ${cached.folders.size} folder (dari cache). Tekan Rescan untuk memperbarui.",
                            )
                        }
                    } else {
                        scan(saved, force = false, after = dialog)
                    }
                } else if (recoveries.isNotEmpty()) {
                    update { copy(dialog = UiDialog.Recovery(recoveries)) }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                showError("Gagal memulai", e)
            }
        }
    }

    // ---------------------------------------------------------------- Isi tampilan

    fun viewContent(): ViewContent {
        val s = state
        val key = ViewKey(s.snapshot, s.viewMode, s.browser.path, s.groupKey, s.query, s.manualOrder, s.allSort, s.shuffleSeed)
        val old = viewKey
        // Snapshot dibandingkan berdasarkan referensi agar tidak membandingkan ribuan lagu.
        if (old != null && old.snapshot === key.snapshot && old.mode == key.mode && old.path == key.path &&
            old.groupKey == key.groupKey && old.query == key.query && old.order === key.order &&
            old.allSort == key.allSort && old.seed == key.seed
        ) {
            return viewValue
        }
        viewValue = cached(key) {
            buildContent(s.snapshot, s.viewMode, s.browser, s.groupKey, s.query, s.allSort, s.shuffleSeed, s.manualOrder)
        }
        viewKey = key
        return viewValue
    }

    /** Isi browser sumber lagu di ruang kerja Playlist (Folder / Album / All Songs). */
    fun pickerContent(): ViewContent {
        val s = state
        val key = ViewKey(s.snapshot, s.pickMode, s.pickBrowser.path, s.pickGroupKey, s.pickQuery, null, AllSongsSort.TRACK_NUMBER, 0L)
        val old = pickKey
        if (old != null && old.snapshot === key.snapshot && old.mode == key.mode && old.path == key.path &&
            old.groupKey == key.groupKey && old.query == key.query
        ) {
            return pickValue
        }
        pickValue = cached(key) {
            buildContent(s.snapshot, s.pickMode, s.pickBrowser, s.pickGroupKey, s.pickQuery, AllSongsSort.TRACK_NUMBER, 0L, null)
        }
        pickKey = key
        return pickValue
    }

    private fun cached(key: ViewKey, build: () -> ViewContent): ViewContent {
        // Snapshot baru membuat semua hasil lama tidak berlaku.
        if (key.snapshot !== recentSnapshot) {
            recentContent.clear()
            recentSnapshot = key.snapshot
        }
        // Snapshot sudah dijamin sama, jadi tidak perlu ikut dibandingkan.
        val lookup = key.copy(snapshot = null)
        return recentContent[lookup] ?: build().also { recentContent[lookup] = it }
    }

    private fun buildContent(
        snapshot: LibrarySnapshot?,
        viewMode: LibraryViewMode,
        browser: BrowserState,
        groupKey: String?,
        query: String,
        allSort: AllSongsSort,
        shuffleSeed: Long,
        manualOrder: List<String>?,
    ): ViewContent {
        if (snapshot == null) return ViewContent()
        val content = if (viewMode == LibraryViewMode.ALL) {
            val found = LibraryViews.search(snapshot.tracks, query)
            val sorted = if (allSort == AllSongsSort.SHUFFLE) {
                found.shuffled(java.util.Random(shuffleSeed))
            } else {
                found.sortedWith(
                    compareBy<LibraryTrack> { it.tags.trackNumber ?: Int.MAX_VALUE }
                        .then { a, b -> NaturalOrder.compare(a.displayTitle, b.displayTitle) },
                )
            }
            ViewContent(title = "All Songs (${sorted.size})", tracks = sorted)
        } else if (viewMode == LibraryViewMode.FOLDER) {
            val path = browser.path
            val title = if (path.isEmpty()) "Folder utama" else path
            if (query.isBlank()) {
                val folder = LibraryViews.folderContent(snapshot, path)
                ViewContent(
                    title = title,
                    canGoUp = browser.canGoUp,
                    folders = folder.subfolders,
                    playlists = folder.playlists,
                    tracks = folder.tracks,
                )
            } else {
                // Pencarian mencakup semua sub-folder.
                ViewContent(
                    title = "Cari di $title",
                    canGoUp = browser.canGoUp,
                    folders = searchFolders(snapshot, path, query),
                    tracks = LibraryViews.search(LibraryViews.tracksUnder(snapshot, path), query),
                )
            }
        } else {
            val groups = LibraryViews.groups(snapshot, viewMode, query)
            val selected = groups.firstOrNull { it.key == groupKey }
            val modeName = viewMode.name.lowercase().replaceFirstChar { it.uppercase() }
            if (selected == null) {
                ViewContent(title = "$modeName (${groups.size})", groups = groups)
            } else {
                ViewContent(title = "$modeName: ${selected.title}", canGoUp = true, tracks = selected.tracks)
            }
        }
        val order = manualOrder ?: return content
        val position = order.withIndex().associate { it.value to it.index }
        return content.copy(tracks = content.tracks.sortedBy { position[it.documentId] ?: Int.MAX_VALUE })
    }

    private fun searchFolders(snapshot: LibrarySnapshot, path: String, query: String): List<LibraryFolder> {
        val words = normalizeKey(query).split(' ').filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        return snapshot.folders.filter { folder ->
            folder.path.isNotEmpty() && (path.isEmpty() || folder.path.startsWith("$path/")) &&
                normalizeKey(folder.name).let { name -> words.all { it in name } }
        }.sortedWith { a, b -> NaturalOrder.compare(a.name, b.name) }
    }

    /** Lagu sasaran operasi: yang dicentang, atau baris yang disorot. Urut sesuai tabel. */
    fun targets(): List<LibraryTrack> = targetsOf(state.tab == MainTab.PLAYLIST)

    /** Sama seperti [targets], tetapi konteksnya dipilih eksplisit (jendela playlist bisa tampil di tab Library). */
    fun targetsOf(inPlaylist: Boolean): List<LibraryTrack> {
        val s = state
        return if (!inPlaylist) {
            val tracks = viewContent().tracks
            if (s.checked.isNotEmpty()) tracks.filter { it.documentId in s.checked }
            else tracks.filter { it.documentId == s.focusedId }
        } else {
            val entries = s.playlist.entries
            val chosen = if (s.playlistChecked.isNotEmpty()) entries.filter { it.id in s.playlistChecked }
            else entries.filter { it.id == s.playlistFocused }
            chosen.mapNotNull { it.track }.distinctBy { it.documentId }
        }
    }

    private fun requireTargets(): List<LibraryTrack>? {
        val tracks = targets()
        if (tracks.isEmpty()) {
            update { copy(status = "Centang atau sorot minimal satu lagu.") }
            return null
        }
        return tracks
    }

    // ---------------------------------------------------------------- Navigasi

    /** Menjalankan [action] setelah memastikan isian tag yang belum disimpan boleh dibuang. */
    private fun guarded(action: () -> Unit) {
        if (!state.inspector.isDirty) {
            action()
            return
        }
        update {
            copy(
                dialog = UiDialog.Confirm(
                    "Perubahan belum disimpan",
                    "Buang isian tag yang belum disimpan?",
                    "Buang",
                ) {
                    update { copy(inspector = inspector.copy(draft = emptyMap())) }
                    action()
                },
            )
        }
    }

    private fun navigate(change: UiState.() -> UiState) = guarded {
        update { change().copy(checked = emptySet(), focusedId = null, manualOrder = null) }
        refreshInspector()
    }

    fun setViewMode(mode: LibraryViewMode) = navigate {
        copy(viewMode = mode, groupKey = null, browser = BrowserState(), tab = MainTab.LIBRARY)
    }

    fun openFolder(folder: LibraryFolder) = navigate { copy(browser = browser.open(folder), query = "") }

    fun openGroup(group: LibraryGroup) = navigate { copy(groupKey = group.key) }

    fun goUp() = navigate {
        if (viewMode == LibraryViewMode.FOLDER) copy(browser = browser.up(), query = "")
        else copy(groupKey = null)
    }

    fun setTab(tab: MainTab) {
        if (tab == state.tab) return
        guarded {
            update { copy(tab = tab) }
            refreshInspector()
        }
    }

    fun setQuery(query: String) {
        if (state.inspector.isDirty) {
            update { copy(status = "Simpan atau batalkan perubahan tag sebelum mencari.") }
            return
        }
        update { copy(query = query, checked = emptySet(), focusedId = null) }
        refreshInspector()
    }

    // ---------------------------------------------------------------- Browser sumber (ruang kerja Playlist)

    fun setPickMode(mode: LibraryViewMode) {
        update { copy(pickMode = mode, pickGroupKey = null, pickBrowser = BrowserState()) }
    }

    fun openPickFolder(folder: LibraryFolder) {
        update { copy(pickBrowser = pickBrowser.open(folder), pickQuery = "") }
    }

    fun openPickGroup(group: LibraryGroup) {
        update { copy(pickGroupKey = group.key) }
    }

    fun pickGoUp() {
        update {
            if (pickMode == LibraryViewMode.FOLDER) copy(pickBrowser = pickBrowser.up(), pickQuery = "")
            else copy(pickGroupKey = null)
        }
    }

    fun setPickQuery(query: String) {
        update { copy(pickQuery = query) }
    }

    /** Memutar [track] dengan antrean berupa daftar [list] (mis. isi browser sumber). */
    fun playTrackIn(list: List<LibraryTrack>, track: LibraryTrack) {
        player.start(if (list.any { it.documentId == track.documentId }) list else listOf(track), track)
        update { copy(playerMode = if (playerMode == PlayerMode.CAPSULE) playerMode else PlayerMode.EXPANDED) }
    }

    /** Menambahkan banyak lagu sekaligus (mis. semua lagu yang tampil di browser sumber). */
    fun addTracksToPlaylist(tracks: List<LibraryTrack>) {
        if (tracks.isEmpty()) return
        update {
            copy(
                playlist = playlist.add(tracks),
                playlistDirty = true,
                status = "${tracks.size} lagu ditambahkan ke \"${playlist.name}\" (${playlist.entries.size + tracks.size} lagu).",
            )
        }
    }

    fun setAllSort(sort: AllSongsSort) {
        update {
            copy(
                allSort = sort,
                shuffleSeed = if (sort == AllSongsSort.SHUFFLE) System.nanoTime() else shuffleSeed,
                manualOrder = null,
            )
        }
    }

    // ---------------------------------------------------------------- Tema, About, pemutar

    /** Terang → Gelap → Dynamic Color → Terang. */
    fun toggleTheme() {
        val next = when (state.themeMode) {
            ThemeMode.LIGHT -> ThemeMode.DARK
            ThemeMode.DARK -> ThemeMode.DYNAMIC
            ThemeMode.DYNAMIC -> ThemeMode.LIGHT
        }
        setThemeMode(next)
    }

    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString("theme", mode.name).putBoolean("dark", mode != ThemeMode.LIGHT).apply()
        update { copy(themeMode = mode) }
    }

    // ---------------------------------------------------------------- Dynamic Color

    /** Warna dominan cover yang sedang dipakai mode Dynamic; null = belum ada / tanpa cover. */
    var dynamicSeed by mutableStateOf<Color?>(null)
        private set

    /**
     * Lagu yang menentukan warna Dynamic: lagu yang sedang diputar; bila jeda atau berhenti, lagu
     * yang disorot di daftar; bila tidak ada, lagu terakhir di pemutar.
     */
    fun dynamicSourceTrack(): LibraryTrack? {
        val s = state
        val playing = player.current
        if (player.isPlaying && playing != null) return playing
        val focused = if (s.tab == MainTab.PLAYLIST) {
            s.playlistFocused?.let { id -> s.playlist.entries.firstOrNull { it.id == id }?.track }
        } else {
            s.focusedId?.let { id -> trackIndex()[id] }
        }
        return focused ?: playing
    }

    /** Menghitung ulang [dynamicSeed] dari cover [track]; dipanggil dari komposisi saat lagu berubah. */
    suspend fun updateDynamicSeed(track: LibraryTrack?) {
        if (track == null) {
            dynamicSeed = null
            return
        }
        val latest = latestTrack(track)
        val key = covers.key(latest)
        val image = covers.peek(key) ?: covers.load(latest, key)
        dynamicSeed = image?.let { covers.dominantColor(key, it) }?.let { Color(it) }
    }

    private fun trackIndex(): Map<String, LibraryTrack> {
        val snapshot = state.snapshot ?: return emptyMap()
        if (snapshot !== latestSnapshot) {
            latestTracks = snapshot.tracks.associateBy { it.documentId }
            latestSnapshot = snapshot
        }
        return latestTracks
    }

    fun showAbout() = update { copy(dialog = UiDialog.About) }

    fun setPlayerMode(mode: PlayerMode) = update { copy(playerMode = mode) }

    fun playTrack(track: LibraryTrack, fromPlaylist: Boolean = state.tab == MainTab.PLAYLIST) {
        val list = if (!fromPlaylist) {
            viewContent().tracks
        } else {
            state.playlist.entries.mapNotNull { it.track }
        }
        player.start(if (list.any { it.documentId == track.documentId }) list else listOf(track), track)
        update { copy(playerMode = if (playerMode == PlayerMode.CAPSULE) playerMode else PlayerMode.EXPANDED) }
    }

    fun playSelected(inPlaylist: Boolean = state.tab == MainTab.PLAYLIST) {
        val fallback = if (inPlaylist) {
            state.playlist.entries.firstNotNullOfOrNull { it.track }
        } else {
            viewContent().tracks.firstOrNull()
        }
        val track = (if (inPlaylist) targetsOf(true) else targets()).firstOrNull() ?: fallback
        if (track == null) {
            update { copy(status = "Tidak ada lagu untuk diputar.") }
            return
        }
        playTrack(track, inPlaylist)
    }

    fun playAlbumOfCurrent() {
        val current = player.current ?: return
        player.playAlbum(albumOf(current).sortedWith(LibraryViews.albumOrder))
    }

    private var albumListSnapshot: LibrarySnapshot? = null
    private var albumList: List<LibraryGroup> = emptyList()

    /** Semua album di pustaka (untuk pemilih album di pemutar); disimpan per snapshot. */
    fun albumGroups(): List<LibraryGroup> {
        val snapshot = state.snapshot ?: return emptyList()
        if (snapshot !== albumListSnapshot) {
            albumList = LibraryViews.groups(snapshot, LibraryViewMode.ALBUM)
            albumListSnapshot = snapshot
        }
        return albumList
    }

    /** Key album yang sedang diputar (dipakai untuk menandai pilihan di dropdown). */
    fun currentAlbumKey(): String? {
        val current = player.current ?: return null
        if (!player.albumMode) return null
        return albumGroups().firstOrNull { g -> g.tracks.any { it.documentId == current.documentId } }?.key
    }

    /** Berganti ke [group] langsung dari pemutar: antrean dan Cover Flow berisi album itu, lagu pertama diputar. */
    fun playAlbumGroup(group: LibraryGroup) {
        if (group.tracks.isEmpty()) return
        player.playAlbumTracks(group.tracks)
        update { copy(playerMode = if (playerMode == PlayerMode.CAPSULE) playerMode else PlayerMode.EXPANDED) }
    }

    fun addCurrentToPlaylist() {
        val track = player.current ?: return
        update {
            copy(
                playlist = playlist.add(listOf(track)),
                playlistDirty = true,
                status = "\"${track.displayTitle}\" ditambahkan ke \"${playlist.name}\".",
            )
        }
    }

    /**
     * Versi terbaru [track] dari pustaka. Antrean pemutar menyimpan objek lama, padahal sampul
     * bisa saja baru diganti, jadi kunci cache harus dihitung dari data terbaru.
     */
    fun latestTrack(track: LibraryTrack): LibraryTrack {
        if (state.snapshot == null) return track
        return trackIndex()[track.documentId] ?: track
    }

    override fun onCleared() {
        player.release()
        super.onCleared()
    }

    // ---------------------------------------------------------------- Seleksi

    fun focusTrack(track: LibraryTrack) = guarded {
        update { copy(focusedId = track.documentId) }
        refreshInspector()
    }

    fun toggleTrack(track: LibraryTrack) = guarded {
        val id = track.documentId
        update {
            copy(checked = if (id in checked) checked - id else checked + id, focusedId = id)
        }
        refreshInspector()
    }

    fun focusEntry(id: Long) = guarded {
        update { copy(playlistFocused = id) }
        refreshInspector()
    }

    fun toggleEntry(id: Long) = guarded {
        update {
            copy(
                playlistChecked = if (id in playlistChecked) playlistChecked - id else playlistChecked + id,
                playlistFocused = id,
            )
        }
        refreshInspector()
    }

    fun selectAll(inPlaylist: Boolean = state.tab == MainTab.PLAYLIST) = guarded {
        if (!inPlaylist) {
            val ids = viewContent().tracks.mapTo(LinkedHashSet()) { it.documentId }
            update { copy(checked = ids, status = "${ids.size} lagu dipilih.") }
        } else {
            val ids = state.playlist.entries.mapTo(LinkedHashSet()) { it.id }
            update { copy(playlistChecked = ids, status = "${ids.size} entri dipilih.") }
        }
        refreshInspector()
    }

    fun selectNone(inPlaylist: Boolean = state.tab == MainTab.PLAYLIST) = guarded {
        update {
            if (!inPlaylist) copy(checked = emptySet(), focusedId = null)
            else copy(playlistChecked = emptySet(), playlistFocused = null)
        }
        refreshInspector()
    }

    fun invertSelection() = guarded {
        if (state.tab == MainTab.LIBRARY) {
            val all = viewContent().tracks.map { it.documentId }
            update { copy(checked = all.filterNot { it in checked }.toSet()) }
        } else {
            update { copy(playlistChecked = playlist.entries.map { it.id }.filterNot { it in playlistChecked }.toSet()) }
        }
        refreshInspector()
    }

    // ---------------------------------------------------------------- Urutan & playlist

    /** Menggeser baris tercentang (atau tersorot) satu posisi; [delta] -1 naik, +1 turun. */
    fun moveSelection(delta: Int, inPlaylist: Boolean = state.tab == MainTab.PLAYLIST) {
        val s = state
        if (!inPlaylist) {
            val ids = viewContent().tracks.map { it.documentId }
            val chosen = s.checked.ifEmpty { setOfNotNull(s.focusedId) }
            if (chosen.isEmpty()) {
                update { copy(status = "Pilih lagu yang akan digeser.") }
                return
            }
            update { copy(manualOrder = shift(ids, chosen, delta)) }
        } else {
            val ids = s.playlist.entries.map { it.id }
            val chosen = s.playlistChecked.ifEmpty { setOfNotNull(s.playlistFocused) }
            if (chosen.isEmpty()) {
                update { copy(status = "Sorot atau centang entri yang akan digeser.") }
                return
            }
            val order = shift(ids, chosen, delta)
            if (order == ids) return
            val byId = s.playlist.entries.associateBy { it.id }
            update {
                copy(playlist = playlist.copy(entries = order.map { byId.getValue(it) }), playlistDirty = true)
            }
        }
    }

    private fun <T> shift(items: List<T>, chosen: Set<T>, delta: Int): List<T> {
        val result = items.toMutableList()
        val indices = if (delta < 0) 1 until result.size else result.size - 2 downTo 0
        for (i in indices) {
            val j = i + if (delta < 0) -1 else 1
            if (result[i] in chosen && result[j] !in chosen) {
                val temp = result[i]
                result[i] = result[j]
                result[j] = temp
            }
        }
        return result
    }

    /** Menambahkan satu lagu langsung dari daftar, tanpa harus memutarnya atau mencentangnya. */
    fun addTrackToPlaylist(track: LibraryTrack) {
        update {
            copy(
                playlist = playlist.add(listOf(track)),
                playlistDirty = true,
                status = "\"${track.displayTitle}\" ditambahkan ke \"${playlist.name}\" (${playlist.entries.size + 1} lagu).",
            )
        }
    }

    /** Menggeser satu entri playlist satu posisi; [delta] -1 naik, +1 turun. */
    fun moveEntry(id: Long, delta: Int) {
        val current = state.playlist
        val moved = if (delta < 0) current.moveUp(id) else current.moveDown(id)
        if (moved === current) return
        update { copy(playlist = moved, playlistDirty = true, playlistFocused = id) }
    }

    /** Memindahkan baris tercentang (atau tersorot) ke urutan paling atas atau paling bawah. */
    fun moveSelectionToEdge(top: Boolean, inPlaylist: Boolean = state.tab == MainTab.PLAYLIST) {
        val s = state
        if (!inPlaylist) return
        val chosen = s.playlistChecked.ifEmpty { setOfNotNull(s.playlistFocused) }
        if (chosen.isEmpty()) {
            update { copy(status = "Sorot atau centang entri yang akan dipindah.") }
            return
        }
        val picked = s.playlist.entries.filter { it.id in chosen }
        val rest = s.playlist.entries.filterNot { it.id in chosen }
        val order = if (top) picked + rest else rest + picked
        if (order.map { it.id } == s.playlist.entries.map { it.id }) return
        update { copy(playlist = playlist.copy(entries = order), playlistDirty = true) }
    }

    /** Menghapus satu entri tertentu dari playlist. */
    fun removeEntry(id: Long) = guarded {
        update {
            copy(
                playlist = playlist.remove(id),
                playlistChecked = playlistChecked - id,
                playlistFocused = if (playlistFocused == id) null else playlistFocused,
                playlistDirty = true,
            )
        }
        refreshInspector()
    }

    fun addToPlaylist() {
        if (state.tab != MainTab.LIBRARY) {
            update { copy(status = "Buka tab Library, lalu pilih lagu yang akan ditambahkan.") }
            return
        }
        val tracks = requireTargets() ?: return
        update {
            copy(
                playlist = playlist.add(tracks),
                playlistDirty = true,
                status = "${tracks.size} lagu ditambahkan ke \"${playlist.name}\".",
            )
        }
    }

    /**
     * Tombol "+ Tambah Terpilih ke Playlist" di Library: memasukkan semua lagu yang dicentang sekaligus
     * (urutan sesuai tampilan), lalu mengosongkan centang agar gelombang berikutnya bisa langsung dipilih.
     */
    fun addCheckedToPlaylist() {
        val s = state
        if (s.checked.isEmpty()) {
            update { copy(status = "Centang minimal satu lagu untuk ditambahkan.") }
            return
        }
        val tracks = viewContent().tracks.filter { it.documentId in s.checked }
        if (tracks.isEmpty()) {
            update { copy(status = "Lagu yang dicentang tidak ada di tampilan ini.") }
            return
        }
        update {
            copy(
                playlist = playlist.add(tracks),
                playlistDirty = true,
                checked = emptySet(),
                status = "${tracks.size} lagu terpilih ditambahkan ke \"${playlist.name}\" (${playlist.entries.size + tracks.size} lagu).",
            )
        }
    }

    /** Mengacak seluruh urutan Susunan Playlist; hasilnya yang dipakai saat disimpan atau diekspor. */
    fun shufflePlaylist() {
        val entries = state.playlist.entries
        if (entries.size < 2) return
        var shuffled = entries.shuffled()
        // Hindari urutan acak yang kebetulan sama persis dengan urutan semula.
        if (shuffled.map { it.id } == entries.map { it.id }) shuffled = entries.reversed()
        update {
            copy(
                playlist = playlist.copy(entries = shuffled),
                playlistDirty = true,
                status = "Urutan ${entries.size} lagu di \"${playlist.name}\" diacak.",
            )
        }
    }

    fun removeFromPlaylist(inPlaylist: Boolean = state.tab == MainTab.PLAYLIST) {
        val s = state
        if (!inPlaylist) return
        val chosen = s.playlistChecked.ifEmpty { setOfNotNull(s.playlistFocused) }
        if (chosen.isEmpty()) return
        guarded {
            update {
                copy(
                    playlist = playlist.remove(chosen),
                    playlistChecked = emptySet(),
                    playlistFocused = null,
                    playlistDirty = true,
                )
            }
            refreshInspector()
        }
    }

    fun newPlaylist() = confirmDiscardPlaylist {
        guarded {
            update {
                copy(
                    playlist = Playlist(),
                    playlistChecked = emptySet(),
                    playlistFocused = null,
                    playlistDirty = false,
                    tab = MainTab.PLAYLIST,
                )
            }
            refreshInspector()
        }
    }

    fun confirmDiscardPlaylist(action: () -> Unit) {
        if (!state.playlistDirty || state.playlist.entries.isEmpty()) {
            action()
            return
        }
        update {
            copy(
                dialog = UiDialog.Confirm(
                    "Playlist belum diekspor",
                    "Perubahan pada \"${playlist.name}\" akan hilang. Lanjutkan?",
                    "Lanjutkan",
                    action,
                ),
            )
        }
    }

    // ---------------------------------------------------------------- Inspector

    private fun refreshInspector(force: Boolean = false) {
        val tracks = targets()
        val ids = tracks.map { it.documentId }
        val old = state.inspector
        // Lagu yang disorot menjadi acuan bila termasuk sasaran.
        val anchor = tracks.firstOrNull { it.documentId == state.focusedId } ?: tracks.firstOrNull()
        if (!force && ids == old.ids && anchor?.documentId == old.anchor?.documentId) return

        inspectorJob?.cancel()
        val draft = if (ids == old.ids) old.draft else emptyMap()
        if (anchor == null) {
            update { copy(inspector = InspectorState()) }
            return
        }
        update { copy(inspector = InspectorState(ids = ids, anchor = anchor, loading = true, draft = draft)) }
        inspectorJob = viewModelScope.launch {
            try {
                val metadata = manager.engine.readMetadata(anchor.item, includeCover = true)
                val bitmap = metadata.coverArt?.let { bytes -> withContext(Dispatchers.Default) { decodeCover(bytes) } }
                storeTech(anchor, metadata)
                update {
                    copy(
                        inspector = inspector.copy(
                            metadata = metadata.copy(coverArt = null),
                            cover = bitmap,
                            loading = false,
                        ),
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                update { copy(inspector = inspector.copy(loading = false, error = e.message ?: "Tag tidak terbaca")) }
            } catch (e: OutOfMemoryError) {
                update { copy(inspector = inspector.copy(loading = false, error = "Memori tidak cukup")) }
            }
        }
    }

    private fun decodeCover(bytes: ByteArray): ImageBitmap? {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 800) sample *= 2
        val options = BitmapFactory.Options()
        options.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)?.asImageBitmap()
    }

    /** Nilai asli kolom; null berarti belum dimuat atau berbeda antar lagu terpilih. */
    fun baseValue(field: InspectorField): String? {
        val inspector = state.inspector
        if (!inspector.isBatch) {
            val m = inspector.metadata ?: return null
            return when (field) {
                InspectorField.TITLE -> m.title
                InspectorField.ARTIST -> m.artist
                InspectorField.ALBUM -> m.album
                InspectorField.ALBUM_ARTIST -> m.albumArtist
                InspectorField.GENRE -> m.genre
                InspectorField.YEAR -> m.year
                InspectorField.TRACK -> m.trackNumber
                InspectorField.DISC -> m.discNumber
                InspectorField.COMMENT -> m.comment
            }
        }
        if (field == InspectorField.COMMENT) return null
        val values = targets().map { track ->
            val t = track.tags
            when (field) {
                InspectorField.TITLE -> t.title
                InspectorField.ARTIST -> t.artist
                InspectorField.ALBUM -> t.album
                InspectorField.ALBUM_ARTIST -> t.albumArtist
                InspectorField.GENRE -> t.genre
                InspectorField.YEAR -> t.year
                InspectorField.TRACK -> t.trackNumber?.toString().orEmpty()
                InspectorField.DISC -> t.discNumber?.toString().orEmpty()
                InspectorField.COMMENT -> ""
            }
        }.distinct()
        return values.singleOrNull()
    }

    fun editField(field: InspectorField, value: String) {
        val clean = if (field.numeric) value.filter { it in '0'..'9' }.take(4) else value
        val base = baseValue(field)
        // Pada nilai yang beragam, isian kosong berarti "biarkan".
        val unchanged = clean == base || (base == null && clean.isEmpty())
        update {
            val draft = if (unchanged) inspector.draft - field else inspector.draft + (field to clean)
            copy(inspector = inspector.copy(draft = draft))
        }
    }

    fun revertTags() {
        update { copy(inspector = inspector.copy(draft = emptyMap())) }
    }

    fun saveTags() {
        val draft = state.inspector.draft
        if (draft.isEmpty()) {
            update { copy(status = "Tidak ada perubahan tag.") }
            return
        }
        val tracks = requireTargets() ?: return
        val edit = TagEdit(
            title = draft[InspectorField.TITLE],
            artist = draft[InspectorField.ARTIST],
            album = draft[InspectorField.ALBUM],
            albumArtist = draft[InspectorField.ALBUM_ARTIST],
            genre = draft[InspectorField.GENRE],
            year = draft[InspectorField.YEAR],
            trackNumber = draft[InspectorField.TRACK],
            discNumber = draft[InspectorField.DISC],
            comment = draft[InspectorField.COMMENT],
        )
        val write: () -> Unit = {
            runOperation("Menyimpan tag", tracks) {
                val result = manager.engine.batchEdit(tracks.map { it.item }, edit, ::report)
                // Isian dipertahankan bila ada yang gagal, agar bisa dicoba lagi.
                if (result.failed.isEmpty()) update { copy(inspector = inspector.copy(draft = emptyMap())) }
                batchDialog("Simpan tag", result)
            }
        }
        if (tracks.size == 1) {
            write()
        } else {
            val names = draft.keys.joinToString { it.label }
            update {
                copy(dialog = UiDialog.Confirm("Edit massal", "Ubah $names pada ${tracks.size} lagu?", "Simpan", write))
            }
        }
    }

    // ---------------------------------------------------------------- Sampul

    fun showCoverOptions() {
        val tracks = requireTargets() ?: return
        val anchor = state.inspector.anchor ?: tracks.first()
        guarded { update { copy(dialog = UiDialog.CoverOptions(anchor, tracks)) } }
    }

    private fun coverTargets(scope: CoverScope, anchor: LibraryTrack, selection: List<LibraryTrack>): List<LibraryTrack> =
        when (scope) {
            CoverScope.ONE -> listOf(anchor)
            CoverScope.SELECTION -> selection
            CoverScope.ALBUM -> albumOf(anchor)
        }

    /** Lagu tanpa tag Album hanya dikelompokkan dengan lagu tanpa Album di folder yang sama. */
    fun albumOf(anchor: LibraryTrack): List<LibraryTrack> {
        val snapshot = state.snapshot ?: return listOf(anchor)
        if (anchor.tags.album.isBlank()) {
            return snapshot.tracks.filter {
                it.item.parentDocumentId == anchor.item.parentDocumentId && it.tags.album.isBlank()
            }
        }
        return LibraryViews.groups(snapshot, LibraryViewMode.ALBUM)
            .firstOrNull { group -> group.tracks.any { it.documentId == anchor.documentId } }
            ?.tracks ?: listOf(anchor)
    }

    /** Menyiapkan sasaran sebelum pemilih gambar dibuka. */
    fun prepareCoverPick(scope: CoverScope, anchor: LibraryTrack, selection: List<LibraryTrack>) {
        pendingCoverTargets = coverTargets(scope, anchor, selection)
        dismissDialog()
    }

    fun onCoverPicked(uri: Uri?) {
        val tracks = pendingCoverTargets
        pendingCoverTargets = emptyList()
        if (uri == null || tracks.isEmpty()) return
        runOperation("Menyematkan sampul", tracks) {
            val art = manager.engine.loadCover(uri)
            val result = manager.engine.batchEdit(
                tracks.map { it.item }, TagEdit(cover = CoverAction.Replace(art)), ::report,
            )
            batchDialog("Sampul (${art.width} x ${art.height})", result)
        }
    }

    fun removeCover(scope: CoverScope, anchor: LibraryTrack, selection: List<LibraryTrack>) {
        val tracks = coverTargets(scope, anchor, selection)
        update {
            copy(
                dialog = UiDialog.Confirm("Hapus sampul", "Hapus sampul dari ${tracks.size} lagu?", "Hapus") {
                    runOperation("Menghapus sampul", tracks) {
                        val result = manager.engine.batchEdit(
                            tracks.map { it.item }, TagEdit(cover = CoverAction.Remove), ::report,
                        )
                        batchDialog("Hapus sampul", result)
                    }
                },
            )
        }
    }

    // ---------------------------------------------------------------- ReplayGain

    fun scanReplayGain(grouping: AlbumGrouping) {
        val tracks = requireTargets() ?: return
        guarded {
            runOperation("Memindai ReplayGain", tracks, rescan = false) {
                val result = manager.engine.analyzeReplayGain(
                    items = tracks.map { it.item },
                    grouping = grouping,
                    useTruePeak = state.truePeak,
                    onProgress = ::report,
                )
                UiDialog.ReplayGainResult(result)
            }
        }
    }

    fun writeReplayGain(result: ReplayGainReport) {
        val uris = result.tracks.mapTo(HashSet()) { it.item.uri }
        val tracks = state.snapshot?.tracks.orEmpty().filter { it.item.uri in uris }
        runOperation("Menulis ReplayGain", tracks) {
            batchDialog("Tulis ReplayGain", manager.engine.writeReplayGain(result, ::report))
        }
    }

    fun confirmRemoveReplayGain() {
        val tracks = requireTargets() ?: return
        guarded {
            update {
                copy(
                    dialog = UiDialog.Confirm(
                        "Hapus ReplayGain",
                        "Hapus semua tag ReplayGain dari ${tracks.size} lagu?",
                        "Hapus",
                    ) {
                        runOperation("Menghapus ReplayGain", tracks) {
                            batchDialog("Hapus ReplayGain", manager.removeReplayGain(tracks, ::report))
                        }
                    },
                )
            }
        }
    }

    fun toggleTruePeak() = update { copy(truePeak = !truePeak) }

    // ---------------------------------------------------------------- Tools

    fun showAutoNumber() {
        val tracks = requireTargets() ?: return
        guarded { update { copy(dialog = UiDialog.AutoNumber(tracks)) } }
    }

    fun previewAutoNumber(tracks: List<LibraryTrack>, options: AutoNumberOptions): Result<List<NumberingPreview>> =
        runCatching { manager.previewAutoNumber(tracks, options) }

    fun applyAutoNumber(previews: List<NumberingPreview>) {
        runOperation("Memberi nomor trek", previews.map { it.track }) {
            batchDialog("Auto-Numbering", manager.applyAutoNumber(previews, ::report))
        }
    }

    fun showFilenameToTag() {
        val tracks = requireTargets() ?: return
        guarded { update { copy(dialog = UiDialog.FilenameToTagWizard(tracks)) } }
    }

    fun previewFilenameToTag(
        tracks: List<LibraryTrack>,
        pattern: String,
        underscores: Boolean,
    ): Result<List<FilenameToTagPreview>> =
        runCatching { manager.previewFilenameToTag(tracks, pattern.trim().ifEmpty { null }, underscores) }

    fun applyFilenameToTag(previews: List<FilenameToTagPreview>) {
        val valid = previews.filter { it.error == null }
        runOperation("Mengisi tag dari nama file", valid.map { it.track }) {
            batchDialog("Filename to Tag", manager.applyFilenameToTag(valid, ::report))
        }
    }

    fun showTagToFilename() {
        val tracks = requireTargets() ?: return
        guarded { update { copy(dialog = UiDialog.TagToFilenameWizard(tracks)) } }
    }

    fun previewTagToFilename(tracks: List<LibraryTrack>, pattern: String) {
        val tree = state.snapshot?.treeUri ?: return
        runOperation("Membaca tag", emptyList(), rescan = false) {
            try {
                val previews = manager.previewTagToFilename(tracks, tree, pattern, onProgress = ::report)
                UiDialog.TagToFilenameWizard(tracks, pattern, previews)
            } catch (e: IllegalArgumentException) {
                UiDialog.Info("Pola tidak valid", listOf(e.message ?: pattern))
            }
        }
    }

    fun applyRename(previews: List<RenamePreview>) {
        val tree = state.snapshot?.treeUri ?: return
        val ready = previews.filter { it.status == RenameStatus.READY }
        var renamed: List<RenamedFile> = emptyList()
        runOperation("Mengganti nama file", ready.map { it.track }, renames = { renamed }) {
            val result = manager.applyRename(ready, tree, ::report)
            renamed = result.renamed
            UiDialog.Info(
                "Tag to Filename",
                listOf("Berhasil: ${result.renamed.size}", "Gagal: ${result.failed.size}") +
                    result.failed.map { "${it.item.displayName}: ${it.message}" } +
                    if (result.renamed.isNotEmpty()) {
                        listOf("File M3U lama di penyimpanan perlu diekspor ulang.")
                    } else {
                        emptyList()
                    },
            )
        }
    }

    // ---------------------------------------------------------------- Folder & pemindaian

    fun onLibraryPicked(uri: Uri?) {
        if (uri == null) return
        try {
            manager.setLibraryFolder(uri)
        } catch (e: Exception) {
            showError("Folder tidak dapat dipakai", e)
            return
        }
        inspectorJob?.cancel()
        techQueue.clear()
        update {
            copy(
                snapshot = null,
                browser = BrowserState(),
                groupKey = null,
                query = "",
                manualOrder = null,
                checked = emptySet(),
                focusedId = null,
                playlist = Playlist(),
                playlistChecked = emptySet(),
                playlistFocused = null,
                playlistDirty = false,
                inspector = InspectorState(),
                tab = MainTab.LIBRARY,
            )
        }
        scan(uri, force = false)
    }

    /** Membuka pemilih folder hanya setelah perubahan yang belum disimpan dikonfirmasi. */
    fun requestOpenLibrary(launch: () -> Unit) = confirmDiscardPlaylist { guarded(launch) }

    fun rescan(force: Boolean) {
        val tree = state.snapshot?.treeUri ?: manager.savedLibraryFolder()
        if (tree == null) {
            update { copy(status = "Belum ada folder musik.") }
            return
        }
        guarded { scan(tree, force) }
    }

    private fun scan(tree: Uri, force: Boolean, after: UiDialog? = null) {
        if (force) techInfo.clear()
        runOperation("Memindai folder", emptyList(), rescan = false) {
            val snapshot = manager.scanLibrary(tree, force) { p ->
                val reading = p.tracksRead > 0
                report(
                    if (reading) p.tracksRead else 0,
                    if (reading) p.tracksFound else 0,
                    if (reading) p.currentName else "${p.tracksFound} lagu: ${p.currentName}",
                )
            }
            applySnapshot(snapshot, emptyList())
            after ?: if (snapshot.warnings.isNotEmpty()) UiDialog.Info("Peringatan pemindaian", snapshot.warnings) else null
        }
    }

    private fun applySnapshot(snapshot: LibrarySnapshot, renames: List<RenamedFile>) {
        val newIds = renames.mapNotNull { r -> r.newDocumentId?.let { r.oldDocumentId to it } }.toMap()
        val known = snapshot.tracks.mapTo(HashSet()) { it.documentId }
        fun map(id: String): String? = (newIds[id] ?: id).takeIf { it in known }
        update {
            copy(
                snapshot = snapshot,
                browser = browser.validate(snapshot),
                checked = checked.mapNotNull { map(it) }.toSet(),
                focusedId = focusedId?.let { map(it) },
                manualOrder = manualOrder?.mapNotNull { map(it) },
                playlist = playlist.relink(snapshot, renames),
                status = "${snapshot.tracks.size} lagu, ${snapshot.folders.size} folder.",
            )
        }
        // Grup bisa hilang setelah tag berubah.
        if (state.groupKey != null && viewContent().tracks.isEmpty()) {
            update { copy(groupKey = null, checked = emptySet(), focusedId = null) }
        }
        // Lagu yang tidak lagi terlihat tidak boleh tetap tercentang.
        val visible = viewContent().tracks.mapTo(HashSet()) { it.documentId }
        update {
            copy(
                checked = checked.filter { it in visible }.toSet(),
                focusedId = focusedId?.takeIf { it in visible },
            )
        }
    }

    // ---------------------------------------------------------------- Impor / ekspor

    fun importPlaylist(uri: Uri?) {
        if (uri == null) return
        val snapshot = state.snapshot
        if (snapshot == null) {
            update { copy(status = "Buka folder musik dulu agar lagu bisa dicocokkan.") }
            return
        }
        runOperation("Membuka playlist", emptyList(), rescan = false) {
            val playlist = manager.importPlaylist(uri, snapshot)
            update {
                copy(
                    playlist = playlist,
                    playlistChecked = emptySet(),
                    playlistFocused = null,
                    playlistDirty = false,
                    tab = MainTab.PLAYLIST,
                    status = "Playlist \"${playlist.name}\": ${playlist.entries.size} entri.",
                )
            }
            val missing = playlist.entries.count { it.isMissing }
            val approximate = playlist.entries.count { it.approximate }
            if (missing + approximate == 0) {
                null
            } else {
                UiDialog.Info(
                    "Hasil impor",
                    listOf(
                        "Tidak ditemukan: $missing (ditandai merah)",
                        "Cocok perkiraan: $approximate (ditandai ≈, mohon diperiksa)",
                    ),
                )
            }
        }
    }

    fun requestImport(action: () -> Unit) = confirmDiscardPlaylist { guarded(action) }

    fun showExport(format: PlaylistFormat) {
        if (state.playlist.entries.isEmpty()) {
            update { copy(status = "Playlist masih kosong. Tambahkan lagu dengan tombol + Playlist.") }
            return
        }
        update { copy(dialog = UiDialog.ExportPlaylist(format)) }
    }

    fun renamePlaylist(name: String) = update { copy(playlist = playlist.copy(name = name)) }

    /** Ekspor ke folder di dalam perpustakaan. */
    fun exportToLibrary(name: String, format: PlaylistFormat, includeMissing: Boolean, folderPath: String) {
        val snapshot = state.snapshot ?: return
        val destination = try {
            manager.libraryDestination(snapshot, folderPath)
        } catch (e: Exception) {
            showError("Ekspor gagal", e)
            return
        }
        export(ExportRequest(name, format, includeMissing), destination, overwrite = false)
    }

    fun prepareExportPick(name: String, format: PlaylistFormat, includeMissing: Boolean) {
        pendingExport = ExportRequest(name, format, includeMissing)
        dismissDialog()
    }

    fun onExportFolderPicked(uri: Uri?) {
        val request = pendingExport
        pendingExport = null
        if (uri == null || request == null) return
        val destination = try {
            manager.pickedDestination(uri)
        } catch (e: Exception) {
            showError("Ekspor gagal", e)
            return
        }
        export(request, destination, overwrite = false)
    }

    private fun export(request: ExportRequest, destination: PlaylistDestination, overwrite: Boolean) {
        val snapshot = state.snapshot ?: return
        val playlist = state.playlist.copy(name = request.name)
        val inLibrary = destination.treeUri == snapshot.treeUri
        runOperation("Mengekspor playlist", emptyList(), rescan = false) {
            try {
                val result = manager.exportPlaylist(
                    playlist, snapshot, destination, request.name, request.format, overwrite, request.includeMissing,
                )
                update { copy(playlist = playlist, playlistDirty = false, status = "Tersimpan: ${result.fileName}") }
                // Pindai ulang agar file baru muncul di browser folder.
                if (inLibrary) applySnapshot(manager.scanLibrary(snapshot.treeUri), emptyList())
                UiDialog.Info(
                    "Ekspor selesai",
                    listOf("File: ${result.fileName}", "Jumlah lagu: ${result.writtenCount}") +
                        if (result.missingKept > 0) {
                            listOf("${result.missingKept} entri hilang ditulis dengan path lama.")
                        } else {
                            emptyList()
                        },
                )
            } catch (e: PlaylistExistsException) {
                UiDialog.Confirm("File sudah ada", "Timpa \"${e.fileName}\"?", "Timpa") {
                    export(request, destination, overwrite = true)
                }
            }
        }
    }

    // ---------------------------------------------------------------- Pemulihan

    fun showRecoveries() {
        viewModelScope.launch {
            try {
                val items = manager.engine.pendingRecoveries()
                update {
                    if (items.isEmpty()) copy(status = "Tidak ada cadangan yang tertunda.")
                    else copy(dialog = UiDialog.Recovery(items))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                showError("Pemulihan", e)
            }
        }
    }

    fun recoverAll(items: List<PendingRecovery>) {
        runOperation("Memulihkan file", emptyList(), rescan = state.snapshot != null, cancellable = false) {
            val failures = mutableListOf<String>()
            items.forEachIndexed { index, item ->
                try {
                    manager.engine.recover(item)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failures += "${item.backupFile.name}: ${e.message}"
                }
                report(index + 1, items.size, item.backupFile.name)
            }
            state.snapshot?.let { manager.invalidate(it.tracks) }
            UiDialog.Info("Pemulihan", listOf("Dipulihkan: ${items.size - failures.size}") + failures)
        }
    }

    // ---------------------------------------------------------------- Operasi umum

    private fun report(p: com.tagbardroid.app.engine.OperationProgress) =
        report(p.completed, p.total, p.currentName)

    private fun report(completed: Int, total: Int, name: String) {
        val now = SystemClock.elapsedRealtime()
        // Batasi frekuensi pembaruan layar.
        if (completed != total && now - lastProgressAt < 80) return
        lastProgressAt = now
        progress = ProgressState(completed, total, name)
    }

    /**
     * Menjalankan satu operasi panjang dengan dialog progres.
     * @param changed lagu yang diubah; dibaca ulang saat pemindaian setelah operasi.
     */
    private fun runOperation(
        title: String,
        changed: List<LibraryTrack>,
        rescan: Boolean = true,
        cancellable: Boolean = true,
        renames: () -> List<RenamedFile> = { emptyList() },
        block: suspend () -> UiDialog?,
    ) {
        if (state.busy != null) return
        progress = ProgressState()
        update { copy(busy = BusyState(title, cancellable), dialog = null) }
        // UNDISPATCHED: blok try pasti sudah dimasuki sebelum bisa dibatalkan, sehingga finally selalu jalan.
        operationJob = viewModelScope.launch(start = CoroutineStart.UNDISPATCHED) {
            var next: UiDialog? = null
            try {
                next = block()
            } catch (e: CancellationException) {
                update { copy(status = "$title dibatalkan.") }
                throw e
            } catch (e: Exception) {
                next = UiDialog.Info("$title gagal", listOf(e.message ?: e.javaClass.simpleName))
            } catch (e: OutOfMemoryError) {
                next = UiDialog.Info("$title gagal", listOf("Memori tidak cukup"))
            } finally {
                // Dibatalkan pun, sebagian file mungkin sudah berubah.
                withContext(NonCancellable) {
                    if (changed.isNotEmpty()) {
                        manager.invalidate(changed)
                        changed.forEach { techInfo.remove(it.documentId) }
                    }
                    val snapshot = state.snapshot
                    if (rescan && snapshot != null) {
                        progress = ProgressState(name = "Memperbarui daftar...")
                        try {
                            applySnapshot(manager.scanLibrary(snapshot.treeUri), renames())
                        } catch (e: Exception) {
                            next = UiDialog.Info("Daftar gagal diperbarui", listOf(e.message ?: "Pindai ulang manual"))
                        }
                    }
                    val result = next
                    update { copy(busy = null, dialog = result) }
                    refreshInspector(force = true)
                    startTechWorker()
                }
            }
        }
    }

    fun cancelOperation() {
        if (state.busy?.cancellable == true) operationJob?.cancel()
    }

    private fun batchDialog(title: String, report: BatchReport): UiDialog = UiDialog.Info(
        title,
        listOf("Berhasil: ${report.succeeded.size}", "Gagal: ${report.failed.size}") +
            report.failed.map { "${it.item.displayName}: ${it.message}" },
    )

    private fun showError(title: String, error: Throwable) {
        update { copy(dialog = UiDialog.Info(title, listOf(error.message ?: error.javaClass.simpleName))) }
    }

    fun showDialog(dialog: UiDialog) = update { copy(dialog = dialog) }

    fun dismissDialog() = update { copy(dialog = null) }

    fun toggleInspector() = update { copy(inspectorVisible = !inspectorVisible) }

    fun toggleAutoTech() {
        update { copy(autoTechColumns = !autoTechColumns) }
        if (!state.autoTechColumns) techQueue.clear() else startTechWorker()
    }

    // ---------------------------------------------------------------- Kolom Codec & RG

    private fun stampOf(track: LibraryTrack) = "${track.item.sizeBytes}:${track.lastModified}"

    /** Info teknis yang masih sesuai dengan isi file sekarang. */
    fun techFor(track: LibraryTrack): TechInfo? = techInfo[track.documentId]?.takeIf { it.stamp == stampOf(track) }

    /** Dipanggil oleh baris tabel yang sedang terlihat. */
    fun requestTech(track: LibraryTrack) {
        if (!state.autoTechColumns || techFor(track) != null) return
        techQueue[track.documentId] = track
        startTechWorker()
    }

    fun cancelTech(track: LibraryTrack) {
        techQueue.remove(track.documentId)
    }

    private fun startTechWorker() {
        if (techJob?.isActive == true || state.busy != null || techQueue.isEmpty()) return
        techJob = viewModelScope.launch {
            while (techQueue.isNotEmpty() && state.busy == null && state.autoTechColumns) {
                val id = techQueue.keys.first()
                val track = techQueue.remove(id) ?: continue
                if (techFor(track) != null) continue
                try {
                    storeTech(track, manager.engine.readMetadata(track.item, includeCover = false))
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // Disimpan di memori saja agar tidak dicoba terus-menerus.
                    techInfo[id] = TechInfo(stampOf(track), "?", "", "", "?")
                }
            }
            saveTechCache()
        }
    }

    private fun storeTech(track: LibraryTrack, metadata: AudioMetadata) {
        techInfo[track.documentId] = TechInfo(
            stamp = stampOf(track),
            codec = metadata.codec,
            sampleRate = metadata.sampleRate,
            bitrate = metadata.bitrate,
            trackGain = metadata.replayGain.trackGain,
            bitDepth = metadata.bitDepth,
        )
        techCacheDirty = true
    }

    private fun loadTechCache() {
        runCatching {
            if (!techCacheFile.isFile) return
            techCacheFile.forEachLine { line ->
                val p = line.split('\t')
                // 6 kolom = cache lama (tanpa bit depth); 7 kolom = format baru.
                if (p.size == 6) techInfo[p[0]] = TechInfo(p[1], p[2], p[3], p[4], p[5])
                else if (p.size == 7) techInfo[p[0]] = TechInfo(p[1], p[2], p[3], p[4], p[5], p[6])
            }
        }
    }

    private suspend fun saveTechCache() {
        if (!techCacheDirty) return
        techCacheDirty = false
        val lines = techInfo.entries.filter { it.value.codec != "?" }.map { (id, t) ->
            listOf(id, t.stamp, t.codec, t.sampleRate, t.bitrate, t.trackGain, t.bitDepth)
                .joinToString("\t") { it.replace('\t', ' ').replace('\n', ' ') }
        }
        withContext(Dispatchers.IO) {
            runCatching { techCacheFile.writeText(lines.joinToString("\n")) }
        }
    }
}

// =====================================================================================
// ACTIVITY
// =====================================================================================

/** Pemilih file/folder sistem yang dipakai layar utama. */
class Pickers(
    val openLibrary: () -> Unit,
    val pickCover: () -> Unit,
    val openPlaylist: () -> Unit,
    val pickExportFolder: () -> Unit,
    val exit: () -> Unit,
)

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ViewModel dibuat di luar komposisi karena init-nya langsung menulis state.
        val mainViewModel = viewModel
        setContent {
            val dark = mainViewModel.state.darkTheme
            val mode = mainViewModel.state.themeMode
            SideEffect {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(
                        android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT,
                    ) { dark },
                    navigationBarStyle = SystemBarStyle.auto(
                        android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT,
                    ) { dark },
                )
            }
            ClassicTheme(mode, mainViewModel.dynamicSeed) {
                DynamicSeedEffect(mainViewModel)
                Box(Modifier.fillMaxSize()) {
                    TagBarApp(mainViewModel, onExit = { finish() })
                    if (!mainViewModel.introDone) IntroSplash(ready = mainViewModel.state.busy == null) { mainViewModel.introDone = true }
                }
            }
        }
    }

    /** Mengikuti lagu yang diputar/disorot: setiap berganti, ambil warna dominan cover-nya. */
    @Composable
    private fun DynamicSeedEffect(vm: MainViewModel) {
        val active = vm.state.themeMode == ThemeMode.DYNAMIC
        val track = if (active) vm.dynamicSourceTrack() else null
        val latest = track?.let { vm.latestTrack(it) }
        LaunchedEffect(active, latest?.documentId, latest?.lastModified, latest?.item?.sizeBytes) {
            vm.updateDynamicSeed(if (active) track else null)
        }
    }

    @Composable
    private fun TagBarApp(vm: MainViewModel, onExit: () -> Unit) {
        val libraryPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
            vm.onLibraryPicked(it)
        }
        val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {
            vm.onCoverPicked(it)
        }
        val playlistPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {
            vm.importPlaylist(it)
        }
        val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
            vm.onExportFolderPicked(it)
        }

        // Layar tetap menyala selama operasi panjang agar tidak terhenti di tengah jalan.
        val busy = vm.state.busy != null
        DisposableEffect(busy) {
            if (busy) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            onDispose { window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        }

        val pickers = remember(libraryPicker, coverPicker, playlistPicker, exportPicker) {
            Pickers(
                openLibrary = { vm.requestOpenLibrary { libraryPicker.launch(null) } },
                pickCover = { coverPicker.launch(arrayOf("image/jpeg", "image/png")) },
                // MIME file M3U berbeda-beda antar perangkat, jadi semua file ditampilkan.
                openPlaylist = { vm.requestImport { playlistPicker.launch(arrayOf("*/*")) } },
                pickExportFolder = { exportPicker.launch(null) },
                exit = { vm.confirmDiscardPlaylist(onExit) },
            )
        }
        MainScreen(vm, pickers)
    }
}
