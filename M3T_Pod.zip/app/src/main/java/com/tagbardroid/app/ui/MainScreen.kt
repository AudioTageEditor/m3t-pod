// File: app/src/main/java/com/tagbardroid/app/ui/MainScreen.kt
package com.tagbardroid.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.CubicBezierEasing
import com.tagbardroid.app.ThemeMode
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.graphics.toArgb
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.ui.draw.clipToBounds
import com.tagbardroid.app.ViewContent
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VerticalAlignBottom
import androidx.compose.material.icons.rounded.VerticalAlignTop
import androidx.compose.material3.Icon
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.offset
import com.tagbardroid.app.PlayerMode
import com.tagbardroid.app.library.AllSongsSort
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import kotlinx.coroutines.delay
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tagbardroid.app.CoverScope
import com.tagbardroid.app.InspectorField
import com.tagbardroid.app.MainTab
import com.tagbardroid.app.MainViewModel
import com.tagbardroid.app.Pickers
import com.tagbardroid.app.UiDialog
import com.tagbardroid.app.engine.AlbumGrouping
import com.tagbardroid.app.engine.TrackGainResult
import com.tagbardroid.app.library.AutoNumberOptions
import com.tagbardroid.app.library.LibraryTrack
import com.tagbardroid.app.library.LibraryViewMode
import com.tagbardroid.app.library.NumberingOrder
import com.tagbardroid.app.library.PlaylistEntry
import com.tagbardroid.app.library.PlaylistFormat
import com.tagbardroid.app.library.RenameStatus
import java.util.Locale

// =====================================================================================
// TEMA CLASSIC DARK
// =====================================================================================

internal object Classic {
    /** Diatur oleh [ClassicTheme]; semua warna di bawah ikut berubah saat nilainya berganti. */
    var dark by mutableStateOf(true)

    /** true = mode Dynamic Color: permukaan utama mengikuti [seed] (warna dominan cover). */
    var dynamic by mutableStateOf(false)

    /** Warna dasar Dynamic Color; dianimasikan oleh [ClassicTheme] sehingga berubah mulus. */
    var seed by mutableStateOf(DYNAMIC_NEUTRAL)

    /** Palet turunan [seed]; dihitung ulang sekali per perubahan seed, bukan di setiap pembacaan warna. */
    private val dyn by derivedStateOf { DynamicPalette.from(seed) }

    private fun pick(d: Long, l: Long) = Color(if (dark) d else l)

    // Bingkai jendela dan isi panel (struktur padat ala foobar2000).
    val background get() = if (dynamic) dyn.background else pick(0xFF17181B, 0xFFC3C6CC)
    val panel get() = if (dynamic) dyn.panel else pick(0xFF1F2124, 0xFFFFFFFF)
    val rowAlternate get() = if (dynamic) dyn.rowAlternate else pick(0xFF262A2E, 0xFFF1F4F8)
    val chrome get() = if (dynamic) dyn.chrome else pick(0xFF3B3F45, 0xFFDDE0E5)
    val chromePressed get() = if (dynamic) dyn.chromePressed else pick(0xFF2A2D31, 0xFFC4C8CF)
    val field get() = if (dynamic) dyn.field else pick(0xFF121314, 0xFFFFFFFF)
    val border get() = if (dynamic) dyn.border else pick(0xFF050506, 0xFF7B7F87)
    val borderLight get() = if (dynamic) dyn.borderLight else pick(0xFF5A5F66, 0xFFFFFFFF)
    val grid get() = if (dynamic) dyn.grid else pick(0xFF30343A, 0xFFDADEE4)
    val bevelLight get() = border
    val bevelDark get() = border
    val text get() = pick(0xFFE9ECEF, 0xFF101214)
    val dim get() = pick(0xFF9EA4AC, 0xFF59606A)
    val selection get() = if (dynamic) dyn.selection else pick(0xFF1D3652, 0xFFD3E6F9)

    // Aksen biru iPod Classic.
    val accent get() = Color(0xFF2E83DB)
    val focus get() = accent
    val onAccent = Color.White
    val blue get() = pick(0xFF69AEF2, 0xFF1A60B5)
    val warning get() = pick(0xFFFFB340, 0xFFB86E00)
    val error get() = pick(0xFFFF6A60, 0xFFC4170C)

    // Bahan logam: bagian atas lebih terang, bagian bawah lebih gelap dengan garis belah di tengah (glossy).
    private fun gloss(a: Long, b: Long, c: Long, d: Long) = Brush.verticalGradient(
        0f to Color(a), 0.5f to Color(b), 0.5f to Color(c), 1f to Color(d),
    )

    val metal get() = if (dynamic) dyn.metal else if (dark) {
        gloss(0xFF5C6067, 0xFF474B51, 0xFF393C41, 0xFF2E3135)
    } else {
        gloss(0xFFFFFFFF, 0xFFF1F3F6, 0xFFDEE1E6, 0xFFCED2D8)
    }
    val metalPressed get() = if (dynamic) dyn.metalPressed else if (dark) {
        gloss(0xFF2B2E32, 0xFF33363B, 0xFF3C4046, 0xFF464A50)
    } else {
        gloss(0xFFC2C6CD, 0xFFCDD1D7, 0xFFDADDE2, 0xFFE6E8EC)
    }
    val blueGloss get() = gloss(0xFF7DBCF8, 0xFF3F93E6, 0xFF1F6FCC, 0xFF3A94EB)
    val bluePressed get() = gloss(0xFF2B78D2, 0xFF2F80DA, 0xFF2873CC, 0xFF4A9CEE)

    /** Bilah judul, menu, dan status: gradasi logam halus tanpa garis belah. */
    val bar get() = if (dynamic) dyn.bar else if (dark) {
        Brush.verticalGradient(listOf(Color(0xFF50545B), Color(0xFF2C2F34)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFFF7F8FA), Color(0xFFD1D5DB)))
    }

    private val font = FontFamily.SansSerif
    val body get() = TextStyle(color = text, fontSize = 13.sp, fontFamily = font)
    val small get() = TextStyle(color = dim, fontSize = 11.5.sp, fontFamily = font)
    val heading get() = TextStyle(color = text, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = font)
    val mono get() = TextStyle(
        color = dim, fontSize = 11.5.sp, fontWeight = FontWeight.Medium,
        fontFamily = font, fontFeatureSettings = "tnum",
    )
}

@Composable
fun ClassicTheme(
    mode: ThemeMode = ThemeMode.DARK,
    /** Warna dominan cover yang sedang dipilih/diputar; null = netral. Dipakai hanya di mode Dynamic. */
    dynamicSeed: Color? = null,
    content: @Composable () -> Unit,
) {
    val dynamic = mode == ThemeMode.DYNAMIC
    val dark = mode != ThemeMode.LIGHT
    // Transisi warna 600 ms: latar utama dan Floating Player berganti halus saat lagu/cover berubah.
    val animatedSeed by animateColorAsState(
        targetValue = if (dynamic) dynamicSeed ?: DYNAMIC_NEUTRAL else DYNAMIC_NEUTRAL,
        animationSpec = tween(DYNAMIC_COLOR_MS, easing = FastOutSlowInEasing),
        label = "dynamic-seed",
    )
    Classic.dark = dark
    Classic.dynamic = dynamic
    Classic.seed = animatedSeed
    val scheme = if (dark) {
        darkColorScheme(
            primary = Classic.accent, secondary = Classic.accent, background = Classic.background,
            surface = Classic.panel, surfaceContainer = Classic.chrome,
            onBackground = Classic.text, onSurface = Classic.text,
        )
    } else {
        lightColorScheme(
            primary = Classic.accent, secondary = Classic.accent, background = Classic.background,
            surface = Classic.panel, surfaceContainer = Classic.chrome,
            onBackground = Classic.text, onSurface = Classic.text,
        )
    }
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(2.dp),
            small = RoundedCornerShape(3.dp),
            medium = RoundedCornerShape(5.dp),
            large = RoundedCornerShape(6.dp),
            extraLarge = RoundedCornerShape(8.dp),
        ),
        content = content,
    )
}

private const val DYNAMIC_COLOR_MS = 600

/** Warna dasar saat belum ada cover: menghasilkan permukaan gelap netral yang mirip tema Gelap. */
internal val DYNAMIC_NEUTRAL = Color(0xFF30343A)

/**
 * Seluruh warna permukaan mode Dynamic, diturunkan dari satu warna dasar. Hanya kecerahan yang diatur
 * tetap (selalu gelap, supaya teks terang tetap terbaca); rona dan kejenuhan mengikuti cover, dengan
 * kejenuhan dibatasi agar latar tidak terlalu mencolok.
 */
private class DynamicPalette private constructor(private val hue: Float, private val sat: Float) {
    private fun tone(v: Float, satScale: Float = 1f): Color =
        Color.hsv(hue, (sat * satScale).coerceIn(0f, 1f), v.coerceIn(0f, 1f))

    val background = tone(0.14f)
    val panel = tone(0.19f)
    val rowAlternate = tone(0.23f)
    val chrome = tone(0.29f)
    val chromePressed = tone(0.22f)
    val field = tone(0.11f)
    val border = tone(0.05f)
    val borderLight = tone(0.42f, 0.7f)
    val grid = tone(0.27f)
    val selection = tone(0.40f, 1.15f)

    private fun gloss(a: Float, b: Float, c: Float, d: Float) = Brush.verticalGradient(
        0f to tone(a, 0.8f), 0.5f to tone(b, 0.8f), 0.5f to tone(c, 0.8f), 1f to tone(d, 0.8f),
    )

    val metal = gloss(0.40f, 0.32f, 0.26f, 0.21f)
    val metalPressed = gloss(0.18f, 0.22f, 0.26f, 0.31f)
    val bar = Brush.verticalGradient(listOf(tone(0.34f, 0.8f), tone(0.19f, 0.8f)))

    companion object {
        fun from(seed: Color): DynamicPalette {
            val hsv = FloatArray(3)
            android.graphics.Color.colorToHSV(seed.toArgb(), hsv)
            return DynamicPalette(hsv[0], (hsv[1] * 0.7f).coerceAtMost(0.55f))
        }
    }
}

/** Gaya lama bergaya bevel dihapus; dipertahankan sebagai no-op agar pemanggilnya tetap valid. */
@Suppress("UnusedReceiverParameter")
private fun Modifier.bevel(sunken: Boolean = false): Modifier = this

/** Garis pemisah tipis 1dp, dipakai untuk batas panel, kolom tabel, dan bilah. */
private fun Modifier.bottomLine(color: Color): Modifier = drawBehind {
    val w = 1.dp.toPx()
    drawRect(color, topLeft = Offset(0f, size.height - w), size = Size(size.width, w))
}

private fun Modifier.topLine(color: Color): Modifier = drawBehind {
    drawRect(color, topLeft = Offset(0f, 0f), size = Size(size.width, 1.dp.toPx()))
}

private fun Modifier.rightLine(color: Color): Modifier = drawBehind {
    val w = 1.dp.toPx()
    drawRect(color, topLeft = Offset(size.width - w, 0f), size = Size(w, size.height))
}

private fun Modifier.leftLine(color: Color): Modifier = drawBehind {
    drawRect(color, topLeft = Offset(0f, 0f), size = Size(1.dp.toPx(), size.height))
}

// =====================================================================================
// KOMPONEN DASAR
// =====================================================================================

@Composable
private fun Label(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = Classic.body,
    maxLines: Int = 1,
    align: TextAlign? = null,
) {
    Text(
        text = text,
        modifier = modifier,
        style = if (align == null) style else style.copy(textAlign = align),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}

private val ButtonShape = RoundedCornerShape(5.dp)
private val FieldShape = RoundedCornerShape(3.dp)

/** Tombol logam glossy; bila [active] berubah menjadi biru iPod. Teks boleh kosong untuk tombol ikon. */
@Composable
private fun ClassicButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    active: Boolean = false,
    icon: ImageVector? = null,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val brush = when {
        active && pressed -> Classic.bluePressed
        active -> Classic.blueGloss
        pressed -> Classic.metalPressed
        else -> Classic.metal
    }
    val foreground = when {
        !enabled -> Classic.dim
        active -> Classic.onAccent
        else -> Classic.text
    }
    Row(
        modifier = modifier
            .heightIn(min = 34.dp)
            .widthIn(min = 34.dp)
            .clip(ButtonShape)
            .background(brush)
            .border(1.dp, Brush.verticalGradient(listOf(Classic.borderLight, Classic.border)), ButtonShape)
            .clickable(interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
    ) {
        if (icon != null) Icon(icon, contentDescription = text.ifEmpty { null }, tint = foreground, modifier = Modifier.size(16.dp))
        if (text.isNotEmpty()) {
            Label(text, style = Classic.body.copy(color = foreground, fontWeight = FontWeight.Medium))
        }
    }
}

/** Tab ala jendela desktop: tab aktif menyatu dengan panel dan diberi garis biru di atasnya. */
@Composable
private fun ClassicTab(text: String, active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp)
    Box(
        modifier = modifier
            .height(34.dp)
            .clip(shape)
            .then(if (active) Modifier.background(Classic.background) else Modifier.background(Classic.metal))
            .border(1.dp, Classic.border, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        if (active) {
            Box(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(3.dp).background(Classic.blueGloss))
        }
        Label(
            text,
            style = Classic.body.copy(
                color = if (active) Classic.text else Classic.dim,
                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            ),
        )
    }
}

/** Sakelar tema: Terang → Gelap → Dynamic Color → Terang. Ikonnya menunjukkan mode yang aktif. */
@Composable
private fun ThemeSwitch(mode: ThemeMode, onToggle: () -> Unit) {
    ClassicButton(
        "", onToggle,
        Modifier.padding(horizontal = 2.dp),
        icon = when (mode) {
            ThemeMode.LIGHT -> Icons.Rounded.LightMode
            ThemeMode.DARK -> Icons.Rounded.DarkMode
            ThemeMode.DYNAMIC -> Icons.Rounded.Palette
        },
    )
}

/** Kotak centang persegi ala Windows; saat tercentang berisi biru glossy. */
@Composable
private fun CheckSquare(checked: Boolean) {
    val shape = RoundedCornerShape(2.dp)
    Box(
        modifier = Modifier
            .size(16.dp)
            .clip(shape)
            .then(if (checked) Modifier.background(Classic.blueGloss) else Modifier.background(Classic.field))
            .border(1.dp, if (checked) Classic.border else Classic.dim, shape),
        contentAlignment = Alignment.Center,
    ) {
        if (checked) Icon(Icons.Rounded.Check, contentDescription = null, tint = Classic.onAccent, modifier = Modifier.size(12.dp))
    }
}

@Composable
private fun CheckLine(text: String, checked: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = 40.dp).clickable(onClick = onToggle),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        CheckSquare(checked)
        Label(text, maxLines = 2)
    }
}

@Composable
private fun ClassicField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    enabled: Boolean = true,
    numeric: Boolean = false,
    highlighted: Boolean = false,
    leading: ImageVector? = null,
) {
    val style = Classic.body.copy(
        color = if (highlighted) Classic.warning else Classic.text,
        fontFamily = if (numeric) FontFamily.Monospace else FontFamily.SansSerif,
    )
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        enabled = enabled,
        singleLine = true,
        textStyle = style,
        cursorBrush = SolidColor(Classic.accent),
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text),
        modifier = modifier,
        decorationBox = { inner ->
            Row(
                modifier = Modifier
                    .heightIn(min = 34.dp)
                    .clip(FieldShape)
                    .background(Classic.field)
                    .border(1.dp, Brush.verticalGradient(listOf(Classic.border, Classic.borderLight)), FieldShape)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                if (leading != null) Icon(leading, contentDescription = null, tint = Classic.dim, modifier = Modifier.size(16.dp))
                Box(contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Label(placeholder, style = Classic.body.copy(color = Classic.dim))
                    inner()
                }
            }
        },
    )
}

/** Bilah judul panel dan jendela dialog. */
@Composable
private fun PanelTitle(text: String, modifier: Modifier = Modifier, onFloat: (() -> Unit)? = null) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(if (onFloat == null) 28.dp else 38.dp)
            .background(Classic.bar)
            .bottomLine(Classic.border)
            .padding(start = 10.dp, end = if (onFloat == null) 10.dp else 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Label(text, Modifier.weight(1f), Classic.heading.copy(fontSize = 12.5.sp))
        if (onFloat != null) {
            ClassicButton("Jendela", onFloat, icon = Icons.Rounded.PictureInPictureAlt)
        }
    }
}

// =====================================================================================
// LAYAR UTAMA
// =====================================================================================

@Composable
fun MainScreen(vm: MainViewModel, pickers: Pickers) {
    val state = vm.state
    val content = vm.viewContent()
    var inspectorFocused by remember { mutableStateOf(false) }

    val pick = vm.pickerContent()
    BackHandler(enabled = state.tab == MainTab.PLAYLIST || content.canGoUp) {
        if (state.tab == MainTab.PLAYLIST) {
            // Di ruang kerja Playlist, Back lebih dulu keluar dari folder/album sumber lagu.
            if (pick.canGoUp) vm.pickGoUp() else vm.setTab(MainTab.LIBRARY)
        } else {
            vm.goUp()
        }
    }

    // Back lebih dulu mengembalikan jendela yang sedang diperbesar.
    val maximized = vm.desktop.active?.takeIf { vm.desktop.window(it).maximized }
    BackHandler(enabled = maximized != null) {
        maximized?.let { vm.desktop.toggleMaximize(it) }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Classic.background)
            .windowInsetsPadding(WindowInsets.safeDrawing),
    ) {
    Column(Modifier.fillMaxSize()) {
        MenuBar(vm, pickers)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val wide = maxWidth >= 720.dp
                val keyboardOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
                // Di tab Playlist inspector disembunyikan supaya ruang kerja memakai seluruh layar.
                val showInspector = state.inspectorVisible && state.tab != MainTab.PLAYLIST
                if (wide) {
                    Row(Modifier.fillMaxSize()) {
                        AnimatedVisibility(
                            visible = showInspector,
                            enter = expandHorizontally(tween(INSPECTOR_MS), expandFrom = Alignment.End) +
                                fadeIn(tween(INSPECTOR_MS)),
                            exit = shrinkHorizontally(tween(INSPECTOR_MS), shrinkTowards = Alignment.End) +
                                fadeOut(tween(INSPECTOR_MS)),
                        ) {
                            Inspector(vm, Modifier.width(300.dp).fillMaxHeight(), horizontalCover = false) {}
                        }
                        MainPanel(vm, pickers, Modifier.weight(1f).fillMaxHeight())
                    }
                } else {
                    // Saat keyboard terbuka untuk mengedit tag, inspector memakai seluruh ruang.
                    val editing = showInspector && inspectorFocused && keyboardOpen
                    val inspectorHeight = if (editing) maxHeight else maxHeight * 0.46f
                    Column(Modifier.fillMaxSize()) {
                        // Slide-up: tepi bawah isi ikut naik saat tingginya menyusut, dan panel di
                        // bawahnya melebar mengisi ruang yang ditinggalkan.
                        AnimatedVisibility(
                            visible = showInspector,
                            enter = expandVertically(tween(INSPECTOR_MS), expandFrom = Alignment.Bottom) +
                                fadeIn(tween(INSPECTOR_MS)),
                            exit = shrinkVertically(tween(INSPECTOR_MS), shrinkTowards = Alignment.Bottom) +
                                fadeOut(tween(INSPECTOR_MS)),
                        ) {
                            Inspector(
                                vm,
                                Modifier.fillMaxWidth().height(inspectorHeight),
                                horizontalCover = true,
                            ) { inspectorFocused = it }
                        }
                        if (!editing) {
                            MainPanel(vm, pickers, Modifier.fillMaxWidth().weight(1f))
                        }
                    }
                }
            }
            FloatingDesktop(vm, pickers)
        }
        WindowTaskbar(vm.desktop)
        StatusBar(vm)
    }
    MiniPlayer(vm)
    }

    Dialogs(vm, pickers)
}

// =====================================================================================
// MENU BAR
// =====================================================================================

private class MenuAction(
    val label: String,
    val enabled: Boolean = true,
    val separatorBefore: Boolean = false,
    val run: () -> Unit,
)

@Composable
private fun MenuBar(vm: MainViewModel, pickers: Pickers) {
    val state = vm.state
    val loaded = state.snapshot != null
    val inPlaylist = state.tab == MainTab.PLAYLIST
    fun mark(on: Boolean) = if (on) "✓ " else "    "

    val menus: List<Pair<String, List<MenuAction>>> = listOf(
        "File" to listOf(
            MenuAction("Buka Folder...") { pickers.openLibrary() },
            MenuAction("Pindai Ulang", loaded) { vm.rescan(force = false) },
            MenuAction("Pindai Ulang Penuh", loaded) { vm.rescan(force = true) },
            MenuAction("Pulihkan Cadangan...", separatorBefore = true) { vm.showRecoveries() },
            MenuAction("Keluar", separatorBefore = true) { pickers.exit() },
        ),
        "Edit" to listOf(
            MenuAction("Pilih Semua", loaded) { vm.selectAll() },
            MenuAction("Batal Pilih", loaded) { vm.selectNone() },
            MenuAction("Balik Pilihan", loaded) { vm.invertSelection() },
            MenuAction("Simpan Tag", state.inspector.isDirty, separatorBefore = true) { vm.saveTags() },
            MenuAction("Batalkan Perubahan", state.inspector.isDirty) { vm.revertTags() },
            MenuAction("Sampul Album...", loaded, separatorBefore = true) { vm.showCoverOptions() },
        ),
        "ReplayGain" to listOf(
            MenuAction("Scan Per Track", loaded) { vm.scanReplayGain(AlbumGrouping.TRACK_ONLY) },
            MenuAction("Scan Per Album (tag)", loaded) { vm.scanReplayGain(AlbumGrouping.BY_TAGS) },
            MenuAction("Scan Per Album (folder)", loaded) { vm.scanReplayGain(AlbumGrouping.BY_FOLDER) },
            MenuAction("Pilihan sebagai 1 Album", loaded) { vm.scanReplayGain(AlbumGrouping.SINGLE_ALBUM) },
            MenuAction(mark(state.truePeak) + "Gunakan True Peak", separatorBefore = true) { vm.toggleTruePeak() },
            MenuAction("Hapus Tag ReplayGain", loaded, separatorBefore = true) { vm.confirmRemoveReplayGain() },
        ),
        "Playlist" to listOf(
            MenuAction("Tambah Terpilih", loaded && !inPlaylist) { vm.addToPlaylist() },
            MenuAction("Playlist Baru") { vm.newPlaylist() },
            MenuAction("Jendela Susunan Playlist", separatorBefore = true) { vm.desktop.open(PanelId.PLAYLIST) },
            MenuAction("Jendela Sumber Lagu") { vm.desktop.open(PanelId.SOURCE) },
            MenuAction("Import M3U/M3U8...", loaded) { pickers.openPlaylist() },
            MenuAction("Export M3U8...", loaded, separatorBefore = true) { vm.showExport(PlaylistFormat.M3U8) },
            MenuAction("Export M3U...", loaded) { vm.showExport(PlaylistFormat.M3U) },
            MenuAction("Geser Naik", loaded, separatorBefore = true) { vm.moveSelection(-1) },
            MenuAction("Geser Turun", loaded) { vm.moveSelection(1) },
            MenuAction("Acak Urutan Playlist", state.playlist.entries.size > 1) { vm.shufflePlaylist() },
            MenuAction("Ke Paling Atas", inPlaylist) { vm.moveSelectionToEdge(top = true) },
            MenuAction("Ke Paling Bawah", inPlaylist) { vm.moveSelectionToEdge(top = false) },
            MenuAction("Hapus dari Daftar", inPlaylist) { vm.removeFromPlaylist() },
        ),
        "Bantuan" to listOf(
            MenuAction("Tentang Aplikasi") { vm.showAbout() },
        ),
        "Tools" to listOf(
            MenuAction("Auto-Numbering...", loaded) { vm.showAutoNumber() },
            MenuAction("Filename to Tag...", loaded) { vm.showFilenameToTag() },
            MenuAction("Tag to Filename...", loaded) { vm.showTagToFilename() },
            MenuAction(mark(state.inspectorVisible) + "Panel Inspector", separatorBefore = true) {
                vm.toggleInspector()
            },
            MenuAction(mark(state.autoTechColumns) + "Muat Codec & RG Otomatis") { vm.toggleAutoTech() },
            MenuAction(mark(state.themeMode == ThemeMode.LIGHT) + "Tema Terang", separatorBefore = true) { vm.setThemeMode(ThemeMode.LIGHT) },
            MenuAction(mark(state.themeMode == ThemeMode.DARK) + "Tema Gelap") { vm.setThemeMode(ThemeMode.DARK) },
            MenuAction(mark(state.themeMode == ThemeMode.DYNAMIC) + "Dynamic Color (ikut cover)") { vm.setThemeMode(ThemeMode.DYNAMIC) },
        ),
    )

    var open by remember { mutableStateOf<String?>(null) }
    Row(
        modifier = Modifier.fillMaxWidth().background(Classic.bar).bottomLine(Classic.border).padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
            menus.forEach { (name, actions) ->
                Box {
                    val isOpen = open == name
                    Box(
                        modifier = Modifier
                            .height(36.dp)
                            .then(if (isOpen) Modifier.background(Classic.blueGloss) else Modifier)
                            .clickable { open = name }
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Label(name, style = Classic.body.copy(color = if (isOpen) Classic.onAccent else Classic.text))
                    }
                    DropdownMenu(
                        expanded = isOpen,
                        onDismissRequest = { open = null },
                        modifier = Modifier.background(Classic.panel).border(1.dp, Classic.border),
                        shape = RoundedCornerShape(2.dp),
                    ) {
                        actions.forEach { action ->
                            if (action.separatorBefore) {
                                Box(Modifier.fillMaxWidth().height(1.dp).background(Classic.grid))
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 36.dp)
                                    .clickable(enabled = action.enabled) {
                                        open = null
                                        action.run()
                                    }
                                    .padding(horizontal = 16.dp),
                                contentAlignment = Alignment.CenterStart,
                            ) {
                                Label(
                                    action.label,
                                    style = Classic.body.copy(color = if (action.enabled) Classic.text else Classic.dim),
                                )
                            }
                        }
                    }
                }
            }
        }
        // Sisi kanan: pemutar, sakelar tema, About.
        ClassicButton(
            "", { vm.setPlayerMode(PlayerMode.EXPANDED) },
            enabled = vm.player.current != null, icon = Icons.Rounded.MusicNote,
        )
        ThemeSwitch(state.themeMode) { vm.toggleTheme() }
        ClassicButton("", { vm.showAbout() }, icon = Icons.Rounded.Info)
    }
}

/** Bilah status ala foobar2000: sel-sel dipisah garis tegas. */
@Composable
private fun StatusBar(vm: MainViewModel) {
    val state = vm.state
    val selected = if (state.tab == MainTab.LIBRARY) state.checked.size else state.playlistChecked.size
    Row(
        modifier = Modifier.fillMaxWidth().height(26.dp).background(Classic.bar).topLine(Classic.border),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Label(state.status, Modifier.weight(1f).padding(horizontal = 10.dp), Classic.small)
        StatusCell("Pilih: $selected")
        StatusCell(if (state.truePeak) "TP" else "SP")
    }
}

@Composable
private fun StatusCell(text: String) {
    Box(
        modifier = Modifier.fillMaxHeight().leftLine(Classic.border).padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Label(text, style = Classic.mono)
    }
}

// =====================================================================================
// INSPECTOR (gaya Mp3tag)
// =====================================================================================

@Composable
private fun Inspector(
    vm: MainViewModel,
    modifier: Modifier,
    horizontalCover: Boolean,
    onFocusChange: (Boolean) -> Unit,
) {
    val inspector = vm.state.inspector
    DisposableEffect(Unit) { onDispose { onFocusChange(false) } }

    Column(
        modifier = modifier
            .padding(2.dp)
            .border(1.dp, Classic.border)
            .background(Classic.panel)
            .onFocusChanged { onFocusChange(it.hasFocus) },
    ) {
        val title = when {
            inspector.ids.isEmpty() -> "Tag Inspector"
            inspector.isBatch -> "Edit massal: ${inspector.ids.size} lagu"
            else -> inspector.anchor?.item?.displayName.orEmpty()
        }
        PanelTitle(title)
        // Tombol simpan selalu terlihat, tidak ikut tergulung.
        Row(
            modifier = Modifier.fillMaxWidth().padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            ClassicButton("Simpan Tag", { vm.saveTags() }, Modifier.weight(1f), enabled = inspector.isDirty)
            ClassicButton("Batal", { vm.revertTags() }, enabled = inspector.isDirty)
            ClassicButton("Sampul", { vm.showCoverOptions() }, enabled = inspector.ids.isNotEmpty())
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (inspector.ids.isEmpty()) {
                Label("Sorot atau centang lagu untuk melihat tag.", style = Classic.small, maxLines = 3)
            } else {
                if (horizontalCover) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CoverBox(vm, 112.dp)
                        TechnicalInfo(vm, Modifier.weight(1f))
                    }
                } else {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { CoverBox(vm, 220.dp) }
                    TechnicalInfo(vm, Modifier.fillMaxWidth())
                }
                inspector.error?.let { Label(it, style = Classic.body.copy(color = Classic.error), maxLines = 4) }
                InspectorField.entries.forEach { field -> TagRow(vm, field) }
                if (inspector.isBatch) {
                    Label(
                        "Title dan Track dikunci saat edit massal. Gunakan menu Tools.",
                        style = Classic.small,
                        maxLines = 3,
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun TagRow(vm: MainViewModel, field: InspectorField) {
    val inspector = vm.state.inspector
    // targets() hanya dipakai di baseValue, jadi diingat selama seleksi tidak berubah.
    val base = remember(inspector.ids, inspector.metadata, vm.state.snapshot, field) { vm.baseValue(field) }
    val edited = inspector.draft[field]
    val locked = inspector.isBatch && (field == InspectorField.TITLE || field == InspectorField.TRACK)
    val ready = inspector.isBatch || inspector.metadata != null
    Row(verticalAlignment = Alignment.CenterVertically) {
        Label(field.label, Modifier.width(86.dp), Classic.small)
        ClassicField(
            value = edited ?: base.orEmpty(),
            onValueChange = { vm.editField(field, it) },
            modifier = Modifier.weight(1f),
            placeholder = when {
                !ready -> if (inspector.loading) "memuat..." else ""
                base == null && inspector.isBatch -> "<tetap>"
                else -> ""
            },
            enabled = ready && !locked,
            numeric = field.numeric,
            highlighted = edited != null,
        )
    }
}

@Composable
private fun CoverBox(vm: MainViewModel, side: Dp) {
    val inspector = vm.state.inspector
    Box(
        modifier = Modifier
            .size(side)
            .background(Classic.field)
            .border(1.dp, Classic.border)
            .clickable { vm.showCoverOptions() }
            .padding(3.dp),
        contentAlignment = Alignment.Center,
    ) {
        val cover = inspector.cover
        if (cover != null) {
            Image(
                bitmap = cover,
                contentDescription = "Sampul album, ketuk untuk mengganti",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit,
            )
        } else {
            Label(
                if (inspector.loading) "memuat..." else "Tanpa sampul\nketuk untuk ganti",
                style = Classic.small,
                maxLines = 3,
                align = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun TechnicalInfo(vm: MainViewModel, modifier: Modifier) {
    val inspector = vm.state.inspector
    val m = inspector.metadata
    Column(
        modifier = modifier
            .background(Classic.field)
            .border(1.dp, Classic.border)
            .padding(6.dp),
    ) {
        if (inspector.isBatch) {
            Label("Info lagu acuan:", style = Classic.small)
            Label(inspector.anchor?.item?.displayName.orEmpty(), style = Classic.small)
        }
        fun show(value: String?, unit: String = "") = if (value.isNullOrBlank()) "-" else value + unit
        InfoLine("Codec", show(m?.codec))
        InfoLine("Rate", show(m?.sampleRate, " Hz"))
        InfoLine("Bit", show(m?.bitDepth, "-bit"))
        InfoLine("Bitrate", show(m?.bitrate, " kbps"))
        InfoLine("Durasi", m?.let { formatDuration(it.durationSeconds.toLong()) } ?: "-")
        InfoLine("Trk Gain", show(m?.replayGain?.trackGain))
        InfoLine("Trk Peak", show(m?.replayGain?.trackPeak))
        InfoLine("Alb Gain", show(m?.replayGain?.albumGain))
        InfoLine("Alb Peak", show(m?.replayGain?.albumPeak))
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row {
        Label(label, Modifier.width(64.dp), Classic.small)
        Label(value, style = Classic.mono)
    }
}

private fun formatDuration(seconds: Long): String {
    if (seconds < 0) return "-"
    val h = seconds / 3600
    val m = seconds / 60 % 60
    val s = seconds % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%d:%02d", m, s)
}

// =====================================================================================
// PANEL UTAMA: TABEL
// =====================================================================================

private val CHECK_WIDTH = 36.dp
private val ACTION_WIDTH = 100.dp
private val NUMBER_WIDTH = 44.dp
private val TITLE_WIDTH = 190.dp
private val ARTIST_WIDTH = 130.dp
private val ALBUM_WIDTH = 140.dp
private val GENRE_WIDTH = 90.dp
private val CODEC_WIDTH = 62.dp
private val GAIN_WIDTH = 78.dp
private val FIXED_WIDTH = CHECK_WIDTH + ACTION_WIDTH + NUMBER_WIDTH + ARTIST_WIDTH + ALBUM_WIDTH +
    GENRE_WIDTH + CODEC_WIDTH + GAIN_WIDTH
private val ROW_HEIGHT = 34.dp
private const val TECH_DELAY_MS = 350L

// -------------------------------------------------------------------------------------
// Animasi slide antar-tab, antar-mode, dan masuk/keluar folder
// -------------------------------------------------------------------------------------

private const val SLIDE_STIFFNESS = 420f
private const val SLIDE_FADE_IN_MS = 260
private const val SLIDE_FADE_OUT_MS = 140
/** Ease-out kuat (easeOutQuart): cepat di awal, melambat halus di akhir. */
private val EaseOutCurve = CubicBezierEasing(0.25f, 1f, 0.5f, 1f)
private const val INSPECTOR_MS = 280

/** Kunci navigasi sebuah layar daftar; perubahan kunci memicu animasi geser. */
private data class NavKey(val tab: MainTab, val mode: LibraryViewMode, val depth: Int, val id: String)

/** Kunci navigasi + isi daftar saat itu, supaya layar yang sedang keluar tetap menampilkan isi lamanya. */
private data class Screen(val key: NavKey, val content: ViewContent)

private val LIBRARY_MODE_ORDER = listOf(
    LibraryViewMode.FOLDER, LibraryViewMode.ALL, LibraryViewMode.ALBUM, LibraryViewMode.ARTIST, LibraryViewMode.GENRE,
)
private val PICKER_MODE_ORDER = listOf(LibraryViewMode.FOLDER, LibraryViewMode.ALBUM, LibraryViewMode.ALL)

private fun folderDepth(path: String): Int = if (path.isEmpty()) 0 else path.count { it == '/' } + 1

private fun navKey(tab: MainTab, mode: LibraryViewMode, path: String, groupKey: String?): NavKey =
    if (mode == LibraryViewMode.FOLDER) NavKey(tab, mode, folderDepth(path), path)
    else NavKey(tab, mode, if (groupKey == null) 0 else 1, groupKey.orEmpty())

/** Pindah ke tab/mode yang lebih kanan, atau masuk lebih dalam ke folder = maju (geser ke kiri). */
private fun isForward(from: NavKey, to: NavKey, order: List<LibraryViewMode>): Boolean =
    if (from.tab != to.tab || from.mode != to.mode) {
        val a = from.tab.ordinal * 100 + order.indexOf(from.mode)
        val b = to.tab.ordinal * 100 + order.indexOf(to.mode)
        b > a
    } else {
        to.depth >= from.depth
    }

/**
 * Perpindahan halaman: layar baru meluncur masuk dengan pegas teredam kritis (tanpa pantulan, tetap
 * mulus walau dipotong di tengah jalan karena kecepatan gesernya diteruskan), layar lama bergeser
 * sedikit ke sisi berlawanan sambil memudar. Geser hanya sepertiga lebar layar supaya lebih ringan
 * digambar, sehingga tetap 60 fps walau daftar lagunya panjang. Ukuran tidak dianimasikan.
 */
private fun <S> AnimatedContentTransitionScope<S>.slideBetween(forward: Boolean): ContentTransform {
    val sign = if (forward) 1 else -1
    val slideSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = SLIDE_STIFFNESS,
        visibilityThreshold = IntOffset.VisibilityThreshold,
    )
    val enter = slideInHorizontally(slideSpec) { full -> sign * full / 3 } +
        fadeIn(tween(SLIDE_FADE_IN_MS, easing = EaseOutCurve))
    val exit = slideOutHorizontally(slideSpec) { full -> -sign * full / 4 } +
        fadeOut(tween(SLIDE_FADE_OUT_MS, easing = EaseOutCurve))
    return ContentTransform(
        targetContentEnter = enter,
        initialContentExit = exit,
        sizeTransform = SizeTransform(clip = true) { _, _ -> snap() },
    )
}

@Composable
private fun MainPanel(vm: MainViewModel, pickers: Pickers, modifier: Modifier) {
    val state = vm.state
    Column(modifier.padding(2.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            ClassicTab("Library", state.tab == MainTab.LIBRARY, { vm.setTab(MainTab.LIBRARY) })
            val mark = if (state.playlistDirty) " *" else ""
            ClassicTab(
                "${state.playlist.name} (${state.playlist.entries.size})$mark",
                state.tab == MainTab.PLAYLIST,
                { vm.setTab(MainTab.PLAYLIST) },
                Modifier.widthIn(max = 240.dp),
            )
        }
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(1.dp, Classic.border)
                .background(Classic.background)
                .padding(4.dp),
        ) {
            AnimatedContent(
                targetState = state.tab,
                modifier = Modifier.weight(1f).fillMaxWidth().clipToBounds(),
                transitionSpec = { slideBetween(targetState.ordinal > initialState.ordinal) },
                label = "main-tab",
            ) { tab ->
                if (tab == MainTab.LIBRARY) {
                    Column(Modifier.fillMaxSize()) {
                        ActionToolbar(vm, pickers)
                        LibraryPanel(vm, pickers, Modifier.weight(1f))
                    }
                } else {
                    PlaylistWorkspace(vm, pickers, Modifier.fillMaxSize())
                }
            }
        }
    }
}

/** Toolbar tab Library. Semua urusan menyusun playlist pindah ke ruang kerja Playlist. */
@Composable
private fun ActionToolbar(vm: MainViewModel, pickers: Pickers) {
    val state = vm.state
    val loaded = state.snapshot != null
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        ClassicButton("Putar", { vm.playSelected() }, enabled = loaded, active = vm.player.isPlaying, icon = Icons.Rounded.PlayArrow)
        ClassicButton("", { vm.moveSelection(-1) }, enabled = loaded, icon = Icons.Rounded.KeyboardArrowUp)
        ClassicButton("", { vm.moveSelection(1) }, enabled = loaded, icon = Icons.Rounded.KeyboardArrowDown)
        ClassicButton("Semua", { vm.selectAll() }, enabled = loaded)
        ClassicButton("Kosongkan", { vm.selectNone() }, enabled = loaded)
        // Aktif hanya bila ada lagu yang dicentang; memasukkan semuanya ke playlist sekali klik.
        val checkedCount = state.checked.size
        ClassicButton(
            if (checkedCount > 0) "+ Tambah Terpilih ke Playlist ($checkedCount)" else "+ Tambah Terpilih ke Playlist",
            { vm.addCheckedToPlaylist() },
            enabled = loaded && checkedCount > 0,
            active = checkedCount > 0,
            icon = Icons.Rounded.Add,
        )
        ClassicButton("Playlist", { vm.setTab(MainTab.PLAYLIST) }, icon = Icons.Rounded.LibraryMusic)
        // Satu-satunya jalan pindai ulang selain mengganti folder: daftar lagu selalu dari cache.
        ClassicButton("Rescan", { vm.rescan(force = false) }, enabled = loaded, icon = Icons.Rounded.Refresh)
    }
}

@Composable
private fun LibraryPanel(vm: MainViewModel, pickers: Pickers, modifier: Modifier) {
    val state = vm.state
    val content = vm.viewContent()
    Column(modifier) {
        if (state.snapshot == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                ClassicButton("Buka Folder Musik...", { pickers.openLibrary() }, icon = Icons.Rounded.Folder)
            }
        } else {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                listOf(
                    LibraryViewMode.FOLDER to "Folder",
                    LibraryViewMode.ALL to "All Songs",
                    LibraryViewMode.ALBUM to "Album",
                    LibraryViewMode.ARTIST to "Artist",
                    LibraryViewMode.GENRE to "Genre",
                ).forEach { (mode, label) ->
                    ClassicButton(label, { vm.setViewMode(mode) }, active = state.viewMode == mode)
                }
            }
            // Pencarian real-time: nama folder dan lagu.
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                ClassicField(
                    state.query, { vm.setQuery(it) }, Modifier.weight(1f),
                    placeholder = "Cari folder atau lagu", leading = Icons.Rounded.Search,
                )
                if (state.query.isNotEmpty()) ClassicButton("", { vm.setQuery("") }, icon = Icons.Rounded.Close)
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                if (content.canGoUp) ClassicButton("", { vm.goUp() }, icon = Icons.Rounded.ArrowUpward)
                Label(content.title, Modifier.weight(1f).padding(horizontal = 4.dp), Classic.heading.copy(fontSize = 14.sp))
                if (state.viewMode == LibraryViewMode.ALL) {
                    ClassicButton(
                        "No. Trek", { vm.setAllSort(AllSongsSort.TRACK_NUMBER) },
                        active = state.allSort == AllSongsSort.TRACK_NUMBER,
                    )
                    ClassicButton(
                        "Acak", { vm.setAllSort(AllSongsSort.SHUFFLE) },
                        active = state.allSort == AllSongsSort.SHUFFLE,
                    )
                }
            }

            val screen = Screen(navKey(MainTab.LIBRARY, state.viewMode, state.browser.path, state.groupKey), content)
            AnimatedContent(
                targetState = screen,
                modifier = Modifier.weight(1f).fillMaxWidth().clipToBounds(),
                contentKey = { it.key },
                transitionSpec = { slideBetween(isForward(initialState.key, targetState.key, LIBRARY_MODE_ORDER)) },
                label = "library-nav",
            ) { shown ->
                val c = shown.content
                TrackTable(Modifier.fillMaxSize()) { width ->
                    if (c.canGoUp && shown.key.mode == LibraryViewMode.FOLDER) {
                        item(key = "up") {
                            BrowserRow(width, "..", "Naik satu folder", Classic.dim, Icons.Rounded.ArrowUpward) { vm.goUp() }
                        }
                    }
                    items(c.folders, key = { "f:" + it.documentId }) { folder ->
                        BrowserRow(width, folder.name, "", Classic.text, Icons.Rounded.Folder) { vm.openFolder(folder) }
                    }
                    items(c.playlists, key = { "p:" + it.documentId }) { file ->
                        BrowserRow(width, file.name, "ketuk untuk membuka", Classic.blue, Icons.Rounded.LibraryMusic) {
                            vm.requestImport { vm.importPlaylist(file.uri) }
                        }
                    }
                    items(c.groups, key = { "g:" + it.key }) { group ->
                        val detail = if (shown.key.mode == LibraryViewMode.ALBUM) {
                            "${group.subtitle}  [${group.tracks.size} lagu]"
                        } else {
                            group.subtitle
                        }
                        BrowserRow(width, group.title, detail, Classic.text, Icons.Rounded.Folder) { vm.openGroup(group) }
                    }
                    itemsIndexed(
                        c.tracks,
                        key = { _, track -> "t:" + track.documentId },
                        contentType = { _, _ -> "track" },
                    ) { index, track ->
                        val focused = track.documentId == state.focusedId
                        TrackRow(
                            vm = vm,
                            width = width,
                            index = index,
                            track = track,
                            number = track.tags.trackNumber?.toString()?.padStart(2, '0').orEmpty(),
                            checked = track.documentId in state.checked,
                            focused = focused,
                            onClick = { vm.focusTrack(track) },
                            onToggle = { vm.toggleTrack(track) },
                            onPlay = { vm.playTrack(track) },
                            actions = { tint ->
                                // Tambah langsung dari daftar, tanpa harus memutar lagunya.
                                RowAction(Icons.Rounded.PlayArrow, "Putar", tint) { vm.playTrack(track) }
                                RowAction(Icons.Rounded.Add, "Tambah ke playlist", tint) { vm.addTrackToPlaylist(track) }
                            },
                        )
                    }
                    if (c.tracks.isEmpty() && c.folders.isEmpty() && c.groups.isEmpty() && c.playlists.isEmpty()) {
                        item(key = "empty") { BrowserRow(width, "(kosong)", "", Classic.dim) {} }
                    }
                }
            }
        }
    }
}

/**
 * Ruang kerja penyusun playlist: area atas untuk menjelajah sumber lagu (Folder / Album / All Songs
 * dengan pencarian sendiri), area bawah untuk menyusun urutan dan mengekspor M3U8. Tiap panel bisa
 * dilepas menjadi jendela floating; panel yang tersisa memakai seluruh ruang.
 */
@Composable
private fun PlaylistWorkspace(vm: MainViewModel, pickers: Pickers, modifier: Modifier) {
    val count = vm.state.playlist.entries.size
    val desktop = vm.desktop
    val sourceDocked = !desktop.window(PanelId.SOURCE).floating
    val playlistDocked = !desktop.window(PanelId.PLAYLIST).floating
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (sourceDocked) {
            Column(Modifier.weight(1f).fillMaxWidth().border(1.dp, Classic.border)) {
                PanelTitle("Sumber Lagu", onFloat = { desktop.open(PanelId.SOURCE) })
                SourceBrowser(vm, pickers, Modifier.weight(1f).fillMaxWidth().padding(4.dp))
            }
        }
        if (playlistDocked) {
            Column(Modifier.weight(1f).fillMaxWidth().border(1.dp, Classic.border)) {
                PanelTitle("Susunan Playlist  ·  $count track", onFloat = { desktop.open(PanelId.PLAYLIST) })
                PlaylistEditor(vm, pickers, Modifier.weight(1f).fillMaxWidth().padding(4.dp))
            }
        }
        if (!sourceDocked && !playlistDocked) {
            Column(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Label("Kedua panel sedang menjadi jendela.", style = Classic.small)
                ClassicButton("Kembalikan ke panel", {
                    PanelId.entries.forEach { desktop.close(it) }
                })
            }
        }
    }
}

/** Lapisan jendela floating di atas ruang kerja. Area kosongnya tidak menangkap sentuhan. */
@Composable
private fun FloatingDesktop(vm: MainViewModel, pickers: Pickers) {
    BoxWithConstraints(Modifier.fillMaxSize().clipToBounds()) {
        val width = constraints.maxWidth.toFloat()
        val height = constraints.maxHeight.toFloat()
        // Urutan komposisi tetap; urutan tumpukan diatur lewat zIndex agar gestur tidak terputus.
        FloatingWindow(vm.desktop, PanelId.SOURCE, width, height) {
            SourceBrowser(vm, pickers, Modifier.fillMaxSize())
        }
        FloatingWindow(vm.desktop, PanelId.PLAYLIST, width, height) {
            PlaylistEditor(vm, pickers, Modifier.fillMaxSize())
        }
    }
}

/** Bilah tugas: satu tombol untuk tiap jendela yang terbuka, termasuk yang dikecilkan. */
@Composable
private fun WindowTaskbar(desktop: DesktopState) {
    val open = PanelId.entries.filter { desktop.window(it).floating }
    if (open.isEmpty()) return
    Row(
        modifier = Modifier.fillMaxWidth().background(Classic.bar).topLine(Classic.border).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        open.forEach { id ->
            val minimized = desktop.window(id).minimized
            ClassicButton(
                if (minimized) "▁ ${id.title}" else id.title,
                { desktop.taskbarClick(id) },
                Modifier.weight(1f),
                active = desktop.active == id,
            )
        }
    }
}

/** Browser sumber lagu dengan tab Folder / Album / All Songs, pencarian, dan tombol + per lagu. */
@Composable
private fun SourceBrowser(vm: MainViewModel, pickers: Pickers, modifier: Modifier) {
    val state = vm.state
    val content = vm.pickerContent()
    Column(modifier) {
        if (state.snapshot == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                ClassicButton("Buka Folder Musik...", { pickers.openLibrary() }, icon = Icons.Rounded.Folder)
            }
            return@Column
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            listOf(
                LibraryViewMode.FOLDER to "Folder",
                LibraryViewMode.ALBUM to "Album",
                LibraryViewMode.ALL to "All Songs",
            ).forEach { (mode, label) ->
                ClassicButton(label, { vm.setPickMode(mode) }, active = state.pickMode == mode)
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            ClassicField(
                state.pickQuery, { vm.setPickQuery(it) }, Modifier.weight(1f),
                placeholder = "Cari folder atau lagu", leading = Icons.Rounded.Search,
            )
            if (state.pickQuery.isNotEmpty()) ClassicButton("", { vm.setPickQuery("") }, icon = Icons.Rounded.Close)
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (content.canGoUp) ClassicButton("", { vm.pickGoUp() }, icon = Icons.Rounded.ArrowUpward)
            Label(content.title, Modifier.weight(1f).padding(horizontal = 4.dp), Classic.heading.copy(fontSize = 14.sp))
            if (content.tracks.isNotEmpty()) {
                ClassicButton(
                    "Tambah semua (${content.tracks.size})",
                    { vm.addTracksToPlaylist(content.tracks) },
                    icon = Icons.Rounded.Add,
                )
            }
        }

        val inPlaylist = remember(state.playlist.entries) {
            state.playlist.entries.mapNotNullTo(HashSet()) { it.track?.documentId }
        }
        val screen = Screen(navKey(MainTab.PLAYLIST, state.pickMode, state.pickBrowser.path, state.pickGroupKey), content)
        AnimatedContent(
            targetState = screen,
            modifier = Modifier.weight(1f).fillMaxWidth().clipToBounds(),
            contentKey = { it.key },
            transitionSpec = { slideBetween(isForward(initialState.key, targetState.key, PICKER_MODE_ORDER)) },
            label = "picker-nav",
        ) { shown ->
            val c = shown.content
            BoxWithConstraints(Modifier.fillMaxSize().border(1.dp, Classic.border).background(Classic.panel)) {
                val width = maxWidth
                LazyColumn(Modifier.fillMaxSize()) {
                    if (c.canGoUp && shown.key.mode == LibraryViewMode.FOLDER) {
                        item(key = "up") {
                            BrowserRow(width, "..", "Naik satu folder", Classic.dim, Icons.Rounded.ArrowUpward) { vm.pickGoUp() }
                        }
                    }
                    items(c.folders, key = { "f:" + it.documentId }) { folder ->
                        BrowserRow(width, folder.name, "", Classic.text, Icons.Rounded.Folder) { vm.openPickFolder(folder) }
                    }
                    items(c.groups, key = { "g:" + it.key }) { group ->
                        val detail = if (shown.key.mode == LibraryViewMode.ALBUM) {
                            "${group.subtitle}  [${group.tracks.size} lagu]"
                        } else {
                            group.subtitle
                        }
                        BrowserRow(width, group.title, detail, Classic.text, Icons.Rounded.Folder) { vm.openPickGroup(group) }
                    }
                    itemsIndexed(
                        c.tracks,
                        key = { _, track -> "t:" + track.documentId },
                        contentType = { _, _ -> "track" },
                    ) { index, track ->
                        PickerTrackRow(
                            width = width,
                            index = index,
                            track = track,
                            added = track.documentId in inPlaylist,
                            playing = vm.player.current?.documentId == track.documentId,
                            onPlay = { vm.playTrackIn(c.tracks, track) },
                            onAdd = { vm.addTrackToPlaylist(track) },
                        )
                    }
                    if (c.tracks.isEmpty() && c.folders.isEmpty() && c.groups.isEmpty()) {
                        item(key = "empty") { BrowserRow(width, "(kosong)", "", Classic.dim) {} }
                    }
                }
            }
        }
    }
}

@Composable
private fun PickerTrackRow(
    width: Dp,
    index: Int,
    track: LibraryTrack,
    added: Boolean,
    playing: Boolean,
    onPlay: () -> Unit,
    onAdd: () -> Unit,
) {
    Row(
        modifier = Modifier
            .width(width)
            .height(ROW_HEIGHT)
            .rowBackground(index, checked = false, focused = false)
            .clickable(onClick = onPlay)
            .padding(start = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            Icons.Rounded.MusicNote, contentDescription = null,
            tint = if (playing) Classic.accent else Classic.dim, modifier = Modifier.size(16.dp),
        )
        Label(
            track.displayTitle,
            Modifier.weight(1f),
            Classic.body.copy(
                color = if (playing) Classic.accent else Classic.text,
                fontWeight = if (playing) FontWeight.Bold else FontWeight.Medium,
            ),
        )
        Label(track.tags.artist, Modifier.widthIn(max = 110.dp), Classic.small)
        if (added) Icon(Icons.Rounded.Check, contentDescription = "Sudah di playlist", tint = Classic.blue, modifier = Modifier.size(16.dp))
        RowAction(Icons.Rounded.Add, "Tambah ke playlist", Classic.text, onClick = onAdd)
    }
}

/** Editor susunan: nama, jumlah track, tombol geser / hapus / import / export, dan daftar entri. */
@Composable
private fun PlaylistEditor(vm: MainViewModel, pickers: Pickers, modifier: Modifier) {
    val state = vm.state
    val loaded = state.snapshot != null
    val hasEntries = state.playlist.entries.isNotEmpty()
    val last = state.playlist.entries.lastIndex
    Column(modifier) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Label("Nama", style = Classic.small)
            ClassicField(state.playlist.name, { vm.renamePlaylist(it) }, Modifier.weight(1f))
            Label(
                "${state.playlist.entries.size} track · ${formatDuration(state.playlist.totalDurationSeconds)}",
                style = Classic.mono,
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            ClassicButton("Putar", { vm.playSelected(true) }, enabled = hasEntries, active = vm.player.isPlaying, icon = Icons.Rounded.PlayArrow)
            ClassicButton("Naik", { vm.moveSelection(-1, true) }, enabled = hasEntries, icon = Icons.Rounded.KeyboardArrowUp)
            ClassicButton("Turun", { vm.moveSelection(1, true) }, enabled = hasEntries, icon = Icons.Rounded.KeyboardArrowDown)
            ClassicButton("Ke Atas", { vm.moveSelectionToEdge(top = true, inPlaylist = true) }, enabled = hasEntries, icon = Icons.Rounded.VerticalAlignTop)
            ClassicButton("Ke Bawah", { vm.moveSelectionToEdge(top = false, inPlaylist = true) }, enabled = hasEntries, icon = Icons.Rounded.VerticalAlignBottom)
            // Mengacak seluruh urutan sebelum disimpan atau diekspor; bisa diulang sampai urutannya cocok.
            ClassicButton("Acak", { vm.shufflePlaylist() }, enabled = state.playlist.entries.size > 1, icon = Icons.Rounded.Shuffle)
            ClassicButton("Hapus", { vm.removeFromPlaylist(true) }, enabled = hasEntries, icon = Icons.Rounded.Delete)
            ClassicButton("Semua", { vm.selectAll(true) }, enabled = hasEntries)
            ClassicButton("Kosongkan", { vm.selectNone(true) }, enabled = hasEntries)
            ClassicButton("Import", { pickers.openPlaylist() }, enabled = loaded)
            ClassicButton("Export M3U8", { vm.showExport(PlaylistFormat.M3U8) }, enabled = hasEntries)
        }
        TrackTable(Modifier.weight(1f)) { width ->
            itemsIndexed(
                state.playlist.entries,
                key = { _, entry -> entry.id },
                contentType = { _, entry -> if (entry.track == null) "missing" else "track" },
            ) { index, entry ->
                val track = entry.track
                val actions: @Composable (Color) -> Unit = { tint ->
                    // Urutan diatur per baris sebelum diekspor ke .m3u8.
                    RowAction(Icons.Rounded.KeyboardArrowUp, "Naikkan", tint, enabled = index > 0) { vm.moveEntry(entry.id, -1) }
                    RowAction(Icons.Rounded.KeyboardArrowDown, "Turunkan", tint, enabled = index < last) { vm.moveEntry(entry.id, 1) }
                    RowAction(Icons.Rounded.Close, "Hapus dari playlist", tint) { vm.removeEntry(entry.id) }
                }
                if (track == null) {
                    MissingRow(
                        width = width,
                        index = index,
                        entry = entry,
                        checked = entry.id in state.playlistChecked,
                        focused = entry.id == state.playlistFocused,
                        onClick = { vm.focusEntry(entry.id) },
                        onToggle = { vm.toggleEntry(entry.id) },
                        actions = actions,
                    )
                } else {
                    TrackRow(
                        vm = vm,
                        width = width,
                        index = index,
                        track = track,
                        number = (index + 1).toString().padStart(2, '0'),
                        titlePrefix = if (entry.approximate) "≈ " else "",
                        onPlay = { vm.playTrack(track, true) },
                        checked = entry.id in state.playlistChecked,
                        focused = entry.id == state.playlistFocused,
                        onClick = { vm.focusEntry(entry.id) },
                        onToggle = { vm.toggleEntry(entry.id) },
                        actions = actions,
                    )
                }
            }
            if (state.playlist.entries.isEmpty()) {
                item(key = "empty") {
                    BrowserRow(width, "Playlist kosong", "Tekan + pada lagu di area Sumber Lagu (atas) untuk menambahkan", Classic.dim) {}
                }
            }
        }
    }
}

/** Header dan isi bergulir horizontal bersama; kolom Title melebar bila layar cukup lebar. */
@Composable
private fun TrackTable(
    modifier: Modifier,
    rows: androidx.compose.foundation.lazy.LazyListScope.(width: Dp) -> Unit,
) {
    BoxWithConstraints(modifier.fillMaxWidth().border(1.dp, Classic.border).background(Classic.panel)) {
        val minimum = FIXED_WIDTH + TITLE_WIDTH
        val width = if (maxWidth > minimum) maxWidth else minimum
        val titleWidth = width - FIXED_WIDTH
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .horizontalScroll(rememberScrollState())
                .width(width),
        ) {
            Row(Modifier.width(width).height(28.dp).background(Classic.bar).bottomLine(Classic.border)) {
                HeaderCell("✓", CHECK_WIDTH)
                HeaderCell("Aksi", ACTION_WIDTH)
                HeaderCell("No", NUMBER_WIDTH)
                HeaderCell("Title", titleWidth)
                HeaderCell("Artist", ARTIST_WIDTH)
                HeaderCell("Album", ALBUM_WIDTH)
                HeaderCell("Genre", GENRE_WIDTH)
                HeaderCell("Codec", CODEC_WIDTH)
                HeaderCell("RG Gain", GAIN_WIDTH)
            }
            LazyColumn(Modifier.weight(1f).width(width)) { rows(width) }
        }
    }
}

@Composable
private fun HeaderCell(text: String, width: Dp) {
    Box(
        modifier = Modifier.width(width).fillMaxHeight().rightLine(Classic.border).padding(horizontal = 6.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        Label(text, style = Classic.small.copy(color = Classic.text, fontWeight = FontWeight.SemiBold))
    }
}

@Composable
private fun Cell(text: String, width: Dp, style: TextStyle = Classic.body) {
    Box(
        modifier = Modifier
            .width(width)
            .fillMaxHeight()
            .rightLine(Classic.grid)
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        Label(text, style = style)
    }
}

/** Tombol ikon kecil di dalam baris tabel. */
@Composable
private fun RowAction(
    icon: ImageVector,
    description: String,
    tint: Color,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier.size(32.dp).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = description,
            tint = if (enabled) tint else tint.copy(alpha = 0.28f),
            modifier = Modifier.size(20.dp),
        )
    }
}

/** Kolom aksi: kotak 100dp berisi tombol-tombol ikon, ditempatkan tepat setelah centang. */
@Composable
private fun ActionCell(tint: Color, actions: @Composable (Color) -> Unit) {
    Row(
        modifier = Modifier.width(ACTION_WIDTH).fillMaxHeight().rightLine(Classic.grid).padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        actions(tint)
    }
}

/** Sorotan baris memakai biru glossy ala layar iPod; centang memakai biru muda; sisanya belang. */
private fun Modifier.rowBackground(index: Int, checked: Boolean, focused: Boolean): Modifier = when {
    focused -> background(Classic.blueGloss)
    checked -> background(Classic.selection)
    index % 2 == 0 -> background(Classic.panel)
    else -> background(Classic.rowAlternate)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TrackRow(
    vm: MainViewModel,
    width: Dp,
    index: Int,
    track: LibraryTrack,
    number: String,
    checked: Boolean,
    focused: Boolean,
    onClick: () -> Unit,
    onToggle: () -> Unit,
    onPlay: () -> Unit,
    actions: @Composable (Color) -> Unit,
    titlePrefix: String = "",
) {
    // derivedStateOf: baris hanya digambar ulang bila nilainya sendiri berubah, bukan setiap kali
    // status aplikasi atau info baris lain berubah.
    val playing by remember(track.documentId) {
        derivedStateOf { vm.player.current?.documentId == track.documentId }
    }
    val auto by remember { derivedStateOf { vm.state.autoTechColumns } }
    val idle by remember { derivedStateOf { vm.state.busy == null } }
    val tech by remember(track) { derivedStateOf { vm.techFor(track) } }
    // Kolom Codec/RG hanya dimuat untuk baris yang tetap terlihat sebentar, supaya file tidak
    // dibaca saat daftar sedang digulir cepat.
    val needsTech = auto && idle && tech == null
    LaunchedEffect(track.documentId, track.lastModified, track.item.sizeBytes, needsTech) {
        if (needsTech) {
            delay(TECH_DELAY_MS)
            vm.requestTech(track)
        }
    }
    DisposableEffect(track.documentId) {
        onDispose { vm.cancelTech(track) }
    }
    val pending = if (auto) "…" else "-"
    val fg = if (focused) Classic.onAccent else Classic.text
    val muted = if (focused) Classic.onAccent.copy(alpha = 0.85f) else Classic.dim
    Row(
        modifier = Modifier
            .width(width)
            .height(ROW_HEIGHT)
            .rowBackground(index, checked, focused)
            .combinedClickable(onClick = onClick, onLongClick = onToggle, onDoubleClick = onPlay),
    ) {
        Box(
            modifier = Modifier.width(CHECK_WIDTH).fillMaxHeight().rightLine(Classic.grid).clickable(onClick = onToggle),
            contentAlignment = Alignment.Center,
        ) {
            CheckSquare(checked)
        }
        ActionCell(fg, actions)
        Cell(number, NUMBER_WIDTH, Classic.mono.copy(color = muted))
        Cell(
            (if (playing) "▶ " else "") + titlePrefix + track.displayTitle,
            width - FIXED_WIDTH,
            Classic.body.copy(
                color = if (playing && !focused) Classic.accent else fg,
                fontWeight = if (playing) FontWeight.Bold else FontWeight.Medium,
            ),
        )
        Cell(track.tags.artist, ARTIST_WIDTH, Classic.body.copy(color = fg))
        Cell(track.tags.album, ALBUM_WIDTH, Classic.body.copy(color = fg))
        Cell(track.tags.genre, GENRE_WIDTH, Classic.body.copy(color = fg))
        Cell(
            tech?.codec?.let { shortCodec(it) } ?: track.item.extension.uppercase(Locale.ROOT),
            CODEC_WIDTH,
            Classic.mono.copy(color = if (focused) Classic.onAccent else Classic.blue),
        )
        Cell(tech?.let { it.trackGain.ifBlank { "-" } } ?: pending, GAIN_WIDTH, Classic.mono.copy(color = muted))
    }
}

/** Nama codec dari header bisa panjang, mis. "FLAC 16 bits" atau "MPEG-1 Layer 3". */
private fun shortCodec(codec: String): String {
    val upper = codec.uppercase(Locale.ROOT)
    return listOf("FLAC", "ALAC", "AAC", "VORBIS", "WAV", "PCM").firstOrNull { it in upper }
        ?: when {
            "LAYER 3" in upper || "MP3" in upper -> "MP3"
            "APPLE LOSSLESS" in upper -> "ALAC"
            "OGG" in upper -> "VORBIS"
            else -> codec
        }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MissingRow(
    width: Dp,
    index: Int,
    entry: PlaylistEntry,
    checked: Boolean,
    focused: Boolean,
    onClick: () -> Unit,
    onToggle: () -> Unit,
    actions: @Composable (Color) -> Unit,
) {
    val fg = if (focused) Classic.onAccent else Classic.error
    Row(
        modifier = Modifier
            .width(width)
            .height(ROW_HEIGHT)
            .rowBackground(index, checked, focused)
            .combinedClickable(onClick = onClick, onLongClick = onToggle),
    ) {
        Box(
            modifier = Modifier.width(CHECK_WIDTH).fillMaxHeight().rightLine(Classic.grid).clickable(onClick = onToggle),
            contentAlignment = Alignment.Center,
        ) {
            CheckSquare(checked)
        }
        ActionCell(if (focused) Classic.onAccent else Classic.text, actions)
        Cell((index + 1).toString().padStart(2, '0'), NUMBER_WIDTH, Classic.mono.copy(color = fg))
        Cell(
            "(hilang) ${entry.title}  ${entry.rawPath}",
            width - CHECK_WIDTH - ACTION_WIDTH - NUMBER_WIDTH,
            Classic.body.copy(color = fg),
        )
    }
}

@Composable
private fun BrowserRow(
    width: Dp,
    title: String,
    detail: String,
    color: Color,
    icon: ImageVector? = null,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .width(width)
            .height(ROW_HEIGHT)
            .background(Classic.panel)
            .bottomLine(Classic.grid)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (icon != null) Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        Label(title, Modifier.widthIn(max = 260.dp), Classic.body.copy(color = color))
        Label(detail, style = Classic.small)
    }
}

// =====================================================================================
// DIALOG
// =====================================================================================

@Composable
private fun ClassicWindow(
    title: String,
    onDismiss: () -> Unit,
    buttons: @Composable () -> Unit,
    dismissible: Boolean = true,
    scrollable: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(6.dp)
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(dismissOnBackPress = dismissible, dismissOnClickOutside = false),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 560.dp)
                .clip(shape)
                .background(Classic.panel)
                .border(1.dp, Classic.border, shape),
        ) {
            PanelTitle(title)
            val scroll = rememberScrollState()
            Column(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .fillMaxWidth()
                    .then(if (scrollable) Modifier.verticalScroll(scroll) else Modifier)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                content = content,
            )
            Row(
                modifier = Modifier.fillMaxWidth().background(Classic.chrome).topLine(Classic.border).padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End),
            ) {
                buttons()
            }
        }
    }
}

@Composable
private fun Dialogs(vm: MainViewModel, pickers: Pickers) {
    val busy = vm.state.busy
    if (busy != null) {
        ProgressDialog(vm, busy.title, busy.cancellable)
        return
    }
    when (val dialog = vm.state.dialog) {
        null -> Unit
        is UiDialog.Confirm -> ClassicWindow(
            title = dialog.title,
            onDismiss = { vm.dismissDialog() },
            buttons = {
                ClassicButton(dialog.confirmLabel, {
                    vm.dismissDialog()
                    dialog.onConfirm()
                })
                ClassicButton("Batal", { vm.dismissDialog() })
            },
        ) {
            Label(dialog.message, maxLines = 8)
        }
        is UiDialog.Info -> ClassicWindow(
            title = dialog.title,
            onDismiss = { vm.dismissDialog() },
            buttons = { ClassicButton("OK", { vm.dismissDialog() }) },
        ) {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                items(dialog.lines) { Label(it, Modifier.padding(vertical = 2.dp), maxLines = 5) }
            }
        }
        is UiDialog.AutoNumber -> AutoNumberDialog(vm, dialog)
        is UiDialog.FilenameToTagWizard -> FilenameToTagDialog(vm, dialog)
        is UiDialog.TagToFilenameWizard -> TagToFilenameDialog(vm, dialog)
        is UiDialog.ReplayGainResult -> ReplayGainDialog(vm, dialog)
        is UiDialog.CoverOptions -> CoverDialog(vm, pickers, dialog)
        is UiDialog.ExportPlaylist -> ExportDialog(vm, pickers, dialog)
        UiDialog.About -> AboutDialog(vm)
        is UiDialog.Recovery -> ClassicWindow(
            title = "Pemulihan file",
            onDismiss = { vm.dismissDialog() },
            buttons = {
                ClassicButton("Pulihkan", { vm.recoverAll(dialog.items) })
                ClassicButton("Nanti", { vm.dismissDialog() })
            },
        ) {
            Label(
                "${dialog.items.size} penulisan sebelumnya terputus. Pulihkan file asli dari cadangan?",
                maxLines = 6,
            )
        }
    }
}

@Composable
private fun AboutDialog(vm: MainViewModel) {
    val context = LocalContext.current
    // Otomatis mengikuti versionName di build.gradle.kts.
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "-"
    }
    ClassicWindow(
        title = "Tentang M3T Pod",
        onDismiss = { vm.dismissDialog() },
        buttons = { ClassicButton("Tutup", { vm.dismissDialog() }, active = true) },
    ) {
        Label("Developer: S. GreArd", style = Classic.body.copy(fontWeight = FontWeight.SemiBold))
        Label("Versi $version", style = Classic.small)
    }
}

@Composable
private fun ProgressDialog(vm: MainViewModel, title: String, cancellable: Boolean) {
    val progress = vm.progress
    ClassicWindow(
        title = title,
        onDismiss = {},
        dismissible = false,
        buttons = { if (cancellable) ClassicButton("Batalkan", { vm.cancelOperation() }) },
    ) {
        Label(progress.name.ifEmpty { "Bekerja..." }, maxLines = 2)
        val fraction = if (progress.total > 0) {
            (progress.completed.toFloat() / progress.total).coerceIn(0f, 1f)
        } else {
            0f
        }
        Box(Modifier.fillMaxWidth().height(20.dp).background(Classic.field).border(1.dp, Classic.border).padding(3.dp)) {
            if (fraction > 0f) Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(Classic.blueGloss))
        }
        if (progress.total > 0) Label("${progress.completed} / ${progress.total}", style = Classic.mono)
    }
}

@Composable
private fun AutoNumberDialog(vm: MainViewModel, dialog: UiDialog.AutoNumber) {
    var start by remember(dialog) { mutableStateOf("1") }
    var padding by remember(dialog) { mutableStateOf("2") }
    var disc by remember(dialog) { mutableStateOf("") }
    var total by remember(dialog) { mutableStateOf(false) }
    var perFolder by remember(dialog) { mutableStateOf(true) }
    var order by remember(dialog) { mutableStateOf(NumberingOrder.AS_SELECTED) }

    val result = remember(dialog, start, padding, disc, total, perFolder, order) {
        vm.previewAutoNumber(
            dialog.tracks,
            AutoNumberOptions(
                startNumber = start.toIntOrNull() ?: 0,
                padWidth = padding.toIntOrNull() ?: 0,
                writeTotal = total,
                restartPerFolder = perFolder,
                discNumber = if (disc.isEmpty()) null else disc.toIntOrNull() ?: 0,
                order = order,
            ),
        )
    }
    val previews = result.getOrNull().orEmpty()

    ClassicWindow(
        title = "Auto-Numbering (${dialog.tracks.size} lagu)",
        onDismiss = { vm.dismissDialog() },
        buttons = {
            ClassicButton("Terapkan", { vm.applyAutoNumber(previews) }, enabled = previews.isNotEmpty())
            ClassicButton("Batal", { vm.dismissDialog() })
        },
    ) {
        LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LabeledNumber("Mulai", start, Modifier.weight(1f)) { start = it }
                    LabeledNumber("Digit", padding, Modifier.weight(1f)) { padding = it }
                    LabeledNumber("Disc", disc, Modifier.weight(1f)) { disc = it }
                }
            }
            item { CheckLine("Tulis total trek", total) { total = !total } }
            item { CheckLine("Ulangi nomor untuk tiap folder", perFolder) { perFolder = !perFolder } }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    listOf(
                        NumberingOrder.AS_SELECTED to "Tabel",
                        NumberingOrder.FILE_NAME to "Nama file",
                        NumberingOrder.CURRENT_TAGS to "Tag",
                    ).forEach { (value, label) ->
                        ClassicButton(label, { order = value }, Modifier.weight(1f), active = order == value)
                    }
                }
            }
            result.exceptionOrNull()?.let { error ->
                item { Label(error.message.orEmpty(), style = Classic.body.copy(color = Classic.error), maxLines = 3) }
            }
            items(previews) { preview ->
                val suffix = preview.trackTotal?.let { "/$it" }.orEmpty()
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Label(preview.trackNumber + suffix, Modifier.width(72.dp), Classic.mono)
                    Label(preview.track.item.displayName)
                }
            }
        }
    }
}

@Composable
private fun LabeledNumber(label: String, value: String, modifier: Modifier, onChange: (String) -> Unit) {
    Column(modifier) {
        Label(label, style = Classic.small)
        ClassicField(
            value = value,
            onValueChange = { text -> onChange(text.filter { it in '0'..'9' }.take(4)) },
            modifier = Modifier.fillMaxWidth(),
            numeric = true,
        )
    }
}

@Composable
private fun PresetRow(presets: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        presets.forEach { (label, pattern) ->
            ClassicButton(label, { onSelect(pattern) }, active = selected == pattern)
        }
    }
}

@Composable
private fun FilenameToTagDialog(vm: MainViewModel, dialog: UiDialog.FilenameToTagWizard) {
    var pattern by remember(dialog) { mutableStateOf("") }
    var underscores by remember(dialog) { mutableStateOf(true) }
    val result = remember(dialog, pattern, underscores) {
        vm.previewFilenameToTag(dialog.tracks, pattern, underscores)
    }
    val previews = result.getOrNull().orEmpty()
    val valid = previews.count { it.error == null }

    ClassicWindow(
        title = "Filename to Tag",
        onDismiss = { vm.dismissDialog() },
        buttons = {
            ClassicButton("Terapkan ($valid)", { vm.applyFilenameToTag(previews) }, enabled = valid > 0)
            ClassicButton("Batal", { vm.dismissDialog() })
        },
    ) {
        Label("Pola (kosong = otomatis)", style = Classic.small)
        ClassicField(pattern, { pattern = it }, Modifier.fillMaxWidth(), placeholder = "Otomatis")
        PresetRow(
            listOf(
                "Otomatis" to "",
                "01 - Judul" to "%tracknumber% - %title%",
                "01. Judul" to "%tracknumber%. %title%",
                "Artis - Judul" to "%artist% - %title%",
                "01 - Artis - Judul" to "%tracknumber% - %artist% - %title%",
            ),
            pattern,
        ) { pattern = it }
        CheckLine("Ubah \"_\" menjadi spasi", underscores) { underscores = !underscores }
        result.exceptionOrNull()?.let {
            Label(it.message.orEmpty(), style = Classic.body.copy(color = Classic.error), maxLines = 3)
        }
        LazyColumn(Modifier.heightIn(max = 220.dp)) {
            items(previews) { preview ->
                Column(Modifier.padding(vertical = 3.dp)) {
                    Label(preview.track.item.displayName, style = Classic.small)
                    val summary = preview.error ?: preview.values.entries.joinToString("  |  ") {
                        "${it.key.placeholders[0]}=${it.value}"
                    }
                    Label(
                        summary,
                        style = Classic.body.copy(color = if (preview.error == null) Classic.accent else Classic.error),
                        maxLines = 3,
                    )
                }
            }
        }
    }
}

@Composable
private fun TagToFilenameDialog(vm: MainViewModel, dialog: UiDialog.TagToFilenameWizard) {
    var pattern by remember(dialog) { mutableStateOf(dialog.previewPattern ?: "%tracknumber% - %title%") }
    // Pratinjau hanya berlaku bila polanya belum diubah lagi.
    val current = if (pattern == dialog.previewPattern) dialog.previews else emptyList()
    val ready = current.count { it.status == RenameStatus.READY }

    ClassicWindow(
        title = "Tag to Filename (${dialog.tracks.size} lagu)",
        onDismiss = { vm.dismissDialog() },
        buttons = {
            ClassicButton("Pratinjau", { vm.previewTagToFilename(dialog.tracks, pattern) })
            ClassicButton("Ganti Nama ($ready)", { vm.applyRename(current) }, enabled = ready > 0)
            ClassicButton("Tutup", { vm.dismissDialog() })
        },
    ) {
        ClassicField(pattern, { pattern = it }, Modifier.fillMaxWidth(), placeholder = "Pola nama file")
        PresetRow(
            listOf(
                "01 - Judul" to "%tracknumber% - %title%",
                "01. Judul" to "%tracknumber%. %title%",
                "01 - Artis - Judul" to "%tracknumber% - %artist% - %title%",
                "Artis - Judul" to "%artist% - %title%",
            ),
            pattern,
        ) { pattern = it }
        LazyColumn(Modifier.heightIn(max = 260.dp)) {
            items(current) { preview ->
                val color = when (preview.status) {
                    RenameStatus.READY -> Classic.accent
                    RenameStatus.UNCHANGED -> Classic.dim
                    RenameStatus.CONFLICT -> Classic.warning
                    RenameStatus.ERROR -> Classic.error
                }
                Column(Modifier.padding(vertical = 3.dp)) {
                    Label(preview.track.item.displayName, style = Classic.small)
                    Label("→ ${preview.newName}", style = Classic.body.copy(color = color), maxLines = 3)
                    preview.message?.let { Label(it, style = Classic.small.copy(color = color), maxLines = 3) }
                }
            }
        }
    }
}

@Composable
private fun ReplayGainDialog(vm: MainViewModel, dialog: UiDialog.ReplayGainResult) {
    val report = dialog.report
    ClassicWindow(
        title = "Hasil Scan ReplayGain",
        onDismiss = { vm.dismissDialog() },
        buttons = {
            ClassicButton("Tulis ke File", { vm.writeReplayGain(report) }, enabled = report.tracks.isNotEmpty())
            ClassicButton("Buang", { vm.dismissDialog() })
        },
    ) {
        LazyColumn(Modifier.heightIn(max = 400.dp)) {
            items(report.tracks) { result -> GainLine(result) }
            items(report.failed) { failure ->
                Label(
                    "GAGAL ${failure.item.displayName}: ${failure.message}",
                    Modifier.padding(vertical = 3.dp),
                    Classic.body.copy(color = Classic.error),
                    maxLines = 4,
                )
            }
        }
    }
}

@Composable
private fun GainLine(result: TrackGainResult) {
    fun gain(value: Double?) = value?.let { String.format(Locale.US, "%+.2f dB", it) } ?: "-"
    fun peak(value: Double?) = value?.let { String.format(Locale.US, "%.6f", it) } ?: "-"
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Label(result.item.displayName)
        Label("Track ${gain(result.trackGainDb)}  peak ${peak(result.trackPeak)}", style = Classic.mono)
        if (result.writeAlbumValues) {
            Label("Album ${gain(result.albumGainDb)}  peak ${peak(result.albumPeak)}", style = Classic.mono)
        } else if (result.albumKey != null) {
            Label(
                "Nilai album tidak ditulis (ada anggota yang gagal)",
                style = Classic.small.copy(color = Classic.warning),
            )
        }
        if (result.trackGainDb == null) {
            Label("Hening atau terlalu pendek", style = Classic.small.copy(color = Classic.warning))
        }
    }
}

@Composable
private fun CoverDialog(vm: MainViewModel, pickers: Pickers, dialog: UiDialog.CoverOptions) {
    var scope by remember(dialog) {
        mutableStateOf(if (dialog.selection.size > 1) CoverScope.SELECTION else CoverScope.ONE)
    }
    val albumSize = remember(dialog) { vm.albumOf(dialog.anchor).size }
    ClassicWindow(
        title = "Sampul Album",
        onDismiss = { vm.dismissDialog() },
        scrollable = true,
        buttons = {
            ClassicButton("Pilih Gambar", {
                vm.prepareCoverPick(scope, dialog.anchor, dialog.selection)
                pickers.pickCover()
            })
            ClassicButton("Hapus", { vm.removeCover(scope, dialog.anchor, dialog.selection) })
            ClassicButton("Batal", { vm.dismissDialog() })
        },
    ) {
        Label("Acuan: ${dialog.anchor.item.displayName}", style = Classic.small, maxLines = 2)
        CoverScope.entries.forEach { option ->
            val count = when (option) {
                CoverScope.ONE -> 1
                CoverScope.SELECTION -> dialog.selection.size
                CoverScope.ALBUM -> albumSize
            }
            CheckLine("${option.label} ($count)", scope == option) { scope = option }
        }
        Label("Format JPG/PNG, maksimal 10 MB.", style = Classic.small)
    }
}

@Composable
private fun ExportDialog(vm: MainViewModel, pickers: Pickers, dialog: UiDialog.ExportPlaylist) {
    var name by remember(dialog) { mutableStateOf(vm.state.playlist.name) }
    var format by remember(dialog) { mutableStateOf(dialog.format) }
    var includeMissing by remember(dialog) { mutableStateOf(true) }
    val currentFolder = if (vm.state.viewMode == LibraryViewMode.FOLDER) vm.state.browser.path else ""
    val missing = vm.state.playlist.entries.count { it.isMissing }
    val valid = name.isNotBlank()

    ClassicWindow(
        title = "Export Playlist",
        onDismiss = { vm.dismissDialog() },
        scrollable = true,
        buttons = { ClassicButton("Batal", { vm.dismissDialog() }) },
    ) {
        Label("Nama file", style = Classic.small)
        ClassicField(name, { name = it }, Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            PlaylistFormat.entries.forEach { option ->
                ClassicButton(
                    ".${option.extension}",
                    { format = option },
                    Modifier.weight(1f),
                    active = format == option,
                )
            }
        }
        if (missing > 0) {
            CheckLine("Sertakan $missing entri yang hilang", includeMissing) { includeMissing = !includeMissing }
        }
        Label("Path lagu ditulis relatif terhadap folder tujuan.", style = Classic.small, maxLines = 3)
        ClassicButton(
            "Simpan di folder utama musik",
            { vm.exportToLibrary(name, format, includeMissing, "") },
            Modifier.fillMaxWidth(),
            enabled = valid,
        )
        if (currentFolder.isNotEmpty()) {
            ClassicButton(
                "Simpan di: $currentFolder",
                { vm.exportToLibrary(name, format, includeMissing, currentFolder) },
                Modifier.fillMaxWidth(),
                enabled = valid,
            )
        }
        ClassicButton(
            "Pilih folder lain...",
            {
                vm.prepareExportPick(name, format, includeMissing)
                pickers.pickExportFolder()
            },
            Modifier.fillMaxWidth(),
            enabled = valid,
        )
    }
}
