// File: app/src/main/java/com/tagbardroid/app/library/FileAndPlaylistManager.kt
package com.tagbardroid.app.library

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import com.tagbardroid.app.engine.AudioItem
import com.tagbardroid.app.engine.BatchReport
import com.tagbardroid.app.engine.ItemFailure
import com.tagbardroid.app.engine.OperationProgress
import com.tagbardroid.app.engine.SUPPORTED_EXTENSIONS
import com.tagbardroid.app.engine.TagAndReplayGainEngine
import com.tagbardroid.app.engine.TagEdit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.IOException
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.security.MessageDigest
import java.text.Normalizer
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

// =====================================================================================
// MODEL PERPUSTAKAAN
// =====================================================================================

data class TrackTags(
    val title: String = "",
    val artist: String = "",
    val albumArtist: String = "",
    val album: String = "",
    val genre: String = "",
    val year: String = "",
    val trackNumber: Int? = null,
    val discNumber: Int? = null,
    val durationMs: Long = 0L,
)

data class LibraryTrack(
    val item: AudioItem,
    val documentId: String,
    val lastModified: Long,
    val tags: TrackTags,
) {
    /** Path relatif terhadap folder akar perpustakaan, memakai "/". */
    val path: String get() = joinPath(item.folderPath, item.displayName)
    val displayTitle: String get() = tags.title.ifBlank { item.displayName.substringBeforeLast('.') }
}

data class LibraryFolder(
    val documentId: String,
    val name: String,
    /** "" untuk folder akar. */
    val path: String,
)

data class PlaylistFile(
    val uri: Uri,
    val documentId: String,
    val name: String,
    val folderPath: String,
    val parentDocumentId: String,
)

data class LibrarySnapshot(
    val treeUri: Uri,
    val folders: List<LibraryFolder>,
    val tracks: List<LibraryTrack>,
    val playlists: List<PlaylistFile>,
    /** Folder atau file yang tidak bisa dibaca saat pemindaian. */
    val warnings: List<String>,
)

data class ScanProgress(val foldersScanned: Int, val tracksFound: Int, val tracksRead: Int, val currentName: String)

enum class LibraryViewMode { FOLDER, ALBUM, ARTIST, GENRE, ALL }

/** Urutan tab All Songs. */
enum class AllSongsSort { TRACK_NUMBER, SHUFFLE }

data class LibraryGroup(
    val key: String,
    val title: String,
    val subtitle: String,
    val tracks: List<LibraryTrack>,
)

data class FolderContent(
    val folder: LibraryFolder?,
    val subfolders: List<LibraryFolder>,
    val tracks: List<LibraryTrack>,
    val playlists: List<PlaylistFile>,
)

/** Posisi browser folder. Bersifat immutable agar mudah disimpan di state Compose. */
data class BrowserState(val path: String = "") {
    val canGoUp: Boolean get() = path.isNotEmpty()

    fun open(folder: LibraryFolder): BrowserState = BrowserState(folder.path)

    fun up(): BrowserState = BrowserState(path.substringBeforeLast('/', ""))

    /** Pasangan (label, path) dari akar sampai folder sekarang. */
    fun breadcrumbs(rootName: String): List<Pair<String, String>> {
        val result = mutableListOf(rootName to "")
        var current = ""
        path.split('/').filter { it.isNotEmpty() }.forEach { segment ->
            current = joinPath(current, segment)
            result += segment to current
        }
        return result
    }

    /** Kembali ke folder terdekat yang masih ada setelah pemindaian ulang. */
    fun validate(snapshot: LibrarySnapshot): BrowserState {
        val known = snapshot.folders.mapTo(HashSet()) { it.path }
        var state = this
        while (state.canGoUp && state.path !in known) state = state.up()
        return state
    }
}

internal fun joinPath(folder: String, name: String): String = if (folder.isEmpty()) name else "$folder/$name"

/** Urutan alami: "2" sebelum "10", tanpa membedakan huruf besar/kecil. */
object NaturalOrder : Comparator<String> {
    override fun compare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            if (a[i] in '0'..'9' && b[j] in '0'..'9') {
                var endA = i
                var endB = j
                while (endA < a.length && a[endA] in '0'..'9') endA++
                while (endB < b.length && b[endB] in '0'..'9') endB++
                val numberA = a.substring(i, endA).trimStart('0')
                val numberB = b.substring(j, endB).trimStart('0')
                if (numberA.length != numberB.length) return numberA.length - numberB.length
                val result = numberA.compareTo(numberB)
                if (result != 0) return result
                i = endA
                j = endB
            } else {
                val result = a[i].lowercaseChar().compareTo(b[j].lowercaseChar())
                if (result != 0) return result
                i++
                j++
            }
        }
        val rest = (a.length - i) - (b.length - j)
        return if (rest != 0) rest else a.compareTo(b)
    }
}

// =====================================================================================
// TAMPILAN: FOLDER / ALBUM / ARTIS / GENRE
// =====================================================================================

object LibraryViews {

    private const val UNKNOWN_ALBUM = "(Tanpa Album)"
    private const val UNKNOWN_ARTIST = "(Artis Tidak Dikenal)"
    private const val UNKNOWN_GENRE = "(Tanpa Genre)"

    private val byFileName = Comparator<LibraryTrack> { a, b ->
        NaturalOrder.compare(a.item.displayName, b.item.displayName)
    }

    /** Urutan album: disc, nomor trek, lalu nama file. */
    val albumOrder: Comparator<LibraryTrack> =
        compareBy<LibraryTrack> { it.tags.discNumber ?: 1 }
            .thenBy { it.tags.trackNumber ?: Int.MAX_VALUE }
            .then(byFileName)

    fun folderContent(snapshot: LibrarySnapshot, path: String): FolderContent = FolderContent(
        folder = snapshot.folders.firstOrNull { it.path == path },
        subfolders = snapshot.folders
            .filter { it.path.isNotEmpty() && it.path.substringBeforeLast('/', "") == path }
            .sortedWith { a, b -> NaturalOrder.compare(a.name, b.name) },
        tracks = snapshot.tracks.filter { it.item.folderPath == path }.sortedWith(byFileName),
        playlists = snapshot.playlists.filter { it.folderPath == path }
            .sortedWith { a, b -> NaturalOrder.compare(a.name, b.name) },
    )

    /** Semua lagu di sebuah folder; [recursive] mencakup sub-folder. */
    fun tracksUnder(snapshot: LibrarySnapshot, path: String, recursive: Boolean = true): List<LibraryTrack> =
        snapshot.tracks.filter {
            it.item.folderPath == path ||
                (recursive && (path.isEmpty() || it.item.folderPath.startsWith("$path/")))
        }.sortedWith { a, b ->
            val folder = NaturalOrder.compare(a.item.folderPath, b.item.folderPath)
            if (folder != 0) folder else NaturalOrder.compare(a.item.displayName, b.item.displayName)
        }

    fun search(tracks: List<LibraryTrack>, query: String): List<LibraryTrack> {
        val words = normalizeKey(query).split(' ').filter { it.isNotEmpty() }
        if (words.isEmpty()) return tracks
        return tracks.filter { track ->
            val haystack = normalizeKey(
                listOf(
                    track.tags.title, track.tags.artist, track.tags.albumArtist,
                    track.tags.album, track.tags.genre, track.path,
                ).joinToString(" "),
            )
            words.all { it in haystack }
        }
    }

    fun groups(snapshot: LibrarySnapshot, mode: LibraryViewMode, query: String = ""): List<LibraryGroup> {
        val tracks = search(snapshot.tracks, query)
        val groups = when (mode) {
            LibraryViewMode.FOLDER -> tracks.groupBy { it.item.folderPath }.map { (path, members) ->
                LibraryGroup(
                    key = "folder:$path",
                    title = path.substringAfterLast('/').ifEmpty { "(Folder utama)" },
                    subtitle = path,
                    tracks = members.sortedWith(byFileName),
                )
            }

            LibraryViewMode.ALBUM -> tracks.groupBy { track ->
                val album = normalizeKey(track.tags.album)
                // Tanpa Album Artist, dua album bernama sama di folder berbeda tetap dipisah.
                val owner = normalizeKey(track.tags.albumArtist).ifEmpty { "folder:${track.item.folderPath}" }
                if (album.isEmpty()) "album:" else "album:$owner\u0000$album"
            }.map { (key, members) ->
                val first = members.first().tags
                val artists = members.map { it.tags.artist.trim() }.filter { it.isNotEmpty() }.distinct()
                val artist = first.albumArtist.ifBlank {
                    when (artists.size) {
                        0 -> UNKNOWN_ARTIST
                        1 -> artists[0]
                        else -> "Various Artists"
                    }
                }
                LibraryGroup(
                    key = key,
                    title = first.album.ifBlank { UNKNOWN_ALBUM },
                    subtitle = if (key == "album:") "" else artist,
                    tracks = members.sortedWith(albumOrder),
                )
            }

            LibraryViewMode.ARTIST -> tagGroups(tracks, "artist", UNKNOWN_ARTIST) {
                listOf(it.tags.artist.ifBlank { it.tags.albumArtist })
            }

            LibraryViewMode.GENRE -> tagGroups(tracks, "genre", UNKNOWN_GENRE) {
                it.tags.genre.split(';', '\u0000')
            }

            // Tab All Songs tidak memakai grup; daftar lagunya disusun di ViewModel.
            LibraryViewMode.ALL -> emptyList()
        }
        return groups.sortedWith { a, b ->
            val title = NaturalOrder.compare(a.title, b.title)
            if (title != 0) title else NaturalOrder.compare(a.subtitle, b.subtitle)
        }
    }

    private fun tagGroups(
        tracks: List<LibraryTrack>,
        prefix: String,
        unknown: String,
        values: (LibraryTrack) -> List<String>,
    ): List<LibraryGroup> {
        val names = LinkedHashMap<String, String>()
        val members = LinkedHashMap<String, MutableList<LibraryTrack>>()
        for (track in tracks) {
            val all = values(track).map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("") }
            for (value in all.distinctBy { normalizeKey(it) }) {
                val key = normalizeKey(value)
                names.getOrPut(key) { value.ifEmpty { unknown } }
                members.getOrPut(key) { mutableListOf() }.add(track)
            }
        }
        return members.map { (key, list) ->
            LibraryGroup(
                key = "$prefix:$key",
                title = names.getValue(key),
                subtitle = "${list.size} lagu",
                tracks = list.sortedWith(
                    Comparator<LibraryTrack> { a, b -> NaturalOrder.compare(a.tags.album, b.tags.album) }
                        .then(albumOrder),
                ),
            )
        }
    }
}

internal fun normalizeKey(text: String): String =
    Normalizer.normalize(text, Normalizer.Form.NFC).trim().lowercase(Locale.ROOT)

// =====================================================================================
// AKSES DOKUMEN (SAF)
// =====================================================================================

internal data class DocumentEntry(
    val documentId: String,
    val name: String,
    val isDirectory: Boolean,
    val size: Long,
    val lastModified: Long,
)

internal class DocumentStore(private val context: Context) {

    private val resolver get() = context.contentResolver

    fun children(treeUri: Uri, folderId: String): List<DocumentEntry> {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, folderId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        val cursor = resolver.query(uri, projection, null, null, null)
            ?: throw IOException("Folder tidak dapat dibaca")
        val result = mutableListOf<DocumentEntry>()
        cursor.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                result += DocumentEntry(
                    documentId = id,
                    name = name,
                    isDirectory = c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR,
                    size = if (c.isNull(3)) -1L else c.getLong(3),
                    lastModified = if (c.isNull(4)) 0L else c.getLong(4),
                )
            }
        }
        return result
    }

    fun displayName(uri: Uri): String? {
        val cursor = resolver.query(
            uri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null,
        ) ?: return null
        return cursor.use { if (it.moveToNext()) it.getString(0) else null }
    }

    fun rename(uri: Uri, newName: String): Uri {
        val renamed = DocumentsContract.renameDocument(resolver, uri, newName)
        if (renamed != null) return renamed
        // Sebagian provider mengembalikan null bila ID dokumen tidak berubah.
        if (displayName(uri) == newName) return uri
        throw IOException("Provider menolak mengganti nama menjadi \"$newName\"")
    }

    fun create(treeUri: Uri, parentId: String, name: String): Uri {
        val parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, parentId)
        // MIME generik agar provider tidak menambahkan ekstensi sendiri.
        return DocumentsContract.createDocument(resolver, parent, "application/octet-stream", name)
            ?: throw IOException("File \"$name\" tidak dapat dibuat")
    }

    fun delete(uri: Uri) {
        DocumentsContract.deleteDocument(resolver, uri)
    }

    fun write(uri: Uri, bytes: ByteArray) {
        val stream = resolver.openOutputStream(uri, "rwt") ?: throw IOException("File tidak dapat ditulis")
        stream.use {
            it.write(bytes)
            it.flush()
        }
    }

    fun read(uri: Uri, limit: Int): ByteArray {
        val stream = resolver.openInputStream(uri) ?: throw IOException("File tidak dapat dibuka")
        stream.use { input ->
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                output.write(buffer, 0, count)
                if (output.size() > limit) throw IOException("File terlalu besar")
            }
            return output.toByteArray()
        }
    }
}

// =====================================================================================
// PEMINDAI PERPUSTAKAAN + CACHE METADATA
// =====================================================================================

internal data class CachedTags(val size: Long, val lastModified: Long, val tags: TrackTags)

/** Cache biner kecil agar pemindaian ulang tidak membaca semua file lagi. */
internal object IndexCache {
    private const val VERSION = 1
    private const val MAX_TEXT = 4000

    fun load(file: File): Map<String, CachedTags> {
        if (!file.isFile) return emptyMap()
        return runCatching {
            DataInputStream(file.inputStream().buffered()).use { input ->
                if (input.readInt() != VERSION) return emptyMap()
                val count = input.readInt()
                val result = HashMap<String, CachedTags>()
                repeat(count) {
                    val id = input.readUTF()
                    val size = input.readLong()
                    val modified = input.readLong()
                    val tags = TrackTags(
                        title = input.readUTF(),
                        artist = input.readUTF(),
                        albumArtist = input.readUTF(),
                        album = input.readUTF(),
                        genre = input.readUTF(),
                        year = input.readUTF(),
                        trackNumber = input.readInt().takeIf { it >= 0 },
                        discNumber = input.readInt().takeIf { it >= 0 },
                        durationMs = input.readLong(),
                    )
                    result[id] = CachedTags(size, modified, tags)
                }
                result
            }
        }.getOrDefault(emptyMap()) // Cache rusak cukup dibangun ulang.
    }

    fun save(file: File, entries: Map<String, CachedTags>) {
        val temp = File(file.parentFile, "${file.name}.tmp")
        DataOutputStream(temp.outputStream().buffered()).use { out ->
            out.writeInt(VERSION)
            out.writeInt(entries.size)
            entries.forEach { (id, entry) ->
                out.writeUTF(id)
                out.writeLong(entry.size)
                out.writeLong(entry.lastModified)
                with(entry.tags) {
                    listOf(title, artist, albumArtist, album, genre, year)
                        .forEach { out.writeUTF(it.take(MAX_TEXT)) }
                    out.writeInt(trackNumber ?: -1)
                    out.writeInt(discNumber ?: -1)
                    out.writeLong(durationMs)
                }
            }
        }
        if (!temp.renameTo(file)) {
            temp.delete()
            throw IOException("Cache perpustakaan gagal disimpan")
        }
    }
}

/**
 * Cache seluruh daftar perpustakaan (folder, lagu beserta metadata, playlist) supaya aplikasi bisa
 * menampilkan daftar secara instan saat dibuka kembali, tanpa menelusuri folder lagi.
 * URI dibangun ulang dari folder akar + documentId, jadi tidak ikut disimpan.
 */
internal object SnapshotCache {
    private const val VERSION = 1
    private const val MAX_TEXT = 4000

    fun save(file: File, snapshot: LibrarySnapshot) {
        val temp = File(file.parentFile, "${file.name}.tmp")
        DataOutputStream(temp.outputStream().buffered()).use { out ->
            out.writeInt(VERSION)
            out.writeInt(snapshot.folders.size)
            snapshot.folders.forEach {
                out.writeUTF(it.documentId)
                out.writeUTF(it.name)
                out.writeUTF(it.path)
            }
            out.writeInt(snapshot.tracks.size)
            snapshot.tracks.forEach { track ->
                out.writeUTF(track.documentId)
                out.writeUTF(track.item.displayName)
                out.writeUTF(track.item.folderPath)
                out.writeUTF(track.item.parentDocumentId)
                out.writeLong(track.item.sizeBytes)
                out.writeLong(track.lastModified)
                with(track.tags) {
                    listOf(title, artist, albumArtist, album, genre, year)
                        .forEach { out.writeUTF(it.take(MAX_TEXT)) }
                    out.writeInt(trackNumber ?: -1)
                    out.writeInt(discNumber ?: -1)
                    out.writeLong(durationMs)
                }
            }
            out.writeInt(snapshot.playlists.size)
            snapshot.playlists.forEach {
                out.writeUTF(it.documentId)
                out.writeUTF(it.name)
                out.writeUTF(it.folderPath)
                out.writeUTF(it.parentDocumentId)
            }
        }
        if (!temp.renameTo(file)) {
            temp.delete()
            throw IOException("Cache daftar lagu gagal disimpan")
        }
    }

    /** Null bila cache belum ada, versinya beda, atau rusak. */
    fun load(file: File, treeUri: Uri): LibrarySnapshot? {
        if (!file.isFile) return null
        return runCatching {
            DataInputStream(file.inputStream().buffered()).use { input ->
                if (input.readInt() != VERSION) return null
                fun uri(id: String) = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                val folders = List(input.readInt()) {
                    LibraryFolder(input.readUTF(), input.readUTF(), input.readUTF())
                }
                val tracks = List(input.readInt()) {
                    val id = input.readUTF()
                    val name = input.readUTF()
                    val folderPath = input.readUTF()
                    val parent = input.readUTF()
                    val size = input.readLong()
                    val modified = input.readLong()
                    val tags = TrackTags(
                        title = input.readUTF(),
                        artist = input.readUTF(),
                        albumArtist = input.readUTF(),
                        album = input.readUTF(),
                        genre = input.readUTF(),
                        year = input.readUTF(),
                        trackNumber = input.readInt().takeIf { n -> n >= 0 },
                        discNumber = input.readInt().takeIf { n -> n >= 0 },
                        durationMs = input.readLong(),
                    )
                    LibraryTrack(AudioItem(uri(id), name, folderPath, parent, size), id, modified, tags)
                }
                val playlists = List(input.readInt()) {
                    val id = input.readUTF()
                    PlaylistFile(uri(id), id, input.readUTF(), input.readUTF(), input.readUTF())
                }
                LibrarySnapshot(treeUri, folders, tracks, playlists, emptyList())
            }
        }.getOrNull() // Cache rusak: perlu pindai sekali lagi.
    }
}

internal class LibraryScanner(
    private val context: Context,
    private val store: DocumentStore,
    private val engine: TagAndReplayGainEngine,
) {
    private val invalidated: MutableSet<String> = ConcurrentHashMap.newKeySet()

    fun invalidate(documentIds: Collection<String>) {
        invalidated.addAll(documentIds)
    }

    suspend fun scan(treeUri: Uri, forceReread: Boolean, onProgress: (ScanProgress) -> Unit): LibrarySnapshot =
        withContext(Dispatchers.IO) {
            val folders = mutableListOf<LibraryFolder>()
            val playlists = mutableListOf<PlaylistFile>()
            val warnings = mutableListOf<String>()
            val found = mutableListOf<Pair<AudioItem, DocumentEntry>>()

            val rootId = DocumentsContract.getTreeDocumentId(treeUri)
            val pending = ArrayDeque<LibraryFolder>()
            pending.add(LibraryFolder(rootId, "", ""))
            val visited = HashSet<String>()

            while (pending.isNotEmpty()) {
                coroutineContext.ensureActive()
                val folder = pending.removeFirst()
                if (!visited.add(folder.documentId)) continue
                val entries = try {
                    store.children(treeUri, folder.documentId)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    if (folder.path.isEmpty()) throw IOException("Folder utama tidak dapat dibaca: ${e.message}", e)
                    warnings += "Folder dilewati: ${folder.path} (${e.message})"
                    continue
                }
                folders += folder
                for (entry in entries) {
                    if (entry.name.startsWith(".")) continue
                    val extension = entry.name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    if (entry.isDirectory) {
                        pending.add(LibraryFolder(entry.documentId, entry.name, joinPath(folder.path, entry.name)))
                    } else if (extension in SUPPORTED_EXTENSIONS) {
                        val item = AudioItem(
                            uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, entry.documentId),
                            displayName = entry.name,
                            folderPath = folder.path,
                            parentDocumentId = folder.documentId,
                            sizeBytes = entry.size,
                        )
                        found += item to entry
                    } else if (extension == "m3u" || extension == "m3u8") {
                        playlists += PlaylistFile(
                            uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, entry.documentId),
                            documentId = entry.documentId,
                            name = entry.name,
                            folderPath = folder.path,
                            parentDocumentId = folder.documentId,
                        )
                    }
                }
                onProgress(ScanProgress(folders.size, found.size, 0, folder.path))
            }

            val cacheFile = cacheFileFor(treeUri)
            val cache = if (forceReread) emptyMap() else IndexCache.load(cacheFile)
            val updated = ConcurrentHashMap<String, CachedTags>()
            val done = AtomicInteger(0)
            val gate = Semaphore(3)
            val failures = ConcurrentHashMap<String, String>()

            // Diproses per kelompok agar ribuan file tidak membuat ribuan coroutine sekaligus.
            val tracks = found.chunked(CHUNK).flatMap { chunk ->
                coroutineScope {
                    chunk.map { (item, entry) ->
                        async {
                            gate.withPermit {
                                val old = cache[entry.documentId]
                                val fresh = old != null && entry.lastModified > 0 &&
                                    old.size == entry.size && old.lastModified == entry.lastModified &&
                                    entry.documentId !in invalidated
                                val tags = if (fresh) {
                                    old!!.tags
                                } else {
                                    try {
                                        readTags(item)
                                    } catch (e: CancellationException) {
                                        throw e
                                    } catch (e: Exception) {
                                        failures[item.displayName] = e.message ?: e.javaClass.simpleName
                                        null
                                    }
                                }
                                // Hasil gagal tidak di-cache supaya dicoba lagi nanti.
                                if (tags != null) {
                                    updated[entry.documentId] = CachedTags(entry.size, entry.lastModified, tags)
                                    invalidated.remove(entry.documentId)
                                }
                                onProgress(
                                    ScanProgress(folders.size, found.size, done.incrementAndGet(), item.displayName),
                                )
                                LibraryTrack(item, entry.documentId, entry.lastModified, tags ?: TrackTags())
                            }
                        }
                    }.awaitAll()
                }
            }

            failures.forEach { (name, message) -> warnings += "Tag tidak terbaca: $name ($message)" }
            runCatching { IndexCache.save(cacheFile, updated) }
                .onFailure { warnings += it.message ?: "Cache gagal disimpan" }

            val snapshot = LibrarySnapshot(treeUri, folders, tracks, playlists, warnings)
            runCatching { SnapshotCache.save(snapshotFileFor(treeUri), snapshot) }
                .onFailure { warnings += it.message ?: "Cache daftar lagu gagal disimpan" }
            snapshot
        }

    /** Daftar lagu tersimpan dari pemindaian terakhir, atau null bila belum ada. */
    suspend fun loadSnapshot(treeUri: Uri): LibrarySnapshot? =
        withContext(Dispatchers.IO) { SnapshotCache.load(snapshotFileFor(treeUri), treeUri) }

    /** Jalur cepat tanpa menyalin file. Bila platform tidak membaca tag, pakai engine. */
    private suspend fun readTags(item: AudioItem): TrackTags {
        val quick = if (item.extension == "wav") null else readWithPlatform(item.uri)
        if (quick != null && (quick.title.isNotEmpty() || quick.artist.isNotEmpty() || quick.album.isNotEmpty())) {
            return quick
        }
        val full = engine.readMetadata(item, includeCover = false)
        return TrackTags(
            title = full.title,
            artist = full.artist,
            albumArtist = full.albumArtist,
            album = full.album,
            genre = full.genre,
            year = full.year,
            trackNumber = leadingNumber(full.trackNumber),
            discNumber = leadingNumber(full.discNumber),
            durationMs = full.durationSeconds * 1000L,
        )
    }

    private fun readWithPlatform(uri: Uri): TrackTags? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            fun value(key: Int): String = retriever.extractMetadata(key)?.trim().orEmpty()
            TrackTags(
                title = value(MediaMetadataRetriever.METADATA_KEY_TITLE),
                artist = value(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                albumArtist = value(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST),
                album = value(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                genre = value(MediaMetadataRetriever.METADATA_KEY_GENRE),
                year = value(MediaMetadataRetriever.METADATA_KEY_YEAR)
                    .ifEmpty { value(MediaMetadataRetriever.METADATA_KEY_DATE).take(4) },
                trackNumber = leadingNumber(value(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER)),
                discNumber = leadingNumber(value(MediaMetadataRetriever.METADATA_KEY_DISC_NUMBER)),
                durationMs = value(MediaMetadataRetriever.METADATA_KEY_DURATION).toLongOrNull() ?: 0L,
            )
        } catch (e: RuntimeException) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    /** "3/12" -> 3 */
    private fun leadingNumber(text: String): Int? =
        text.trim().takeWhile { it in '0'..'9' }.toIntOrNull()?.takeIf { it > 0 }

    private fun hashOf(treeUri: Uri): String =
        MessageDigest.getInstance("SHA-1").digest(treeUri.toString().toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun cacheFileFor(treeUri: Uri): File = File(context.filesDir, "library-${hashOf(treeUri)}.idx")

    private fun snapshotFileFor(treeUri: Uri): File = File(context.filesDir, "snapshot-${hashOf(treeUri)}.bin")

    private companion object {
        const val CHUNK = 64
    }
}

// =====================================================================================
// ALAT TAG: AUTO-NUMBERING
// =====================================================================================

enum class NumberingOrder {
    /** Urutan daftar yang dipilih pengguna. */
    AS_SELECTED,

    /** Urutan alami nama file: 2 sebelum 10. */
    FILE_NAME,

    /** Urutan nomor disc dan trek yang sekarang ada di tag. */
    CURRENT_TAGS,
}

data class AutoNumberOptions(
    val startNumber: Int = 1,
    /** 2 menghasilkan 01, 02, 03. Format M4A menyimpan angka tanpa nol di depan. */
    val padWidth: Int = 2,
    val writeTotal: Boolean = false,
    /** true = penomoran diulang untuk setiap folder (satu folder = satu album/disc). */
    val restartPerFolder: Boolean = true,
    /** Bila diisi, nomor disc ini ikut ditulis. */
    val discNumber: Int? = null,
    val order: NumberingOrder = NumberingOrder.FILE_NAME,
)

data class NumberingPreview(
    val track: LibraryTrack,
    val trackNumber: String,
    val trackTotal: String?,
    val discNumber: String?,
) {
    fun toEdit(): TagEdit = TagEdit(trackNumber = trackNumber, trackTotal = trackTotal, discNumber = discNumber)
}

object AutoNumbering {
    fun plan(selection: List<LibraryTrack>, options: AutoNumberOptions): List<NumberingPreview> {
        require(options.startNumber >= 1) { "Nomor awal minimal 1" }
        require(options.padWidth in 1..4) { "Lebar angka harus 1-4" }
        require(options.discNumber == null || options.discNumber in 1..9999) { "Nomor disc tidak valid" }
        val unique = selection.distinctBy { it.documentId }
        val groups: List<List<LibraryTrack>> =
            if (options.restartPerFolder) unique.groupBy { it.item.parentDocumentId }.values.toList()
            else listOf(unique)

        return groups.flatMap { group ->
            val ordered = when (options.order) {
                NumberingOrder.AS_SELECTED -> group
                NumberingOrder.FILE_NAME -> group.sortedWith { a, b ->
                    val folder = NaturalOrder.compare(a.item.folderPath, b.item.folderPath)
                    if (folder != 0) folder else NaturalOrder.compare(a.item.displayName, b.item.displayName)
                }
                NumberingOrder.CURRENT_TAGS -> group.sortedWith(LibraryViews.albumOrder)
            }
            val last = options.startNumber + ordered.size - 1
            require(last <= 9999) { "Nomor trek melebihi 9999" }
            ordered.mapIndexed { index, track ->
                NumberingPreview(
                    track = track,
                    trackNumber = (options.startNumber + index).toString().padStart(options.padWidth, '0'),
                    trackTotal = if (options.writeTotal) last.toString().padStart(options.padWidth, '0') else null,
                    discNumber = options.discNumber?.toString(),
                )
            }
        }
    }
}

// =====================================================================================
// ALAT TAG: POLA NAMA FILE
// =====================================================================================

enum class FilenameField(val placeholders: List<String>) {
    TRACK(listOf("tracknumber", "track")),
    DISC(listOf("discnumber", "disc")),
    TITLE(listOf("title")),
    ARTIST(listOf("artist")),
    ALBUM_ARTIST(listOf("albumartist", "album artist")),
    ALBUM(listOf("album")),
    YEAR(listOf("year", "date")),
    GENRE(listOf("genre")),

    /** Bagian nama file yang diabaikan. */
    SKIP(listOf("dummy", "skip"));

    val isNumber: Boolean get() = this == TRACK || this == DISC
}

/** Pola bergaya foobar2000/Mp3tag, mis. "%tracknumber% - %title%". */
class FilenamePattern private constructor(val source: String, private val segments: List<List<Token>>) {

    private sealed interface Token
    private data class Literal(val text: String) : Token
    private data class Field(val field: FilenameField) : Token

    private val fields: List<FilenameField> = segments.flatten().filterIsInstance<Field>().map { it.field }

    private val regexes: List<Regex> by lazy {
        segments.map { tokens ->
            val expression = StringBuilder()
            tokens.forEachIndexed { index, token ->
                when (token) {
                    is Literal -> token.text.split(WHITESPACE).forEachIndexed { i, part ->
                        if (i > 0) expression.append("\\s+")
                        if (part.isNotEmpty()) expression.append(Regex.escape(part))
                    }
                    is Field -> expression.append(
                        when {
                            token.field.isNumber -> "([0-9]{1,4})"
                            token.field == FilenameField.YEAR -> "([0-9]{4})"
                            index == tokens.lastIndex -> "(.+)"
                            else -> "(.+?)"
                        },
                    )
                }
            }
            Regex(expression.toString())
        }
    }

    /**
     * Mencocokkan pola dengan nama file (tanpa ekstensi). Pola yang mengandung "/" juga
     * mencocokkan nama folder induk, mis. "%album%/%tracknumber% - %title%".
     * Mengembalikan null bila tidak cocok.
     */
    fun match(folderPath: String, fileName: String): Map<FilenameField, String>? {
        val base = fileName.substringBeforeLast('.', fileName)
        val parts = folderPath.split('/').filter { it.isNotEmpty() } + base
        if (parts.size < segments.size) return null
        val relevant = parts.takeLast(segments.size)
        val values = LinkedHashMap<FilenameField, String>()
        segments.forEachIndexed { index, tokens ->
            val result = regexes[index].matchEntire(relevant[index].trim()) ?: return null
            var group = 1
            tokens.filterIsInstance<Field>().forEach { token ->
                val value = result.groupValues[group++].trim()
                if (token.field != FilenameField.SKIP) {
                    if (value.isEmpty()) return null
                    val previous = values.put(token.field, value)
                    if (previous != null && previous != value) return null
                }
            }
        }
        return values
    }

    /** Membuat nama file (tanpa ekstensi) dari nilai tag. */
    fun format(values: Map<FilenameField, String>, trackPadding: Int = 2): String {
        require(segments.size == 1) { "Pola ganti nama tidak boleh mengandung \"/\" (file tidak dipindahkan)" }
        require(FilenameField.SKIP !in fields) { "%dummy% hanya untuk Filename to Tag" }
        val result = StringBuilder()
        segments[0].forEach { token ->
            when (token) {
                is Literal -> result.append(FileNames.cleanPart(token.text))
                is Field -> {
                    var value = values[token.field]?.trim().orEmpty()
                    require(value.isNotEmpty()) { "Tag %${token.field.placeholders[0]}% kosong" }
                    if (token.field.isNumber) {
                        value = value.substringBefore('/').trim()
                        val number = value.toIntOrNull()
                        if (number != null) {
                            val width = if (token.field == FilenameField.TRACK) trackPadding else 1
                            value = number.toString().padStart(width, '0')
                        }
                    }
                    result.append(FileNames.cleanPart(value))
                }
            }
        }
        return result.toString()
    }

    companion object {
        private val WHITESPACE = Regex("\\s+")
        private val PLACEHOLDER = Regex("%([^%/]+)%")

        fun parse(source: String): FilenamePattern {
            require(source.isNotBlank()) { "Pola tidak boleh kosong" }
            val segments = source.trim().split('/').map { segment ->
                val tokens = mutableListOf<Token>()
                var position = 0
                for (found in PLACEHOLDER.findAll(segment)) {
                    if (found.range.first > position) {
                        tokens += Literal(segment.substring(position, found.range.first))
                    }
                    val name = found.groupValues[1].lowercase(Locale.ROOT)
                    val field = FilenameField.entries.firstOrNull { name in it.placeholders }
                        ?: throw IllegalArgumentException("Placeholder tidak dikenal: %$name%")
                    require(tokens.lastOrNull() !is Field) { "Beri pemisah di antara dua placeholder" }
                    tokens += Field(field)
                    position = found.range.last + 1
                }
                if (position < segment.length) tokens += Literal(segment.substring(position))
                require(tokens.isNotEmpty()) { "Pola memiliki bagian kosong" }
                require(tokens.filterIsInstance<Literal>().none { '%' in it.text }) { "Tanda % tidak berpasangan" }
                tokens.toList()
            }
            require(segments.flatten().any { it is Field }) { "Pola harus berisi minimal satu placeholder" }
            return FilenamePattern(source.trim(), segments)
        }

        /** Pola yang dicoba berurutan pada mode otomatis. */
        val AUTO_PRESETS: List<String> = listOf(
            "%discnumber%-%tracknumber% - %title%",
            "%discnumber%-%tracknumber% %title%",
            "%tracknumber% - %title%",
            "%tracknumber%. %title%",
            "%tracknumber%) %title%",
            "%tracknumber%_%title%",
            "%tracknumber%-%title%",
            "%tracknumber% %title%",
            "%artist% - %title%",
            "%title%",
        )
    }
}

object FileNames {
    private const val MAX_BYTES = 240

    /** Mengganti karakter yang ditolak FAT32/exFAT/Windows. */
    fun cleanPart(text: String): String = buildString {
        for (c in text) {
            append(
                when {
                    c == '/' || c == '\\' || c == ':' || c == '|' -> '-'
                    c == '"' -> '\''
                    c == '*' || c == '?' || c == '<' || c == '>' -> '_'
                    c.code < 32 || c.code == 127 -> ' '
                    else -> c
                },
            )
        }
    }

    /** Nama file aman (dengan ekstensi) atau exception bila hasilnya kosong. */
    fun build(base: String, extension: String): String {
        var name = cleanPart(base).replace(Regex("\\s+"), " ").trim().trimStart('.').trimEnd('.', ' ')
        require(name.isNotEmpty()) { "Nama file hasil kosong" }
        val suffix = if (extension.isEmpty()) "" else ".$extension"
        while ((name + suffix).toByteArray(Charsets.UTF_8).size > MAX_BYTES) {
            name = name.substring(0, name.offsetByCodePoints(name.length, -1))
        }
        return name.trimEnd('.', ' ') + suffix
    }
}

data class FilenameToTagPreview(
    val track: LibraryTrack,
    val matchedPattern: String?,
    val values: Map<FilenameField, String>,
    val error: String?,
) {
    fun toEdit(): TagEdit = TagEdit(
        title = values[FilenameField.TITLE],
        artist = values[FilenameField.ARTIST],
        albumArtist = values[FilenameField.ALBUM_ARTIST],
        album = values[FilenameField.ALBUM],
        genre = values[FilenameField.GENRE],
        year = values[FilenameField.YEAR],
        trackNumber = values[FilenameField.TRACK],
        discNumber = values[FilenameField.DISC],
    )
}

object FilenameToTag {
    /**
     * @param pattern null = deteksi otomatis dari [FilenamePattern.AUTO_PRESETS].
     * @param underscoresToSpaces ubah "_" pada hasil menjadi spasi.
     */
    fun plan(
        selection: List<LibraryTrack>,
        pattern: String?,
        underscoresToSpaces: Boolean = true,
    ): List<FilenameToTagPreview> {
        val automatic = pattern == null
        val candidates = (if (pattern == null) FilenamePattern.AUTO_PRESETS else listOf(pattern))
            .map { FilenamePattern.parse(it) }

        return selection.distinctBy { it.documentId }.map { track ->
            for (candidate in candidates) {
                val raw = candidate.match(track.item.folderPath, track.item.displayName) ?: continue
                // Pada mode otomatis, pola disc-trek hanya sah bila nomor trek minimal 2 digit.
                if (automatic && FilenameField.DISC in raw && (raw[FilenameField.TRACK]?.length ?: 0) < 2) continue
                val values = raw.mapValues { (field, value) ->
                    when {
                        field == FilenameField.TRACK -> normalizeNumber(value, 2)
                        field == FilenameField.DISC -> normalizeNumber(value, 1)
                        underscoresToSpaces -> value.replace('_', ' ').trim()
                        else -> value
                    }
                }
                if (values.any { it.value.isEmpty() }) continue
                return@map FilenameToTagPreview(track, candidate.source, values, null)
            }
            FilenameToTagPreview(track, null, emptyMap(), "Nama file tidak cocok dengan pola")
        }
    }

    /** Nomor 0 dianggap tidak valid dan menghasilkan teks kosong. */
    private fun normalizeNumber(text: String, width: Int): String {
        val number = text.toIntOrNull() ?: return ""
        return if (number <= 0) "" else number.toString().padStart(width, '0')
    }
}

// =====================================================================================
// ALAT TAG: GANTI NAMA FILE DARI TAG
// =====================================================================================

enum class RenameStatus { READY, UNCHANGED, CONFLICT, ERROR }

data class RenamePreview(
    val track: LibraryTrack,
    val newName: String,
    val status: RenameStatus,
    val message: String? = null,
)

data class RenamedFile(
    val oldDocumentId: String,
    val oldPath: String,
    val newPath: String,
    val newName: String,
    val newUri: Uri,
    val newDocumentId: String?,
)

data class RenameReport(val renamed: List<RenamedFile>, val failed: List<ItemFailure>)

object RenamePlanner {
    /**
     * Menandai bentrokan. [namesByFolder] berisi SEMUA nama di tiap folder (kunci:
     * parentDocumentId). Perbandingan tidak membedakan huruf besar/kecil karena
     * penyimpanan bersama Android juga demikian.
     */
    fun resolveConflicts(
        previews: List<RenamePreview>,
        namesByFolder: Map<String, Collection<String>>,
    ): List<RenamePreview> {
        fun key(name: String) = normalizeKey(name)
        val result = previews.toMutableList()
        var changed = true
        while (changed) {
            changed = false
            val ready = result.indices.filter { result[it].status == RenameStatus.READY }
            val targets = ready.groupBy {
                result[it].track.item.parentDocumentId to key(result[it].newName)
            }
            val leaving = ready.groupBy({ result[it].track.item.parentDocumentId }) {
                result[it].track.item.displayName
            }
            for ((target, indices) in targets) {
                val (folder, name) = target
                val freed = leaving[folder].orEmpty().toHashSet()
                val occupied = namesByFolder[folder].orEmpty().any { it !in freed && key(it) == name }
                if (indices.size > 1 || occupied) {
                    val message = if (indices.size > 1) "Beberapa file menghasilkan nama yang sama"
                    else "Nama sudah dipakai file lain"
                    indices.forEach { result[it] = result[it].copy(status = RenameStatus.CONFLICT, message = message) }
                    changed = true
                }
            }
        }
        return result
    }
}

/** Operasi ganti nama yang bisa diganti saat pengujian. */
internal fun interface Renamer {
    fun rename(uri: Uri, newName: String): Uri
}

internal class RenameExecutor(private val renamer: Renamer) {

    private class Step(val preview: RenamePreview) {
        val originalName = preview.track.item.displayName
        var uri: Uri = preview.track.item.uri
        var currentName = originalName
    }

    private fun move(step: Step, name: String) {
        step.uri = renamer.rename(step.uri, name)
        step.currentName = name
    }

    private fun temporaryName(step: Step): String {
        val extension = step.originalName.substringAfterLast('.', "")
        return "tbd-tmp-${UUID.randomUUID().toString().take(8)}.$extension"
    }

    /**
     * Menjalankan semua item READY dalam SATU folder. Bila satu gagal, seluruh folder
     * dikembalikan ke nama semula. [actualName] membaca nama yang benar-benar dipakai provider.
     */
    fun runFolder(items: List<RenamePreview>, actualName: (Uri) -> String?): Result<List<Pair<RenamePreview, Uri>>> {
        val steps = items.map { Step(it) }
        val oldNames = steps.mapTo(HashSet()) { normalizeKey(it.originalName) }
        return try {
            // Tahap 1: nama yang bertukar atau hanya beda huruf besar/kecil lewat nama sementara.
            steps.filter { normalizeKey(it.preview.newName) in oldNames }
                .forEach { move(it, temporaryName(it)) }
            // Tahap 2: nama akhir.
            steps.forEach { step ->
                move(step, step.preview.newName)
                val actual = actualName(step.uri)
                if (actual != null && normalizeKey(actual) != normalizeKey(step.preview.newName)) {
                    step.currentName = actual
                    throw IOException("Provider mengubah nama menjadi \"$actual\"")
                }
            }
            Result.success(steps.map { it.preview to it.uri })
        } catch (error: Exception) {
            val stuck = rollback(steps)
            val note = if (stuck.isEmpty()) "Semua nama di folder ini dikembalikan."
            else "Periksa manual: ${stuck.joinToString()}"
            Result.failure(IOException("${error.message}. $note", error))
        }
    }

    /** Mengembalikan daftar file yang gagal dipulihkan. */
    private fun rollback(steps: List<Step>): List<String> {
        val changed = steps.filter { it.currentName != it.originalName }
        // Pindahkan dulu ke nama sementara agar pengembalian tidak saling bertabrakan.
        changed.forEach { step -> runCatching { move(step, temporaryName(step)) } }
        return changed.mapNotNull { step ->
            runCatching { move(step, step.originalName) }.exceptionOrNull()
                ?.let { "${step.currentName} (asal: ${step.originalName})" }
        }
    }
}

// =====================================================================================
// PLAYLIST
// =====================================================================================

private val playlistEntryIds = AtomicLong(1)

data class PlaylistEntry(
    /** ID unik untuk key LazyColumn; satu lagu boleh muncul lebih dari sekali. */
    val id: Long,
    /** Path seperti tertulis di file M3U, atau path perpustakaan untuk lagu baru. */
    val rawPath: String,
    val title: String,
    val durationSeconds: Int,
    /** null bila file tidak ditemukan di perpustakaan. */
    val track: LibraryTrack?,
    /** true bila hanya cocok berdasarkan ujung path; sebaiknya diperiksa pengguna. */
    val approximate: Boolean = false,
) {
    val isMissing: Boolean get() = track == null

    companion object {
        fun of(track: LibraryTrack): PlaylistEntry = PlaylistEntry(
            id = playlistEntryIds.getAndIncrement(),
            rawPath = track.path,
            title = M3uCodec.displayTitle(track),
            durationSeconds = durationOf(track),
            track = track,
        )

        internal fun durationOf(track: LibraryTrack): Int =
            if (track.tags.durationMs > 0) ((track.tags.durationMs + 500) / 1000).toInt() else -1

        internal fun nextId(): Long = playlistEntryIds.getAndIncrement()
    }
}

/** Playlist immutable: setiap operasi mengembalikan salinan baru. */
data class Playlist(
    val name: String = "Playlist Baru",
    val entries: List<PlaylistEntry> = emptyList(),
    /** File asal bila playlist ini hasil impor. */
    val source: Uri? = null,
    /** documentId folder tempat file asal berada, bila diketahui. */
    val sourceFolderId: String? = null,
) {
    val totalDurationSeconds: Long get() = entries.sumOf { max0(it.durationSeconds).toLong() }

    private fun max0(value: Int) = if (value < 0) 0 else value

    fun add(tracks: List<LibraryTrack>, at: Int = entries.size): Playlist {
        val updated = entries.toMutableList()
        updated.addAll(at.coerceIn(0, entries.size), tracks.map { PlaylistEntry.of(it) })
        return copy(entries = updated)
    }

    fun remove(ids: Set<Long>): Playlist = copy(entries = entries.filterNot { it.id in ids })

    fun remove(id: Long): Playlist = remove(setOf(id))

    /** Memindahkan satu entri (untuk drag-and-drop). */
    fun move(from: Int, to: Int): Playlist {
        if (from !in entries.indices) return this
        val updated = entries.toMutableList()
        val entry = updated.removeAt(from)
        updated.add(to.coerceIn(0, updated.size), entry)
        return copy(entries = updated)
    }

    fun moveUp(id: Long): Playlist {
        val index = entries.indexOfFirst { it.id == id }
        return if (index <= 0) this else move(index, index - 1)
    }

    fun moveDown(id: Long): Playlist {
        val index = entries.indexOfFirst { it.id == id }
        return if (index < 0 || index == entries.lastIndex) this else move(index, index + 1)
    }

    fun clear(): Playlist = copy(entries = emptyList())

    /** Memperbarui entri setelah file diganti namanya atau perpustakaan dipindai ulang. */
    fun relink(snapshot: LibrarySnapshot, renames: List<RenamedFile> = emptyList()): Playlist {
        val byPath = snapshot.tracks.associateBy { it.path }
        val renamed = renames.associate { it.oldPath to it.newPath }
        return copy(
            entries = entries.map { entry ->
                val current = entry.track ?: return@map entry
                val newPath = renamed[current.path]
                val track = byPath[newPath ?: current.path]
                if (track == null) {
                    entry.copy(track = null)
                } else {
                    entry.copy(
                        track = track,
                        rawPath = if (newPath != null) track.path else entry.rawPath,
                        title = M3uCodec.displayTitle(track),
                        durationSeconds = PlaylistEntry.durationOf(track),
                    )
                }
            },
        )
    }
}

// -------------------------------------------------------------------------------- M3U

enum class PlaylistFormat(val extension: String) { M3U8("m3u8"), M3U("m3u") }

data class M3uLine(val path: String, val title: String, val durationSeconds: Int)

data class M3uDocument(val name: String?, val lines: List<M3uLine>)

object M3uCodec {
    private const val BOM = "﻿"

    fun displayTitle(track: LibraryTrack): String =
        if (track.tags.artist.isBlank()) track.displayTitle
        else "${track.tags.artist} - ${track.displayTitle}"

    /** Mendukung UTF-8/UTF-16 ber-BOM, UTF-8 polos, dan Windows-1252 untuk file lama. */
    fun decode(bytes: ByteArray): String {
        fun startsWith(vararg prefix: Int) =
            bytes.size >= prefix.size && prefix.indices.all { bytes[it] == prefix[it].toByte() }
        return when {
            startsWith(0xEF, 0xBB, 0xBF) -> String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
            startsWith(0xFF, 0xFE) -> String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
            startsWith(0xFE, 0xFF) -> String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
            else -> try {
                Charsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(bytes))
                    .toString()
            } catch (e: CharacterCodingException) {
                String(bytes, Charset.forName("windows-1252"))
            }
        }
    }

    fun parse(text: String): M3uDocument {
        var name: String? = null
        var title = ""
        var duration = -1
        val lines = mutableListOf<M3uLine>()
        for (raw in text.removePrefix(BOM).split('\n')) {
            val line = raw.trim()
            when {
                line.isEmpty() -> Unit
                line.startsWith("#EXTINF:", ignoreCase = true) -> {
                    val info = line.substring(8)
                    val comma = commaOutsideQuotes(info)
                    val head = if (comma < 0) info else info.substring(0, comma)
                    duration = head.trim().substringBefore(' ').toDoubleOrNull()?.toInt() ?: -1
                    title = if (comma < 0) "" else info.substring(comma + 1).trim()
                }
                line.startsWith("#PLAYLIST:", ignoreCase = true) -> name = line.substring(10).trim()
                line.startsWith("#") -> Unit
                else -> {
                    lines += M3uLine(line, title, duration)
                    title = ""
                    duration = -1
                }
            }
        }
        return M3uDocument(name, lines)
    }

    private fun commaOutsideQuotes(text: String): Int {
        var quoted = false
        text.forEachIndexed { index, c ->
            if (c == '"') quoted = !quoted
            if (c == ',' && !quoted) return index
        }
        return -1
    }

    /**
     * Baris diakhiri CRLF agar rapi di PC. .m3u8 ditulis UTF-8 tanpa BOM. .m3u ditulis UTF-8
     * dengan BOM bila ada huruf non-ASCII, sebagai penanda encoding bagi pemutar desktop.
     */
    fun encode(lines: List<M3uLine>, format: PlaylistFormat): ByteArray {
        val text = buildString {
            append("#EXTM3U\r\n")
            for (line in lines) {
                val title = line.title.replace('\r', ' ').replace('\n', ' ').replace('\u0000', ' ')
                append("#EXTINF:").append(line.durationSeconds).append(',').append(title).append("\r\n")
                require('\n' !in line.path && '\r' !in line.path) { "Path berisi baris baru: ${line.path}" }
                // Nama berawalan "#" akan dianggap komentar.
                if (line.path.startsWith("#")) append("./")
                append(line.path).append("\r\n")
            }
        }
        val needsBom = format == PlaylistFormat.M3U && text.any { it.code > 127 }
        return ((if (needsBom) BOM else "") + text).toByteArray(Charsets.UTF_8)
    }
}

// -------------------------------------------------------------------------------- Path

/** Lokasi nyata di penyimpanan, hanya diketahui untuk provider penyimpanan bawaan Android. */
data class StorageLocation(val volume: String, val segments: List<String>)

object PlaylistPaths {
    private const val EXTERNAL_AUTHORITY = "com.android.externalstorage.documents"

    /** documentId penyimpanan bawaan berbentuk "primary:Music/Album" atau "1A2B-3C4D:Music". */
    fun locationOf(authority: String?, documentId: String): StorageLocation? {
        if (authority != EXTERNAL_AUTHORITY || ':' !in documentId) return null
        val volume = documentId.substringBefore(':')
        val segments = documentId.substringAfter(':').split('/').filter { it.isNotEmpty() }
        // Volume "home" adalah folder Documents di penyimpanan utama.
        return if (volume == "home") StorageLocation("primary", listOf("Documents") + segments)
        else StorageLocation(volume, segments)
    }

    /** Menerjemahkan path absolut Android, mis. /storage/emulated/0/Music/a.flac. */
    fun locationOfAbsolute(path: String): StorageLocation? {
        val parts = path.split('/').filter { it.isNotEmpty() }
        if (!path.startsWith("/") || parts.isEmpty()) return null
        return when {
            parts.size >= 3 && parts[0] == "storage" && parts[1] == "emulated" ->
                StorageLocation("primary", parts.drop(3))
            parts[0] == "sdcard" -> StorageLocation("primary", parts.drop(1))
            parts.size >= 2 && parts[0] == "storage" -> StorageLocation(parts[1], parts.drop(2))
            else -> null
        }
    }

    /** Path relatif dari folder [fromFolder] menuju file [toFile], memakai "/". */
    fun relative(fromFolder: List<String>, toFile: List<String>): String {
        var common = 0
        while (common < fromFolder.size && common < toFile.size - 1 &&
            fromFolder[common].equals(toFile[common], ignoreCase = true)
        ) {
            common++
        }
        return (List(fromFolder.size - common) { ".." } + toFile.drop(common)).joinToString("/")
    }

    /** Menyelesaikan "." dan "..". Mengembalikan null bila keluar di atas akar. */
    fun resolve(base: List<String>, relative: List<String>): List<String>? {
        val result = base.toMutableList()
        for (part in relative) {
            when (part) {
                "", "." -> Unit
                ".." -> if (result.isEmpty()) return null else result.removeAt(result.lastIndex)
                else -> result += part
            }
        }
        return result
    }
}

/** Mencocokkan baris M3U dengan lagu di perpustakaan. */
internal class PlaylistResolver(
    tracks: List<LibraryTrack>,
    private val locationOf: (LibraryTrack) -> StorageLocation?,
) {
    private fun key(segments: List<String>) = normalizeKey(segments.joinToString("/"))

    private val byPath = tracks.groupBy { normalizeKey(it.path) }
    private val byLocation = tracks.mapNotNull { track ->
        locationOf(track)?.let { (it.volume.lowercase(Locale.ROOT) to key(it.segments)) to track }
    }.toMap()
    private val byFileName = tracks.groupBy { normalizeKey(it.item.displayName) }

    data class Match(val track: LibraryTrack, val approximate: Boolean)

    /**
     * @param folderPath folder playlist relatif terhadap akar perpustakaan, bila di dalamnya.
     * @param folderLocation lokasi nyata folder playlist, bila diketahui.
     */
    fun find(rawPath: String, folderPath: String?, folderLocation: StorageLocation?): Match? {
        var path = rawPath.trim()
        if (path.startsWith("file://", ignoreCase = true)) {
            // "+" pada URL file adalah karakter biasa, bukan spasi.
            val encoded = path.substring(7).replace("+", "%2B")
            path = runCatching { URLDecoder.decode(encoded, "UTF-8") }.getOrDefault(path.substring(7))
            if (path.length > 2 && path[0] == '/' && path[2] == ':') path = path.substring(1)
        } else if ("://" in path) {
            return null // URL jaringan.
        }
        path = path.replace('\\', '/')
        val isDrive = path.length >= 2 && path[1] == ':' && path[0].isLetter()
        val isAbsolute = isDrive || path.startsWith("/")
        val parts = path.split('/').filter { it.isNotEmpty() }
        if (parts.isEmpty()) return null

        // 1. Pencocokan pasti.
        if (!isAbsolute) {
            if (folderPath != null) {
                val base = folderPath.split('/').filter { it.isNotEmpty() }
                PlaylistPaths.resolve(base, parts)?.let { resolved ->
                    unique(byPath[key(resolved)], resolved.joinToString("/"))?.let { return Match(it, false) }
                }
            }
            if (folderLocation != null) {
                PlaylistPaths.resolve(folderLocation.segments, parts)?.let { resolved ->
                    byLocation[folderLocation.volume.lowercase(Locale.ROOT) to key(resolved)]
                        ?.let { return Match(it, false) }
                }
            }
        } else if (!isDrive) {
            PlaylistPaths.locationOfAbsolute(path)?.let { location ->
                byLocation[location.volume.lowercase(Locale.ROOT) to key(location.segments)]
                    ?.let { return Match(it, false) }
            }
        }

        // 2. Perkiraan: akhiran path terpanjang yang cocok dengan tepat satu lagu.
        val clean = parts.filterNot { it == "." || it == ".." || (it.length == 2 && it[1] == ':') }
        if (clean.isEmpty()) return null
        val candidates = byFileName[normalizeKey(clean.last())].orEmpty()
        for (length in clean.size downTo 1) {
            val suffix = key(clean.takeLast(length))
            val matches = candidates.filter {
                val full = normalizeKey(it.path)
                full == suffix || full.endsWith("/$suffix")
            }
            if (matches.size == 1) return Match(matches[0], true)
            if (matches.size > 1) return null // Ambigu.
        }
        return null
    }

    /** Bila beberapa path hanya beda huruf besar/kecil, pilih yang persis sama. */
    private fun unique(matches: List<LibraryTrack>?, exact: String): LibraryTrack? = when {
        matches == null -> null
        matches.size == 1 -> matches[0]
        else -> matches.firstOrNull { it.path == exact }
    }
}

/** Folder tujuan ekspor: di dalam perpustakaan, atau hasil ACTION_OPEN_DOCUMENT_TREE lain. */
data class PlaylistDestination(
    val treeUri: Uri,
    val folderDocumentId: String,
    /** Path relatif terhadap akar perpustakaan bila folder berada di dalamnya. */
    val libraryPath: String?,
)

data class ExportResult(
    val uri: Uri,
    val fileName: String,
    val writtenCount: Int,
    /** Entri tak ditemukan yang ditulis apa adanya (path lamanya tidak disesuaikan). */
    val missingKept: Int,
)

class PlaylistExistsException(val fileName: String) : IOException("Playlist \"$fileName\" sudah ada")

internal class PlaylistRepository(private val store: DocumentStore) {

    private fun libraryLocation(track: LibraryTrack): StorageLocation? =
        PlaylistPaths.locationOf(track.item.uri.authority, track.documentId)

    fun export(
        playlist: Playlist,
        snapshot: LibrarySnapshot,
        destination: PlaylistDestination,
        fileName: String,
        format: PlaylistFormat,
        overwrite: Boolean,
        includeMissing: Boolean,
    ): ExportResult {
        val entries = playlist.entries.filter { includeMissing || !it.isMissing }
        require(entries.isNotEmpty()) { "Playlist kosong" }

        val destinationLocation =
            PlaylistPaths.locationOf(destination.treeUri.authority, destination.folderDocumentId)
        // Folder yang dipilih lewat dialog terpisah mungkin sebenarnya berada di dalam perpustakaan.
        val libraryPath = destination.libraryPath
            ?: snapshot.folders.firstOrNull { it.documentId == destination.folderDocumentId }
                ?.takeIf { destination.treeUri.authority == snapshot.treeUri.authority }?.path

        var missing = 0
        val lines = entries.map { entry ->
            val track = entry.track
            val path = if (track == null) {
                missing++
                entry.rawPath
            } else if (libraryPath != null) {
                PlaylistPaths.relative(
                    libraryPath.split('/').filter { it.isNotEmpty() },
                    track.path.split('/'),
                )
            } else {
                val target = libraryLocation(track)
                if (destinationLocation == null || target == null ||
                    !destinationLocation.volume.equals(target.volume, ignoreCase = true)
                ) {
                    throw IOException(
                        "Path relatif tidak bisa dibuat untuk \"${track.item.displayName}\". " +
                            "Pilih folder tujuan di dalam folder musik, atau di penyimpanan yang sama.",
                    )
                }
                PlaylistPaths.relative(destinationLocation.segments, target.segments)
            }
            M3uLine(path, entry.title, entry.durationSeconds)
        }
        val bytes = M3uCodec.encode(lines, format)

        val base = fileName.trim().let { name ->
            val lower = name.lowercase(Locale.ROOT)
            when {
                lower.endsWith(".m3u8") -> name.dropLast(5)
                lower.endsWith(".m3u") -> name.dropLast(4)
                else -> name
            }
        }
        val finalName = FileNames.build(base, format.extension)
        val existing = store.children(destination.treeUri, destination.folderDocumentId)
            .firstOrNull { normalizeKey(it.name) == normalizeKey(finalName) }

        if (existing != null) {
            if (existing.isDirectory || !overwrite) throw PlaylistExistsException(existing.name)
            val uri = DocumentsContract.buildDocumentUriUsingTree(destination.treeUri, existing.documentId)
            val previous = store.read(uri, MAX_PLAYLIST_BYTES)
            try {
                store.write(uri, bytes)
            } catch (e: Exception) {
                runCatching { store.write(uri, previous) }.onFailure { e.addSuppressed(it) }
                throw e
            }
            return ExportResult(uri, existing.name, lines.size, missing)
        }

        val uri = store.create(destination.treeUri, destination.folderDocumentId, finalName)
        try {
            store.write(uri, bytes)
        } catch (e: Exception) {
            runCatching { store.delete(uri) }
            throw e
        }
        return ExportResult(uri, store.displayName(uri) ?: finalName, lines.size, missing)
    }

    fun import(uri: Uri, snapshot: LibrarySnapshot): Playlist {
        val document = M3uCodec.parse(M3uCodec.decode(store.read(uri, MAX_PLAYLIST_BYTES)))
        val documentId = DocumentsContract.getDocumentId(uri)
        val authority = uri.authority

        val known = snapshot.playlists.firstOrNull {
            it.documentId == documentId && it.uri.authority == authority
        }
        val fileLocation = PlaylistPaths.locationOf(authority, documentId)
        val folderLocation = fileLocation?.copy(segments = fileLocation.segments.dropLast(1))
        val folderId = known?.parentDocumentId
            ?: if (fileLocation != null && '/' in documentId) documentId.substringBeforeLast('/') else null

        val resolver = PlaylistResolver(snapshot.tracks, ::libraryLocation)
        val entries = document.lines.map { line ->
            val match = resolver.find(line.path, known?.folderPath, folderLocation)
            val track = match?.track
            PlaylistEntry(
                id = PlaylistEntry.nextId(),
                rawPath = line.path,
                title = line.title.ifBlank {
                    track?.let { M3uCodec.displayTitle(it) }
                        ?: line.path.replace('\\', '/').substringAfterLast('/')
                },
                durationSeconds = if (line.durationSeconds >= 0) line.durationSeconds
                else track?.let { PlaylistEntry.durationOf(it) } ?: -1,
                track = track,
                approximate = match?.approximate == true,
            )
        }
        val fileName = known?.name ?: store.displayName(uri) ?: "Playlist"
        return Playlist(
            name = document.name?.takeIf { it.isNotBlank() } ?: fileName.substringBeforeLast('.'),
            entries = entries,
            source = uri,
            sourceFolderId = folderId,
        )
    }

    private companion object {
        const val MAX_PLAYLIST_BYTES = 5 * 1024 * 1024
    }
}

// =====================================================================================
// FASAD: dipakai oleh ViewModel / UI
// =====================================================================================

class FileAndPlaylistManager(
    context: Context,
    val engine: TagAndReplayGainEngine = TagAndReplayGainEngine(context),
) {
    private val appContext = context.applicationContext
    private val store = DocumentStore(appContext)
    private val scanner = LibraryScanner(appContext, store, engine)
    private val playlists = PlaylistRepository(store)
    private val preferences = appContext.getSharedPreferences("tagbardroid", Context.MODE_PRIVATE)

    /** Satu operasi yang mengubah file pada satu waktu. */
    private val operations = Mutex()

    // ---------------------------------------------------------------- Folder musik

    /**
     * Intent pemilih folder. Di Compose bisa juga memakai
     * ActivityResultContracts.OpenDocumentTree().
     */
    fun folderPickerIntent(): Intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
        Intent.FLAG_GRANT_READ_URI_PERMISSION or
            Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION,
    )

    /** Menyimpan folder musik pilihan beserta izinnya. */
    fun setLibraryFolder(treeUri: Uri) {
        engine.persistTreePermission(treeUri)
        preferences.edit().putString(KEY_ROOT, treeUri.toString()).apply()
    }

    /** Folder musik tersimpan, atau null bila belum dipilih / izinnya sudah dicabut. */
    fun savedLibraryFolder(): Uri? {
        val saved = preferences.getString(KEY_ROOT, null) ?: return null
        val permitted = appContext.contentResolver.persistedUriPermissions.any {
            it.uri.toString() == saved && it.isReadPermission && it.isWritePermission
        }
        return if (permitted) Uri.parse(saved) else null
    }

    /**
     * Pemindaian rekursif. File yang tidak berubah diambil dari cache.
     * [onProgress] dipanggil dari thread latar belakang.
     */
    suspend fun scanLibrary(
        treeUri: Uri,
        forceReread: Boolean = false,
        onProgress: (ScanProgress) -> Unit = {},
    ): LibrarySnapshot = operations.withLock { scanner.scan(treeUri, forceReread, onProgress) }

    /** Daftar lagu dari cache tanpa menyentuh folder; null bila belum pernah dipindai. */
    suspend fun loadCachedLibrary(treeUri: Uri): LibrarySnapshot? = scanner.loadSnapshot(treeUri)

    /** Panggil setelah mengubah tag lewat engine secara langsung, sebelum memindai ulang. */
    fun invalidate(tracks: List<LibraryTrack>) = scanner.invalidate(tracks.map { it.documentId })

    // ---------------------------------------------------------------- Auto-numbering

    fun previewAutoNumber(
        selection: List<LibraryTrack>,
        options: AutoNumberOptions = AutoNumberOptions(),
    ): List<NumberingPreview> = AutoNumbering.plan(selection, options)

    suspend fun applyAutoNumber(
        previews: List<NumberingPreview>,
        onProgress: (OperationProgress) -> Unit = {},
    ): BatchReport = applyEdits(previews.map { it.track to it.toEdit() }, onProgress)

    // ---------------------------------------------------------------- Filename -> Tag

    fun previewFilenameToTag(
        selection: List<LibraryTrack>,
        pattern: String? = null,
        underscoresToSpaces: Boolean = true,
    ): List<FilenameToTagPreview> = FilenameToTag.plan(selection, pattern, underscoresToSpaces)

    suspend fun applyFilenameToTag(
        previews: List<FilenameToTagPreview>,
        onProgress: (OperationProgress) -> Unit = {},
    ): BatchReport = applyEdits(
        previews.filter { it.error == null }.map { it.track to it.toEdit() },
        onProgress,
    )

    // ---------------------------------------------------------------- Tag -> Filename

    /** Membaca tag langsung dari file (bukan cache) lalu menyusun nama baru. */
    suspend fun previewTagToFilename(
        selection: List<LibraryTrack>,
        treeUri: Uri,
        pattern: String = "%tracknumber% - %title%",
        trackPadding: Int = 2,
        onProgress: (OperationProgress) -> Unit = {},
    ): List<RenamePreview> = withContext(Dispatchers.IO) {
        val parsed = FilenamePattern.parse(pattern)
        // Kesalahan pola dilaporkan sekali di awal, bukan per file.
        parsed.format(FilenameField.entries.associateWith { "1" }, trackPadding)
        val unique = selection.distinctBy { it.documentId }
        val previews = unique.mapIndexed { index, track ->
            coroutineContext.ensureActive()
            val preview = try {
                val tags = engine.readMetadata(track.item, includeCover = false)
                val values = mapOf(
                    FilenameField.TRACK to tags.trackNumber,
                    FilenameField.DISC to tags.discNumber,
                    FilenameField.TITLE to tags.title,
                    FilenameField.ARTIST to tags.artist,
                    FilenameField.ALBUM_ARTIST to tags.albumArtist,
                    FilenameField.ALBUM to tags.album,
                    FilenameField.YEAR to tags.year,
                    FilenameField.GENRE to tags.genre,
                )
                val extension = track.item.displayName.substringAfterLast('.', "")
                val name = FileNames.build(parsed.format(values, trackPadding), extension)
                val status = if (name == track.item.displayName) RenameStatus.UNCHANGED else RenameStatus.READY
                RenamePreview(track, name, status)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                RenamePreview(track, track.item.displayName, RenameStatus.ERROR, e.message)
            }
            onProgress(OperationProgress(index + 1, unique.size, track.item.displayName))
            preview
        }
        RenamePlanner.resolveConflicts(previews, folderNames(treeUri, previews))
    }

    /** Mengganti nama file fisik. Hanya item READY yang diproses. */
    suspend fun applyRename(
        previews: List<RenamePreview>,
        treeUri: Uri,
        onProgress: (OperationProgress) -> Unit = {},
    ): RenameReport = operations.withLock {
        withContext(Dispatchers.IO) {
            // Isi folder bisa berubah sejak pratinjau, jadi bentrokan diperiksa ulang.
            val checked = RenamePlanner.resolveConflicts(previews, folderNames(treeUri, previews))
            val failed = checked
                .filter { it.status == RenameStatus.CONFLICT || it.status == RenameStatus.ERROR }
                .mapTo(mutableListOf()) { ItemFailure(it.track.item, it.message ?: "Tidak dapat diganti nama") }
            val renamed = mutableListOf<RenamedFile>()
            val executor = RenameExecutor { uri, name -> store.rename(uri, name) }
            val ready = checked.filter { it.status == RenameStatus.READY }
            var completed = 0

            ready.groupBy { it.track.item.parentDocumentId }.values.forEach { folder ->
                coroutineContext.ensureActive()
                // Satu folder diselesaikan utuh walau dibatalkan, agar tidak tertinggal nama sementara.
                val result = withContext(NonCancellable) { executor.runFolder(folder, store::displayName) }
                result.onSuccess { done ->
                    done.forEach { (preview, uri) ->
                        val old = preview.track
                        renamed += RenamedFile(
                            oldDocumentId = old.documentId,
                            oldPath = old.path,
                            newPath = joinPath(old.item.folderPath, preview.newName),
                            newName = preview.newName,
                            newUri = uri,
                            newDocumentId = runCatching { DocumentsContract.getDocumentId(uri) }.getOrNull(),
                        )
                    }
                }.onFailure { error ->
                    folder.forEach { failed += ItemFailure(it.track.item, error.message ?: "Gagal") }
                }
                scanner.invalidate(folder.map { it.track.documentId })
                completed += folder.size
                onProgress(OperationProgress(completed, ready.size, folder.last().newName))
            }
            scanner.invalidate(renamed.mapNotNull { it.newDocumentId })
            RenameReport(renamed, failed)
        }
    }

    // ---------------------------------------------------------------- ReplayGain

    suspend fun removeReplayGain(
        selection: List<LibraryTrack>,
        onProgress: (OperationProgress) -> Unit = {},
    ): BatchReport = operations.withLock {
        try {
            engine.removeReplayGain(selection.distinctBy { it.documentId }.map { it.item }, onProgress)
        } finally {
            invalidate(selection)
        }
    }

    // ---------------------------------------------------------------- Playlist

    /** Folder di dalam perpustakaan sebagai tujuan ekspor. */
    fun libraryDestination(snapshot: LibrarySnapshot, folderPath: String = ""): PlaylistDestination {
        val folder = snapshot.folders.firstOrNull { it.path == folderPath }
            ?: throw IllegalArgumentException("Folder tidak ditemukan: $folderPath")
        return PlaylistDestination(snapshot.treeUri, folder.documentId, folder.path)
    }

    /** Folder tujuan dari hasil ACTION_OPEN_DOCUMENT_TREE. */
    fun pickedDestination(treeUri: Uri): PlaylistDestination =
        PlaylistDestination(treeUri, DocumentsContract.getTreeDocumentId(treeUri), null)

    /**
     * Mengekspor playlist dengan path relatif terhadap folder tujuan. Melempar
     * [PlaylistExistsException] bila nama sudah ada dan [overwrite] false.
     */
    suspend fun exportPlaylist(
        playlist: Playlist,
        snapshot: LibrarySnapshot,
        destination: PlaylistDestination,
        fileName: String = playlist.name,
        format: PlaylistFormat = PlaylistFormat.M3U8,
        overwrite: Boolean = false,
        includeMissing: Boolean = true,
    ): ExportResult = operations.withLock {
        withContext(Dispatchers.IO) {
            playlists.export(playlist, snapshot, destination, fileName, format, overwrite, includeMissing)
        }
    }

    /**
     * Membuka M3U/M3U8: dari daftar [LibrarySnapshot.playlists] atau dari ACTION_OPEN_DOCUMENT.
     */
    suspend fun importPlaylist(uri: Uri, snapshot: LibrarySnapshot): Playlist =
        withContext(Dispatchers.IO) { playlists.import(uri, snapshot) }

    // ---------------------------------------------------------------- Internal

    private suspend fun applyEdits(
        edits: List<Pair<LibraryTrack, TagEdit>>,
        onProgress: (OperationProgress) -> Unit,
    ): BatchReport = operations.withLock {
        try {
            engine.batchEdit(
                items = edits.map { it.first.item },
                common = TagEdit(),
                onProgress = onProgress,
                perItem = { index, _ -> edits[index].second },
            )
        } finally {
            invalidate(edits.map { it.first })
        }
    }

    private fun folderNames(treeUri: Uri, previews: List<RenamePreview>): Map<String, List<String>> =
        previews.map { it.track.item.parentDocumentId }.distinct().associateWith { folderId ->
            store.children(treeUri, folderId).map { it.name }
        }

    private companion object {
        const val KEY_ROOT = "library_root"
    }
}
