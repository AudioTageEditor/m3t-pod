// File: app/src/main/java/com/tagbardroid/app/engine/TagAndReplayGainEngine.kt
package com.tagbardroid.app.engine

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.SystemClock
import android.provider.DocumentsContract
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.jaudiotagger.audio.AudioFile
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.audio.mp3.MP3File
import org.jaudiotagger.audio.wav.WavOptions
import org.jaudiotagger.audio.wav.WavSaveOptions
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.Tag
import org.jaudiotagger.tag.TagOptionSingleton
import org.jaudiotagger.tag.flac.FlacTag
import org.jaudiotagger.tag.id3.AbstractID3v2Frame
import org.jaudiotagger.tag.id3.AbstractID3v2Tag
import org.jaudiotagger.tag.id3.ID3v11Tag
import org.jaudiotagger.tag.id3.ID3v22Tag
import org.jaudiotagger.tag.id3.ID3v23Frame
import org.jaudiotagger.tag.id3.ID3v23Tag
import org.jaudiotagger.tag.id3.ID3v24Frame
import org.jaudiotagger.tag.id3.ID3v24Tag
import org.jaudiotagger.tag.id3.framebody.FrameBodyTXXX
import org.jaudiotagger.tag.id3.valuepair.TextEncoding
import org.jaudiotagger.tag.images.AndroidArtwork
import org.jaudiotagger.tag.reference.GenreTypes
import org.jaudiotagger.tag.vorbiscomment.VorbisCommentTag
import org.jaudiotagger.tag.wav.WavTag
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tan

// =====================================================================================
// MODEL DATA
// =====================================================================================

/** Ekstensi file yang didukung. M4A/MP4/M4B mencakup AAC dan ALAC. */
val SUPPORTED_EXTENSIONS: Set<String> = setOf("flac", "m4a", "m4b", "mp4", "mp3", "ogg", "oga", "wav")

/** Satu file audio di dalam folder yang dipilih lewat SAF. */
data class AudioItem(
    val uri: Uri,
    val displayName: String,
    /** Path folder relatif terhadap folder yang dipilih, "" untuk folder akar. */
    val folderPath: String,
    val parentDocumentId: String,
    val sizeBytes: Long,
) {
    val extension: String get() = displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)
}

/** Gambar sampul JPG/PNG yang sudah divalidasi. */
class CoverArtData(
    val bytes: ByteArray,
    val mimeType: String,
    val width: Int,
    val height: Int,
)

data class ReplayGainTags(
    val trackGain: String = "",
    val trackPeak: String = "",
    val albumGain: String = "",
    val albumPeak: String = "",
)

data class AudioMetadata(
    val title: String,
    val artist: String,
    val albumArtist: String,
    val album: String,
    val genre: String,
    val year: String,
    val trackNumber: String,
    val trackTotal: String,
    val discNumber: String,
    val discTotal: String,
    val comment: String,
    val coverArt: ByteArray?,
    val replayGain: ReplayGainTags,
    val codec: String,
    val sampleRate: String,
    /** Bit depth per sampel (mis. "24") untuk format lossless (FLAC, WAV, ALAC); kosong untuk format lossy. */
    val bitDepth: String,
    val bitrate: String,
    val durationSeconds: Int,
)

sealed interface CoverAction {
    data object Keep : CoverAction
    data object Remove : CoverAction
    class Replace(val art: CoverArtData) : CoverAction
}

/**
 * Perubahan tag. Aturan untuk setiap kolom teks:
 *   null = biarkan nilai lama, "" = hapus tag, selain itu = tulis nilai baru.
 */
data class TagEdit(
    val title: String? = null,
    val artist: String? = null,
    val albumArtist: String? = null,
    val album: String? = null,
    val genre: String? = null,
    val year: String? = null,
    val trackNumber: String? = null,
    val trackTotal: String? = null,
    val discNumber: String? = null,
    val discTotal: String? = null,
    val comment: String? = null,
    val cover: CoverAction = CoverAction.Keep,
) {
    /** Menggabungkan dua perubahan; nilai non-null milik [other] menang. */
    fun overriddenBy(other: TagEdit): TagEdit = TagEdit(
        title = other.title ?: title,
        artist = other.artist ?: artist,
        albumArtist = other.albumArtist ?: albumArtist,
        album = other.album ?: album,
        genre = other.genre ?: genre,
        year = other.year ?: year,
        trackNumber = other.trackNumber ?: trackNumber,
        trackTotal = other.trackTotal ?: trackTotal,
        discNumber = other.discNumber ?: discNumber,
        discTotal = other.discTotal ?: discTotal,
        comment = other.comment ?: comment,
        cover = if (other.cover != CoverAction.Keep) other.cover else cover,
    )

    internal fun validate() {
        listOf(
            "Track Number" to trackNumber,
            "Track Total" to trackTotal,
            "Disc Number" to discNumber,
            "Disc Total" to discTotal,
        ).forEach { (label, value) ->
            if (!value.isNullOrBlank()) {
                val number = value.trim().toIntOrNull()
                require(number != null && number in 1..9999) { "$label harus angka 1-9999, bukan '$value'" }
            }
        }
    }
}

data class OperationProgress(val completed: Int, val total: Int, val currentName: String)

data class ItemFailure(val item: AudioItem, val message: String)

data class BatchReport(val succeeded: List<AudioItem>, val failed: List<ItemFailure>)

/** File cadangan yang tersisa karena penulisan terputus (mis. aplikasi dimatikan paksa). */
data class PendingRecovery(val id: String, val targetUri: Uri, val backupFile: File)

enum class AlbumGrouping {
    /** Hanya Track Gain/Peak. Tag album yang sudah ada tidak diubah. */
    TRACK_ONLY,

    /** Semua file yang dipilih dianggap satu album. */
    SINGLE_ALBUM,

    /** Satu folder = satu album. */
    BY_FOLDER,

    /** Dikelompokkan berdasarkan tag Album + Album Artist (atau folder bila Album Artist kosong). */
    BY_TAGS,
}

data class TrackGainResult(
    val item: AudioItem,
    /** null bila lagu hening total atau lebih pendek dari 400 ms. */
    val integratedLufs: Double?,
    val trackGainDb: Double?,
    val trackPeak: Double,
    val albumKey: String?,
    val albumGainDb: Double?,
    val albumPeak: Double?,
    /** true bila seluruh anggota album berhasil dipindai, sehingga nilai album sah ditulis. */
    val writeAlbumValues: Boolean,
)

data class ReplayGainReport(val tracks: List<TrackGainResult>, val failed: List<ItemFailure>)

// =====================================================================================
// ENGINE UTAMA
// =====================================================================================

class TagAndReplayGainEngine(context: Context) {

    private val appContext = context.applicationContext
    private val storage = SafStorage(appContext)
    private val tagEditor = TagFileEditor()
    private val decoder = PcmDecoder(appContext)

    private val workDir: File get() = File(appContext.cacheDir, "tag_work").apply { mkdirs() }

    /** Cadangan disimpan di filesDir agar tidak dibersihkan sistem seperti cache. */
    private val backupDir: File get() = File(appContext.filesDir, "tag_backup").apply { mkdirs() }

    // ---------------------------------------------------------------- Folder (SAF)

    /** Panggil sekali dengan Uri hasil ACTION_OPEN_DOCUMENT_TREE. */
    fun persistTreePermission(treeUri: Uri) {
        appContext.contentResolver.takePersistableUriPermission(
            treeUri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
        )
    }

    suspend fun scanTree(treeUri: Uri, recursive: Boolean = true): List<AudioItem> =
        withContext(Dispatchers.IO) { storage.listAudio(treeUri, recursive) }

    // ---------------------------------------------------------------- Baca tag

    suspend fun readMetadata(item: AudioItem, includeCover: Boolean = true): AudioMetadata =
        withContext(Dispatchers.IO) {
            val temp = File(workDir, "read-${UUID.randomUUID()}.${item.extension}")
            try {
                storage.copyToFile(item.uri, temp)
                tagEditor.read(temp, includeCover)
            } finally {
                temp.delete()
            }
        }

    /** Memuat dan memvalidasi gambar sampul dari Uri (mis. hasil ACTION_OPEN_DOCUMENT). */
    suspend fun loadCover(imageUri: Uri): CoverArtData = withContext(Dispatchers.IO) {
        val bytes = storage.readBytes(imageUri, MAX_COVER_BYTES)
        val mime = detectImageMime(bytes)
            ?: throw IllegalArgumentException("Sampul harus berformat JPG atau PNG")
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "File gambar rusak" }
        require(bounds.outWidth.toLong() * bounds.outHeight <= MAX_COVER_PIXELS) {
            "Resolusi sampul terlalu besar (maksimal sekitar 6000 x 6000)"
        }
        CoverArtData(bytes, mime, bounds.outWidth, bounds.outHeight)
    }

    // ---------------------------------------------------------------- Tulis tag

    suspend fun editTags(item: AudioItem, edit: TagEdit) {
        edit.validate()
        rewrite(item) { file -> tagEditor.applyEdit(file, edit) }
    }

    /**
     * Edit massal. [common] berlaku untuk semua lagu (mis. Album, Album Artist, sampul);
     * [perItem] menambahkan nilai khusus per lagu (mis. nomor trek).
     * Contoh: batchEdit(items, TagEdit(album = "X")) { i, _ -> TagEdit(trackNumber = "${i + 1}") }
     * [onProgress] dipanggil dari thread latar belakang.
     */
    suspend fun batchEdit(
        items: List<AudioItem>,
        common: TagEdit,
        onProgress: (OperationProgress) -> Unit = {},
        perItem: (index: Int, item: AudioItem) -> TagEdit = { _, _ -> TagEdit() },
    ): BatchReport = runBatch(items, onProgress) { index, item ->
        editTags(item, common.overriddenBy(perItem(index, item)))
    }

    // ---------------------------------------------------------------- ReplayGain

    /**
     * Memindai tanpa mengubah file. Tampilkan hasilnya, lalu panggil [writeReplayGain].
     *
     * @param useTruePeak false = sample peak (bawaan foobar2000), true = true peak (oversampling).
     * @param parallelism jumlah lagu yang di-decode bersamaan.
     */
    suspend fun analyzeReplayGain(
        items: List<AudioItem>,
        grouping: AlbumGrouping,
        useTruePeak: Boolean = false,
        parallelism: Int = 2,
        onProgress: (OperationProgress) -> Unit = {},
    ): ReplayGainReport = withContext(Dispatchers.Default) {
        val gate = Semaphore(parallelism.coerceIn(1, 4))
        val done = AtomicInteger(0)

        val outcomes: List<ScanOutcome> = coroutineScope {
            items.map { item ->
                async {
                    gate.withPermit {
                        val key = try {
                            albumKeyFor(item, grouping)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            // Tag tidak terbaca, jadi albumnya tidak diketahui.
                            return@withPermit ScanOutcome(item, null, null, describe(e), albumUnknown = true)
                        }
                        val outcome = try {
                            val job = coroutineContext
                            val meter = withContext(Dispatchers.IO) {
                                decoder.measure(item, useTruePeak) { job.ensureActive() }
                            }
                            ScanOutcome(item, key, meter, null)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            ScanOutcome(item, key, null, describe(e))
                        } catch (e: OutOfMemoryError) {
                            ScanOutcome(item, key, null, "Memori tidak cukup")
                        }
                        onProgress(OperationProgress(done.incrementAndGet(), items.size, item.displayName))
                        outcome
                    }
                }
            }.awaitAll()
        }

        val albums = outcomes.filter { it.albumKey != null }.groupBy { it.albumKey }
        // Bila tag sebuah file tidak terbaca, albumnya tidak diketahui,
        // jadi semua album di folder yang sama dianggap tidak lengkap.
        val brokenFolders = outcomes.filter { it.albumUnknown }.map { it.item.parentDocumentId }.toSet()

        val summaries = albums.mapValues { (_, members) ->
            val measured = members.mapNotNull { it.measurement }
            val complete = measured.size == members.size &&
                members.none { it.item.parentDocumentId in brokenFolders }
            AlbumSummary(
                lufs = if (complete) Loudness.integrated(measured.map { it.blockEnergies }) else null,
                peak = if (complete) measured.maxOfOrNull { it.peak } else null,
                complete = complete,
            )
        }

        val tracks = outcomes.mapNotNull { outcome ->
            val m = outcome.measurement ?: return@mapNotNull null
            val lufs = Loudness.integrated(listOf(m.blockEnergies))
            val album = outcome.albumKey?.let { summaries[it] }
            TrackGainResult(
                item = outcome.item,
                integratedLufs = lufs,
                trackGainDb = lufs?.let { Loudness.REFERENCE_LUFS - it },
                trackPeak = m.peak,
                albumKey = outcome.albumKey,
                albumGainDb = album?.lufs?.let { Loudness.REFERENCE_LUFS - it },
                albumPeak = album?.peak,
                writeAlbumValues = album?.complete == true,
            )
        }
        val failed = outcomes.filter { it.measurement == null }
            .map { ItemFailure(it.item, it.error ?: "Gagal memindai") }
        ReplayGainReport(tracks, failed)
    }

    /** Menulis REPLAYGAIN_* hasil pemindaian ke metadata masing-masing file. */
    suspend fun writeReplayGain(
        report: ReplayGainReport,
        onProgress: (OperationProgress) -> Unit = {},
    ): BatchReport {
        val byUri = report.tracks.associateBy { it.item.uri }
        return runBatch(report.tracks.map { it.item }, onProgress) { _, item ->
            val result = byUri.getValue(item.uri)
            val values = LinkedHashMap<String, String?>()
            values[RG_TRACK_GAIN] = result.trackGainDb?.let(::formatGain)
            values[RG_TRACK_PEAK] = formatPeak(result.trackPeak)
            if (result.writeAlbumValues) {
                values[RG_ALBUM_GAIN] = result.albumGainDb?.let(::formatGain)
                values[RG_ALBUM_PEAK] = result.albumPeak?.let(::formatPeak)
            }
            rewrite(item) { file -> tagEditor.writeCustomFields(file, values) }
        }
    }

    suspend fun removeReplayGain(
        items: List<AudioItem>,
        onProgress: (OperationProgress) -> Unit = {},
    ): BatchReport = runBatch(items, onProgress) { _, item ->
        val values = listOf(RG_TRACK_GAIN, RG_TRACK_PEAK, RG_ALBUM_GAIN, RG_ALBUM_PEAK)
            .associateWith { null as String? }
        rewrite(item) { file -> tagEditor.writeCustomFields(file, values) }
    }

    // ---------------------------------------------------------------- Pemulihan

    suspend fun pendingRecoveries(): List<PendingRecovery> = withContext(Dispatchers.IO) {
        writeMutex.withLock {
            val files = backupDir.listFiles().orEmpty()
            val markers = files.filter { it.name.endsWith(".uri") }.associateBy { it.name.removeSuffix(".uri") }
            files.filterNot { it.name.endsWith(".uri") }.mapNotNull { backup ->
                val id = backup.name.substringBefore('.')
                val marker = markers[id]
                if (marker == null) {
                    // Tanpa penanda berarti file asli belum disentuh: cadangan boleh dibuang.
                    backup.delete()
                    null
                } else {
                    PendingRecovery(id, Uri.parse(marker.readText()), backup)
                }
            }
        }
    }

    /** Mengembalikan file asli dari cadangan. */
    suspend fun recover(recovery: PendingRecovery) = withContext(Dispatchers.IO) {
        writeMutex.withLock {
            storage.overwrite(recovery.targetUri, recovery.backupFile)
            recovery.backupFile.delete()
            File(backupDir, "${recovery.id}.uri").delete()
            Unit
        }
    }

    // ---------------------------------------------------------------- Internal

    /**
     * Alur tulis aman: salin ke cadangan -> edit salinan kerja -> timpa file asli.
     * Bila penimpaan gagal, isi asli dikembalikan.
     */
    private suspend fun rewrite(item: AudioItem, modify: (File) -> Unit) {
        withContext(Dispatchers.IO) {
            writeMutex.withLock {
                val id = UUID.randomUUID().toString()
                val backup = File(backupDir, "$id.${item.extension}")
                val marker = File(backupDir, "$id.uri")
                val work = File(workDir, "edit-$id.${item.extension}")
                var keepBackup = false
                try {
                    storage.copyToFile(item.uri, backup)
                    backup.copyTo(work, overwrite = true)
                    modify(work)
                    tagEditor.verifyReadable(work)
                    coroutineContext.ensureActive()

                    // Mulai titik kritis: tidak boleh dibatalkan di tengah penulisan.
                    withContext(NonCancellable) {
                        marker.writeText(item.uri.toString())
                        keepBackup = true
                        try {
                            storage.overwrite(item.uri, work)
                            keepBackup = false
                        } catch (writeError: Exception) {
                            try {
                                storage.overwrite(item.uri, backup)
                                keepBackup = false
                            } catch (restoreError: Exception) {
                                writeError.addSuppressed(restoreError)
                                throw IOException(
                                    "Gagal menulis dan gagal memulihkan. Cadangan: ${backup.absolutePath}",
                                    writeError,
                                )
                            }
                            throw writeError
                        }
                    }
                } finally {
                    work.delete()
                    if (!keepBackup) {
                        backup.delete()
                        marker.delete()
                    }
                }
            }
        }
    }

    private suspend fun runBatch(
        items: List<AudioItem>,
        onProgress: (OperationProgress) -> Unit,
        action: suspend (Int, AudioItem) -> Unit,
    ): BatchReport = withContext(Dispatchers.IO) {
        val succeeded = mutableListOf<AudioItem>()
        val failed = mutableListOf<ItemFailure>()
        items.forEachIndexed { index, item ->
            coroutineContext.ensureActive()
            try {
                action(index, item)
                succeeded += item
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                failed += ItemFailure(item, describe(e))
            } catch (e: OutOfMemoryError) {
                failed += ItemFailure(item, "Memori tidak cukup")
            }
            onProgress(OperationProgress(index + 1, items.size, item.displayName))
        }
        BatchReport(succeeded, failed)
    }

    private suspend fun albumKeyFor(item: AudioItem, grouping: AlbumGrouping): String? = when (grouping) {
        AlbumGrouping.TRACK_ONLY -> null
        AlbumGrouping.SINGLE_ALBUM -> "selection"
        AlbumGrouping.BY_FOLDER -> "folder:${item.parentDocumentId}"
        AlbumGrouping.BY_TAGS -> {
            val meta = readMetadata(item, includeCover = false)
            val album = meta.album.trim().lowercase(Locale.ROOT)
            if (album.isEmpty()) {
                null // Tanpa tag Album: hanya nilai track.
            } else {
                val owner = meta.albumArtist.trim().lowercase(Locale.ROOT)
                    .ifEmpty { "folder:${item.parentDocumentId}" }
                "tags:$owner\u0000$album"
            }
        }
    }

    private fun describe(e: Throwable): String = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName

    private fun formatGain(db: Double): String = String.format(Locale.US, "%.2f dB", db)

    private fun formatPeak(peak: Double): String = String.format(Locale.US, "%.6f", peak)

    private fun detectImageMime(b: ByteArray): String? = when {
        b.size > 3 && b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte() && b[2] == 0xFF.toByte() -> "image/jpeg"
        b.size > 8 && b[0] == 0x89.toByte() && b[1] == 'P'.code.toByte() &&
            b[2] == 'N'.code.toByte() && b[3] == 'G'.code.toByte() -> "image/png"
        else -> null
    }

    private class ScanOutcome(
        val item: AudioItem,
        val albumKey: String?,
        val measurement: LoudnessMeasurement?,
        val error: String?,
        val albumUnknown: Boolean = false,
    )

    private class AlbumSummary(val lufs: Double?, val peak: Double?, val complete: Boolean)

    companion object {
        const val RG_TRACK_GAIN = "REPLAYGAIN_TRACK_GAIN"
        const val RG_TRACK_PEAK = "REPLAYGAIN_TRACK_PEAK"
        const val RG_ALBUM_GAIN = "REPLAYGAIN_ALBUM_GAIN"
        const val RG_ALBUM_PEAK = "REPLAYGAIN_ALBUM_PEAK"

        /** Blok gambar FLAC dibatasi 16 MB; sisakan ruang untuk header dan Base64. */
        private const val MAX_COVER_BYTES = 10 * 1024 * 1024
        private const val MAX_COVER_PIXELS = 36_000_000L

        /** Satu penulisan pada satu waktu, berlaku untuk semua instance engine. */
        private val writeMutex = Mutex()
    }
}

// =====================================================================================
// STORAGE ACCESS FRAMEWORK
// =====================================================================================

internal class SafStorage(private val context: Context) {

    private val resolver get() = context.contentResolver

    fun listAudio(treeUri: Uri, recursive: Boolean): List<AudioItem> {
        val result = mutableListOf<AudioItem>()
        val pending = ArrayDeque<Pair<String, String>>() // documentId to path relatif
        pending.add(DocumentsContract.getTreeDocumentId(treeUri) to "")
        val visited = HashSet<String>()
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
        )
        while (pending.isNotEmpty()) {
            val (folderId, path) = pending.removeFirst()
            if (!visited.add(folderId)) continue
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, folderId)
            val cursor = resolver.query(children, projection, null, null, null)
                ?: throw IOException("Folder tidak dapat dibaca: ${path.ifEmpty { "/" }}")
            cursor.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (recursive) pending.add(id to if (path.isEmpty()) name else "$path/$name")
                    } else if (!name.startsWith("._") &&
                        name.substringAfterLast('.', "").lowercase(Locale.ROOT) in SUPPORTED_EXTENSIONS
                    ) {
                        result += AudioItem(
                            uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id),
                            displayName = name,
                            folderPath = path,
                            parentDocumentId = folderId,
                            sizeBytes = if (c.isNull(3)) -1L else c.getLong(3),
                        )
                    }
                }
            }
        }
        return result.sortedWith(
            compareBy(String.CASE_INSENSITIVE_ORDER) { it: AudioItem -> it.folderPath }
                .thenBy(String.CASE_INSENSITIVE_ORDER) { it.displayName },
        )
    }

    fun copyToFile(source: Uri, target: File) {
        val input = resolver.openInputStream(source) ?: throw IOException("File tidak dapat dibuka")
        input.use { src -> FileOutputStream(target).use { dst -> src.copyTo(dst, BUFFER_SIZE) } }
        if (target.length() == 0L) throw IOException("File kosong atau gagal disalin")
    }

    /** Menimpa isi dokumen. Mode "rwt" memastikan file lama dipotong. */
    fun overwrite(target: Uri, source: File) {
        val descriptor = resolver.openFileDescriptor(target, "rwt")
            ?: throw IOException("File tidak dapat ditulis")
        descriptor.use { pfd ->
            FileOutputStream(pfd.fileDescriptor).use { out ->
                out.channel.truncate(0)
                val written = FileInputStream(source).use { it.copyTo(out, BUFFER_SIZE) }
                out.flush()
                pfd.fileDescriptor.sync()
                if (written != source.length()) throw IOException("Penulisan tidak lengkap")
            }
        }
    }

    fun readBytes(uri: Uri, limit: Int): ByteArray {
        val input = resolver.openInputStream(uri) ?: throw IOException("File tidak dapat dibuka")
        input.use { stream ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(BUFFER_SIZE)
            while (true) {
                val read = stream.read(buffer)
                if (read < 0) break
                output.write(buffer, 0, read)
                require(output.size() <= limit) { "Ukuran file melebihi ${limit / (1024 * 1024)} MB" }
            }
            return output.toByteArray()
        }
    }

    private companion object {
        const val BUFFER_SIZE = 256 * 1024
    }
}

// =====================================================================================
// TAG EDITOR
// FLAC/MP3/OGG/WAV: JAudioTagger. M4A/MP4 (AAC & ALAC): Mp4TagFile di bawah,
// karena JAudioTagger gagal menulis atom freeform (tempat tag ReplayGain disimpan).
// =====================================================================================

/** Bit depth hanya bermakna untuk format lossless; MP3/AAC/Vorbis mengembalikan string kosong. */
internal fun losslessBitDepth(encodingType: String, bits: Int): String {
    val upper = encodingType.uppercase(java.util.Locale.ROOT)
    val lossless = listOf("FLAC", "WAV", "PCM", "AIFF", "ALAC", "LOSSLESS").any { it in upper }
    return if (lossless && bits in 8..32) bits.toString() else ""
}

internal class TagFileEditor {

    init {
        configureLibrary()
    }

    fun read(file: File, includeCover: Boolean): AudioMetadata {
        if (isMp4(file)) return Mp4TagFile(file).read(includeCover)
        val audio = open(file)
        val tag: Tag? = if (audio is MP3File) audio.getID3v2Tag() ?: audio.getID3v1Tag() else audio.tag
        val header = audio.audioHeader

        fun text(key: FieldKey): String =
            if (tag == null) "" else runCatching { tag.getFirst(key) }.getOrNull().orEmpty().trimEnd('\u0000')

        fun number(key: FieldKey): String = text(key).let { if (it == "0") "" else it }

        fun custom(name: String): String = if (tag == null) "" else readCustom(tag, name)

        return AudioMetadata(
            title = text(FieldKey.TITLE),
            artist = text(FieldKey.ARTIST),
            albumArtist = text(FieldKey.ALBUM_ARTIST),
            album = text(FieldKey.ALBUM),
            genre = text(FieldKey.GENRE),
            year = text(FieldKey.YEAR),
            trackNumber = number(FieldKey.TRACK),
            trackTotal = number(FieldKey.TRACK_TOTAL),
            discNumber = number(FieldKey.DISC_NO),
            discTotal = number(FieldKey.DISC_TOTAL),
            comment = text(FieldKey.COMMENT),
            coverArt = if (includeCover) runCatching { tag?.firstArtwork?.binaryData }.getOrNull() else null,
            replayGain = ReplayGainTags(
                trackGain = custom(TagAndReplayGainEngine.RG_TRACK_GAIN),
                trackPeak = custom(TagAndReplayGainEngine.RG_TRACK_PEAK),
                albumGain = custom(TagAndReplayGainEngine.RG_ALBUM_GAIN),
                albumPeak = custom(TagAndReplayGainEngine.RG_ALBUM_PEAK),
            ),
            codec = header.encodingType.orEmpty(),
            sampleRate = header.sampleRate.orEmpty(),
            bitDepth = losslessBitDepth(header.encodingType.orEmpty(), header.bitsPerSample),
            bitrate = header.bitRate.orEmpty(),
            durationSeconds = header.trackLength,
        )
    }

    fun applyEdit(file: File, edit: TagEdit) {
        if (isMp4(file)) {
            val mp4 = Mp4TagFile(file)
            mp4.applyEdit(edit)
            mp4.save()
            return
        }
        val audio = open(file)
        val tag = writableTag(audio)

        setText(tag, FieldKey.TITLE, edit.title)
        setText(tag, FieldKey.ARTIST, edit.artist)
        setText(tag, FieldKey.ALBUM_ARTIST, edit.albumArtist)
        setText(tag, FieldKey.ALBUM, edit.album)
        setText(tag, FieldKey.GENRE, edit.genre)
        setText(tag, FieldKey.YEAR, edit.year)
        setText(tag, FieldKey.COMMENT, edit.comment)
        setNumberPair(tag, FieldKey.TRACK, FieldKey.TRACK_TOTAL, edit.trackNumber, edit.trackTotal)
        setNumberPair(tag, FieldKey.DISC_NO, FieldKey.DISC_TOTAL, edit.discNumber, edit.discTotal)

        when (val cover = edit.cover) {
            CoverAction.Keep -> Unit
            CoverAction.Remove -> tag.deleteArtworkField()
            is CoverAction.Replace -> setCover(tag, cover.art)
        }
        save(audio)
    }

    /** Nilai null berarti tag tersebut dihapus. */
    fun writeCustomFields(file: File, values: Map<String, String?>) {
        if (isMp4(file)) {
            val mp4 = Mp4TagFile(file)
            values.forEach { (name, value) -> mp4.setFreeform(name, value) }
            mp4.save()
            return
        }
        val audio = open(file)
        val tag = writableTag(audio)
        values.forEach { (name, value) -> writeCustom(tag, name, value) }
        save(audio)
    }

    /** Memastikan hasil edit masih bisa diurai sebelum menimpa file asli. */
    fun verifyReadable(file: File) {
        if (isMp4(file)) Mp4TagFile(file).read(includeCover = false) else open(file).audioHeader
    }

    private fun isMp4(file: File): Boolean = file.extension.lowercase(Locale.ROOT) in MP4_EXTENSIONS

    private fun open(file: File): AudioFile {
        val extension = when (val ext = file.extension.lowercase(Locale.ROOT)) {
            "oga" -> "ogg"
            else -> ext
        }
        return AudioFileIO.readAs(file, extension)
    }

    private fun writableTag(audio: AudioFile): Tag {
        if (audio !is MP3File) return audio.tagOrCreateAndSetDefault
        val existing: AbstractID3v2Tag? = audio.getID3v2Tag()
        val v1 = audio.getID3v1Tag()
        val tag: AbstractID3v2Tag = when {
            existing is ID3v22Tag -> ID3v23Tag(existing)
            existing != null -> existing
            v1 != null -> ID3v23Tag(v1)
            else -> ID3v23Tag()
        }
        audio.setID3v2Tag(tag)
        return tag
    }

    private fun save(audio: AudioFile) {
        if (audio is MP3File) {
            // Bila file punya ID3v1, samakan isinya dengan ID3v2 agar tidak ada data basi.
            val v2 = audio.getID3v2Tag()
            if (audio.hasID3v1Tag() && v2 != null) audio.setID3v1Tag(ID3v11Tag(v2))
        }
        audio.commit()
    }

    private fun setText(tag: Tag, key: FieldKey, value: String?) {
        if (value == null) return
        tag.deleteField(key)
        if (value.isNotBlank()) tag.setField(key, value.trim())
    }

    private fun setNumberPair(tag: Tag, numberKey: FieldKey, totalKey: FieldKey, number: String?, total: String?) {
        if (number == null && total == null) return
        fun current(key: FieldKey): String =
            runCatching { tag.getFirst(key) }.getOrNull().orEmpty().let { if (it == "0") "" else it }

        val newNumber = (number ?: current(numberKey)).trim()
        val newTotal = (total ?: current(totalKey)).trim()
        tag.deleteField(numberKey)
        tag.deleteField(totalKey)
        if (newNumber.isNotEmpty()) tag.setField(numberKey, newNumber)
        if (newTotal.isNotEmpty()) tag.setField(totalKey, newTotal)
    }

    private fun setCover(tag: Tag, art: CoverArtData) {
        tag.deleteArtworkField()
        if (tag is FlacTag) {
            // Dimensi diberikan langsung sehingga gambar tidak perlu di-decode penuh.
            tag.setField(
                tag.createArtworkField(art.bytes, FRONT_COVER, art.mimeType, "", art.width, art.height, 24, 0),
            )
            return
        }
        val artwork = AndroidArtwork()
        artwork.binaryData = art.bytes
        artwork.mimeType = art.mimeType
        artwork.description = ""
        artwork.pictureType = FRONT_COVER
        artwork.setWidth(art.width)
        artwork.setHeight(art.height)
        tag.setField(artwork)
    }

    private fun writeCustom(tag: Tag, name: String, value: String?) {
        when (tag) {
            is FlacTag -> writeVorbis(tag.vorbisCommentTag, name, value)
            is VorbisCommentTag -> writeVorbis(tag, name, value)
            is WavTag -> writeId3(tag.getID3Tag(), name, value)
            is AbstractID3v2Tag -> writeId3(tag, name, value)
            else -> throw IllegalStateException("Format tag tidak didukung: ${tag.javaClass.simpleName}")
        }
    }

    private fun writeVorbis(tag: VorbisCommentTag, name: String, value: String?) {
        tag.deleteField(name)
        if (value != null) tag.setField(tag.createField(name, value))
    }

    private fun writeId3(tag: AbstractID3v2Tag, name: String, value: String?) {
        val frames = mutableListOf<AbstractID3v2Frame>()
        tag.getFields(USER_TEXT_FRAME).forEach { field ->
            if (field is AbstractID3v2Frame) {
                val body = field.body
                if (body !is FrameBodyTXXX || !body.description.equals(name, ignoreCase = true)) {
                    frames += field
                }
            }
        }
        if (value != null) {
            val frame: AbstractID3v2Frame =
                if (tag is ID3v24Tag) ID3v24Frame(USER_TEXT_FRAME) else ID3v23Frame(USER_TEXT_FRAME)
            frame.body = FrameBodyTXXX(TextEncoding.ISO_8859_1, name, value)
            frames += frame
        }
        tag.removeFrame(USER_TEXT_FRAME)
        when {
            frames.size == 1 -> tag.setFrame(frames[0])
            frames.size > 1 -> tag.setFrame(USER_TEXT_FRAME, frames)
        }
    }

    private fun readCustom(tag: Tag, name: String): String = when (tag) {
        is FlacTag -> tag.vorbisCommentTag.getFirst(name)
        is VorbisCommentTag -> tag.getFirst(name)
        is WavTag -> readCustom(tag.getID3Tag(), name)
        is AbstractID3v2Tag -> tag.getFields(USER_TEXT_FRAME)
            .mapNotNull { (it as? AbstractID3v2Frame)?.body as? FrameBodyTXXX }
            .firstOrNull { it.description.equals(name, ignoreCase = true) }
            ?.firstTextValue
            .orEmpty()
        else -> ""
    }

    private companion object {
        const val FRONT_COVER = 3
        const val USER_TEXT_FRAME = "TXXX"
        val MP4_EXTENSIONS = setOf("m4a", "m4b", "mp4")

        private var configured = false

        @Synchronized
        fun configureLibrary() {
            if (configured) return
            val options = TagOptionSingleton.getInstance()
            options.setAndroid(true)
            // UTF agar huruf non-Latin (Jepang, Korea, Arab, dll.) tidak rusak.
            options.setId3v23DefaultTextEncoding(TextEncoding.UTF_16)
            options.setId3v24DefaultTextEncoding(TextEncoding.UTF_8)
            // WAV: ID3 sebagai tag utama, chunk LIST INFO ikut disinkronkan.
            options.setWavOptions(WavOptions.READ_ID3_ONLY_AND_SYNC)
            options.setWavSaveOptions(WavSaveOptions.SAVE_BOTH)
            configured = true
        }
    }
}

// =====================================================================================
// TAG MP4 / M4A
// Hanya box "moov" yang dibangun ulang; atom yang tidak dikenal dipertahankan apa adanya.
// =====================================================================================

/** Satu box MP4. [children] null berarti box daun yang isinya disimpan di [payload]. */
internal class Mp4Node(
    val type: String,
    var payload: ByteArray = ByteArray(0),
    val children: MutableList<Mp4Node>? = null,
    /** Byte sebelum anak pertama (versi/flag pada "meta"). */
    val prefix: ByteArray = ByteArray(0),
    /** Sisa byte setelah anak terakhir. */
    val tail: ByteArray = ByteArray(0),
) {
    fun child(name: String): Mp4Node? = children?.firstOrNull { it.type == name }

    val size: Int
        get() = 8 + (children?.let { list -> prefix.size + list.sumOf { it.size } + tail.size } ?: payload.size)

    fun writeTo(out: ByteBuffer) {
        out.putInt(size)
        out.put(type.toByteArray(Charsets.ISO_8859_1))
        val list = children
        if (list == null) {
            out.put(payload)
        } else {
            out.put(prefix)
            list.forEach { it.writeTo(out) }
            out.put(tail)
        }
    }

    companion object {
        /** Induk -> anak yang perlu diurai lebih dalam. */
        private val CONTAINERS = mapOf(
            "moov" to setOf("trak", "udta"),
            "trak" to setOf("mdia"),
            "mdia" to setOf("minf"),
            "minf" to setOf("stbl"),
            "udta" to setOf("meta"),
            "meta" to setOf("ilst"),
        )

        fun parseContainer(type: String, data: ByteArray): Mp4Node {
            val buffer = ByteBuffer.wrap(data)
            // "meta" gaya ISO punya 4 byte versi/flag; gaya QuickTime langsung berisi "hdlr".
            val skip = if (type == "meta" && !(data.size >= 8 && fourCc(buffer.getInt(4)) == "hdlr")) 4 else 0
            require(data.size >= skip) { "Box $type rusak" }
            val children = mutableListOf<Mp4Node>()
            var p = skip
            while (p + 8 <= data.size) {
                val length = buffer.getInt(p)
                if (length < 8 || length > data.size - p) break
                val name = fourCc(buffer.getInt(p + 4))
                val body = data.copyOfRange(p + 8, p + length)
                children += when {
                    type == "ilst" -> Mp4Node(name, body)
                    CONTAINERS[type]?.contains(name) == true -> parseContainer(name, body)
                    else -> Mp4Node(name, body)
                }
                p += length
            }
            return Mp4Node(
                type = type,
                children = children,
                prefix = data.copyOfRange(0, skip),
                tail = data.copyOfRange(p, data.size),
            )
        }
    }
}

internal class Mp4TagFile(private val file: File) {

    private val moovStart: Long
    private val moovEnd: Long
    private val moov: Mp4Node

    init {
        var start = -1L
        var end = -1L
        var content: ByteArray? = null
        RandomAccessFile(file, "r").use { raf ->
            val channel = raf.channel
            val size = channel.size()
            var position = 0L
            while (position + 8 <= size) {
                val head = channel.readAt(position, 8)
                var length = head.getInt(0).toLong() and 0xFFFFFFFFL
                val type = fourCc(head.getInt(4))
                var header = 8L
                if (length == 1L) {
                    length = channel.readAt(position + 8, 8).getLong(0)
                    header = 16L
                } else if (length == 0L) {
                    length = size - position
                }
                if (length < header || length > size - position) throw IOException("Struktur MP4 rusak")
                if (type == "moov") {
                    if (length - header > MAX_MOOV) throw IOException("Metadata MP4 terlalu besar")
                    start = position
                    end = position + length
                    content = channel.readAt(position + header, (length - header).toInt()).array()
                }
                position += length
            }
        }
        moovStart = start
        moovEnd = end
        moov = Mp4Node.parseContainer("moov", content ?: throw IOException("Bukan file MP4/M4A yang valid"))
    }

    // ---------------------------------------------------------------- Baca

    fun read(includeCover: Boolean): AudioMetadata {
        val (track, trackTotal) = pair("trkn")
        val (disc, discTotal) = pair("disk")
        val seconds = durationSeconds()
        val (codec, rate, depth) = audioFormat()
        return AudioMetadata(
            title = text("©nam"),
            artist = text("©ART"),
            albumArtist = text("aART"),
            album = text("©alb"),
            genre = text("©gen").ifEmpty { numericGenre() },
            year = text("©day"),
            trackNumber = track,
            trackTotal = trackTotal,
            discNumber = disc,
            discTotal = discTotal,
            comment = text("©cmt"),
            coverArt = if (includeCover) firstData("covr")?.second else null,
            replayGain = ReplayGainTags(
                trackGain = freeform(TagAndReplayGainEngine.RG_TRACK_GAIN),
                trackPeak = freeform(TagAndReplayGainEngine.RG_TRACK_PEAK),
                albumGain = freeform(TagAndReplayGainEngine.RG_ALBUM_GAIN),
                albumPeak = freeform(TagAndReplayGainEngine.RG_ALBUM_PEAK),
            ),
            codec = codec,
            sampleRate = rate,
            bitDepth = depth,
            bitrate = if (seconds > 0) (file.length() * 8 / seconds / 1000).toString() else "",
            durationSeconds = seconds,
        )
    }

    private fun items(): List<Mp4Node> =
        moov.child("udta")?.child("meta")?.child("ilst")?.children.orEmpty()

    /** Sub-box di dalam satu item ilst ("data", "mean", "name"). */
    private fun parts(item: Mp4Node): List<Mp4Node> =
        Mp4Node.parseContainer("item", item.payload).children.orEmpty()

    /** Pasangan (tipe data, nilai) dari box "data" pertama. */
    private fun dataOf(item: Mp4Node): Pair<Int, ByteArray>? {
        val data = parts(item).firstOrNull { it.type == "data" }?.payload ?: return null
        if (data.size < 8) return null
        return ByteBuffer.wrap(data).getInt(0) to data.copyOfRange(8, data.size)
    }

    private fun firstData(type: String): Pair<Int, ByteArray>? =
        items().firstOrNull { it.type == type }?.let(::dataOf)

    private fun text(type: String): String =
        firstData(type)?.second?.toString(Charsets.UTF_8)?.trimEnd('\u0000').orEmpty()

    private fun numericGenre(): String {
        val value = firstData("gnre")?.second ?: return ""
        if (value.size < 2) return ""
        val index = ByteBuffer.wrap(value).getShort(0).toInt() - 1
        return if (index < 0) "" else GenreTypes.getInstanceOf().getValueForId(index).orEmpty()
    }

    private fun pair(type: String): Pair<String, String> {
        val value = firstData(type)?.second ?: return "" to ""
        if (value.size < 6) return "" to ""
        val buffer = ByteBuffer.wrap(value)
        fun show(n: Int) = if (n == 0) "" else n.toString()
        return show(buffer.getShort(2).toInt() and 0xFFFF) to show(buffer.getShort(4).toInt() and 0xFFFF)
    }

    private fun freeformName(item: Mp4Node): String? {
        if (item.type != FREEFORM) return null
        val name = parts(item).firstOrNull { it.type == "name" }?.payload ?: return null
        return if (name.size < 4) null else String(name, 4, name.size - 4, Charsets.UTF_8)
    }

    private fun freeform(name: String): String =
        items().firstOrNull { freeformName(it).equals(name, ignoreCase = true) }
            ?.let(::dataOf)?.second?.toString(Charsets.UTF_8).orEmpty()

    private fun durationSeconds(): Int {
        val data = moov.child("mvhd")?.payload ?: return 0
        val buffer = ByteBuffer.wrap(data)
        val wide = data.isNotEmpty() && data[0].toInt() == 1
        if (data.size < if (wide) 32 else 20) return 0
        val timescale = buffer.getInt(if (wide) 20 else 12).toLong() and 0xFFFFFFFFL
        val duration = if (wide) buffer.getLong(24) else buffer.getInt(16).toLong() and 0xFFFFFFFFL
        return if (timescale > 0) (duration / timescale).toInt() else 0
    }

    /** Triple(codec, sample rate, bit depth). Bit depth hanya diisi untuk ALAC (lossless). */
    private fun audioFormat(): Triple<String, String, String> {
        for (trak in moov.children.orEmpty().filter { it.type == "trak" }) {
            val stsd = trak.child("mdia")?.child("minf")?.child("stbl")?.child("stsd")?.payload ?: continue
            if (stsd.size < 44) continue
            val buffer = ByteBuffer.wrap(stsd)
            val format = fourCc(buffer.getInt(12))
            val codec = when (format) {
                "alac" -> "ALAC"
                "mp4a" -> "AAC"
                else -> continue
            }
            // ALAC: sample rate akurat (termasuk > 65 kHz) ada di akhir magic cookie.
            val rate = if (format == "alac" && stsd.size >= 80 && fourCc(buffer.getInt(48)) == "alac") {
                buffer.getInt(76)
            } else {
                buffer.getInt(40) ushr 16
            }
            // ALAC: bit depth ada di ALACSpecificConfig (1 byte di offset 61 magic cookie).
            val depth = if (format == "alac" && stsd.size >= 80 && fourCc(buffer.getInt(48)) == "alac") {
                (stsd[61].toInt() and 0xFF).takeIf { it in 8..32 }?.toString().orEmpty()
            } else {
                ""
            }
            return Triple(codec, rate.toString(), depth)
        }
        return Triple("", "", "")
    }

    // ---------------------------------------------------------------- Ubah

    fun applyEdit(edit: TagEdit) {
        setText("©nam", edit.title)
        setText("©ART", edit.artist)
        setText("aART", edit.albumArtist)
        setText("©alb", edit.album)
        if (edit.genre != null) remove("gnre")
        setText("©gen", edit.genre)
        setText("©day", edit.year)
        setText("©cmt", edit.comment)
        setPair("trkn", edit.trackNumber, edit.trackTotal, 8)
        setPair("disk", edit.discNumber, edit.discTotal, 6)
        when (val cover = edit.cover) {
            CoverAction.Keep -> Unit
            CoverAction.Remove -> remove("covr")
            is CoverAction.Replace -> {
                val kind = if (cover.art.mimeType == "image/png") TYPE_PNG else TYPE_JPEG
                replace("covr", Mp4Node("covr", dataBox(kind, cover.art.bytes)))
            }
        }
    }

    /** Menulis atom "----:com.apple.iTunes:nama" (huruf kecil, konvensi foobar2000). */
    fun setFreeform(name: String, value: String?) {
        val list = editableItems()
        list.removeAll { freeformName(it).equals(name, ignoreCase = true) }
        if (value == null) return
        fun named(type: String, content: String) =
            Mp4Node(type, ByteArray(4) + content.toByteArray(Charsets.UTF_8))
        val parts = listOf(
            named("mean", ITUNES_ISSUER),
            named("name", name.lowercase(Locale.ROOT)),
            Mp4Node("data", dataPayload(TYPE_UTF8, value.toByteArray(Charsets.UTF_8))),
        )
        list += Mp4Node(FREEFORM, serialize(parts))
    }

    private fun setText(type: String, value: String?) {
        if (value == null) return
        if (value.isBlank()) {
            remove(type)
        } else {
            replace(type, Mp4Node(type, dataBox(TYPE_UTF8, value.trim().toByteArray(Charsets.UTF_8))))
        }
    }

    private fun setPair(type: String, number: String?, total: String?, length: Int) {
        if (number == null && total == null) return
        val (oldNumber, oldTotal) = pair(type)
        val n = (number ?: oldNumber).trim().toIntOrNull() ?: 0
        val t = (total ?: oldTotal).trim().toIntOrNull() ?: 0
        if (n == 0 && t == 0) {
            remove(type)
        } else {
            val value = ByteBuffer.allocate(length).putShort(2, n.toShort()).putShort(4, t.toShort()).array()
            replace(type, Mp4Node(type, dataBox(TYPE_BINARY, value)))
        }
    }

    private fun remove(type: String) {
        editableItems().removeAll { it.type == type }
    }

    private fun replace(type: String, item: Mp4Node) {
        val list = editableItems()
        list.removeAll { it.type == type }
        list += item
    }

    /** Daftar item ilst; membuat udta/meta/ilst bila belum ada. */
    private fun editableItems(): MutableList<Mp4Node> {
        val root = moov.children!!
        val udta = moov.child("udta") ?: Mp4Node("udta", children = mutableListOf()).also { root += it }
        val meta = udta.child("meta") ?: newMeta().also { udta.children!!.add(it) }
        val ilst = meta.child("ilst")
            ?: Mp4Node("ilst", children = mutableListOf()).also { meta.children!!.add(it) }
        return ilst.children!!
    }

    private fun newMeta(): Mp4Node {
        // hdlr: versi/flag, predefined, "mdir", "appl", 8 byte cadangan, nama kosong.
        val handler = ByteArray(25)
        "mdirappl".toByteArray(Charsets.ISO_8859_1).copyInto(handler, 8)
        return Mp4Node("meta", children = mutableListOf(Mp4Node("hdlr", handler)), prefix = ByteArray(4))
    }

    private fun dataPayload(type: Int, value: ByteArray): ByteArray =
        ByteBuffer.allocate(8 + value.size).putInt(type).putInt(0).put(value).array()

    private fun dataBox(type: Int, value: ByteArray): ByteArray =
        serialize(listOf(Mp4Node("data", dataPayload(type, value))))

    private fun serialize(nodes: List<Mp4Node>): ByteArray {
        val out = ByteBuffer.allocate(nodes.sumOf { it.size })
        nodes.forEach { it.writeTo(out) }
        return out.array()
    }

    // ---------------------------------------------------------------- Simpan

    fun save() {
        if (moov.child("mvex") != null) throw IOException("MP4 terfragmentasi belum didukung untuk penulisan")
        // Data audio yang berada setelah moov akan bergeser, jadi offset chunk harus disesuaikan.
        shiftChunkOffsets(moov.size - (moovEnd - moovStart))
        val bytes = serialize(listOf(moov))
        val output = File(file.parentFile, "${file.name}.tmp")
        try {
            FileInputStream(file).use { input ->
                FileOutputStream(output).use { stream ->
                    val source = input.channel
                    val target = stream.channel
                    copyRange(source, target, 0, moovStart)
                    val buffer = ByteBuffer.wrap(bytes)
                    while (buffer.hasRemaining()) target.write(buffer)
                    copyRange(source, target, moovEnd, source.size())
                }
            }
            if (!output.renameTo(file)) throw IOException("Gagal mengganti file sementara")
        } finally {
            output.delete()
        }
    }

    private fun copyRange(source: FileChannel, target: FileChannel, from: Long, to: Long) {
        var position = from
        while (position < to) {
            val moved = source.transferTo(position, to - position, target)
            if (moved <= 0) throw IOException("Gagal menyalin data audio")
            position += moved
        }
    }

    private fun shiftChunkOffsets(delta: Long) {
        if (delta == 0L) return
        for (trak in moov.children.orEmpty().filter { it.type == "trak" }) {
            val stbl = trak.child("mdia")?.child("minf")?.child("stbl") ?: continue
            for (table in stbl.children.orEmpty()) {
                val wide = table.type == "co64"
                if (!wide && table.type != "stco") continue
                val data = ByteBuffer.wrap(table.payload)
                for (i in 0 until data.getInt(4)) {
                    val at = 8 + i * (if (wide) 8 else 4)
                    val old = if (wide) data.getLong(at) else data.getInt(at).toLong() and 0xFFFFFFFFL
                    if (old < moovEnd) continue
                    val moved = old + delta
                    if (wide) {
                        data.putLong(at, moved)
                    } else {
                        if (moved > 0xFFFFFFFFL) throw IOException("File terlalu besar untuk tabel stco")
                        data.putInt(at, moved.toInt())
                    }
                }
            }
        }
    }

    private companion object {
        const val FREEFORM = "----"
        const val ITUNES_ISSUER = "com.apple.iTunes"
        const val TYPE_BINARY = 0
        const val TYPE_UTF8 = 1
        const val TYPE_JPEG = 13
        const val TYPE_PNG = 14
        const val MAX_MOOV = 64L * 1024 * 1024
    }
}

// =====================================================================================
// LOUDNESS: ITU-R BS.1770 / EBU R128
// =====================================================================================

/** Hasil pengukuran satu lagu. [blockEnergies] = energi berbobot tiap blok 400 ms. */
class LoudnessMeasurement(val blockEnergies: DoubleArray, val peak: Double)

object Loudness {
    /** Referensi ReplayGain 2.0 yang dipakai foobar2000. */
    const val REFERENCE_LUFS = -18.0

    private const val ABSOLUTE_GATE_LUFS = -70.0
    private const val RELATIVE_GATE_LU = -10.0

    /**
     * Integrated loudness dengan gating dua tahap. Untuk album, berikan blok semua lagu:
     * gating dihitung gabungan, bukan rata-rata nilai per lagu.
     * Mengembalikan null bila tidak ada blok di atas -70 LUFS.
     */
    fun integrated(tracks: List<DoubleArray>): Double? {
        val absoluteThreshold = energyOf(ABSOLUTE_GATE_LUFS)
        val first = meanAbove(tracks, absoluteThreshold) ?: return null
        val relativeThreshold = first * 10.0.pow(RELATIVE_GATE_LU / 10.0)
        val gated = meanAbove(tracks, max(absoluteThreshold, relativeThreshold)) ?: return null
        return -0.691 + 10.0 * log10(gated)
    }

    private fun energyOf(lufs: Double) = 10.0.pow((lufs + 0.691) / 10.0)

    private fun meanAbove(tracks: List<DoubleArray>, threshold: Double): Double? {
        var sum = 0.0
        var count = 0L
        for (blocks in tracks) {
            for (energy in blocks) {
                if (energy > threshold) {
                    sum += energy
                    count++
                }
            }
        }
        return if (count == 0L) null else sum / count
    }

    /** Posisi speaker WAVE bawaan untuk jumlah kanal tertentu. */
    fun defaultChannelMask(channels: Int): Int = when (channels) {
        1 -> 0x4
        2 -> 0x3
        3 -> 0x7
        4 -> 0x33
        5 -> 0x37
        6 -> 0x3F
        7 -> 0x70F
        8 -> 0x63F
        else -> 0
    }

    /** Bobot kanal BS.1770: LFE diabaikan, surround 1,41, lainnya 1,0. */
    fun channelWeights(channels: Int, mask: Int = 0): DoubleArray {
        val effective = if (Integer.bitCount(mask) == channels) mask else defaultChannelMask(channels)
        val weights = DoubleArray(channels) { 1.0 }
        val hasSide = effective and 0x600 != 0
        var channel = 0
        var bit = 0
        while (bit < 31 && channel < channels) {
            val position = 1 shl bit
            if (effective and position != 0) {
                weights[channel] = when {
                    position == 0x8 -> 0.0
                    position and 0x600 != 0 -> 1.41
                    position and 0x30 != 0 -> if (hasSide) 1.0 else 1.41
                    else -> 1.0
                }
                channel++
            }
            bit++
        }
        return weights
    }
}

class LoudnessMeter(
    sampleRate: Int,
    private val channels: Int,
    private val weights: DoubleArray,
    useTruePeak: Boolean,
) {
    init {
        require(sampleRate in 8000..768000) { "Sample rate tidak didukung: $sampleRate" }
        require(channels in 1..32 && weights.size == channels) { "Jumlah kanal tidak didukung: $channels" }
    }

    // Tahap 1: high-shelf (efek kepala). Koefisien dihitung ulang untuk sample rate apa pun.
    private val s: DoubleArray = run {
        val f0 = 1681.974450955533
        val gain = 3.999843853973347
        val q = 0.7071752369554196
        val k = tan(PI * f0 / sampleRate)
        val vh = 10.0.pow(gain / 20.0)
        val vb = vh.pow(0.4996667741545416)
        val a0 = 1.0 + k / q + k * k
        doubleArrayOf(
            (vh + vb * k / q + k * k) / a0,
            2.0 * (k * k - vh) / a0,
            (vh - vb * k / q + k * k) / a0,
            2.0 * (k * k - 1.0) / a0,
            (1.0 - k / q + k * k) / a0,
        )
    }

    // Tahap 2: high-pass RLB. Pembilangnya tetap 1, -2, 1.
    private val h: DoubleArray = run {
        val f0 = 38.13547087602444
        val q = 0.5003270373238773
        val k = tan(PI * f0 / sampleRate)
        val a0 = 1.0 + k / q + k * k
        doubleArrayOf(2.0 * (k * k - 1.0) / a0, (1.0 - k / q + k * k) / a0)
    }

    private val state = Array(channels) { DoubleArray(4) }

    private val subBlockFrames = (sampleRate + 5) / 10 // 100 ms
    private val recent = DoubleArray(4)
    private var subBlockCount = 0L
    private var framesInSubBlock = 0
    private var subBlockSum = 0.0

    private var blocks = DoubleArray(4096)
    private var blockSize = 0

    private var peak = 0.0

    private val oversampling = when {
        !useTruePeak -> 1
        sampleRate < 96000 -> 4
        sampleRate < 192000 -> 2
        else -> 1
    }
    private val phases: Array<DoubleArray> = Array(oversampling - 1) { p -> interpolator((p + 1.0) / oversampling) }
    private val history = Array(channels) { DoubleArray(TAPS * 2) }
    private var historyPos = 0

    /** [samples] berisi PCM interleaved dalam rentang -1..1. */
    fun process(samples: FloatArray, frames: Int) {
        var index = 0
        for (frame in 0 until frames) {
            var frameEnergy = 0.0
            for (c in 0 until channels) {
                var x = samples[index++].toDouble()
                if (!x.isFinite()) x = 0.0
                val magnitude = abs(x)
                if (magnitude > peak) peak = magnitude
                if (oversampling > 1) measureTruePeak(c, x)

                val z = state[c]
                val y1 = s[0] * x + z[0]
                z[0] = s[1] * x - s[3] * y1 + z[1]
                z[1] = s[2] * x - s[4] * y1
                val y2 = y1 + z[2]
                z[2] = -2.0 * y1 - h[0] * y2 + z[3]
                z[3] = y1 - h[1] * y2
                frameEnergy += weights[c] * y2 * y2
            }
            if (oversampling > 1) historyPos = (historyPos + 1) % TAPS
            subBlockSum += frameEnergy
            if (++framesInSubBlock == subBlockFrames) closeSubBlock()
        }
    }

    fun finish(): LoudnessMeasurement {
        if (oversampling > 1) {
            // Kosongkan sisa sinyal di filter interpolasi.
            repeat(TAPS) {
                for (c in 0 until channels) measureTruePeak(c, 0.0)
                historyPos = (historyPos + 1) % TAPS
            }
        }
        return LoudnessMeasurement(blocks.copyOf(blockSize), peak)
    }

    private fun closeSubBlock() {
        recent[(subBlockCount % 4).toInt()] = subBlockSum
        subBlockCount++
        subBlockSum = 0.0
        framesInSubBlock = 0
        if (subBlockCount >= 4) {
            if (blockSize == blocks.size) blocks = blocks.copyOf(blocks.size * 2)
            blocks[blockSize++] = (recent[0] + recent[1] + recent[2] + recent[3]) / (4.0 * subBlockFrames)
        }
    }

    private fun measureTruePeak(channel: Int, x: Double) {
        val buffer = history[channel]
        buffer[historyPos] = x
        buffer[historyPos + TAPS] = x
        val start = historyPos + 1 // sampel tertua
        for (taps in phases) {
            var sum = 0.0
            for (i in 0 until TAPS) sum += taps[i] * buffer[start + i]
            val magnitude = abs(sum)
            if (magnitude > peak) peak = magnitude
        }
    }

    /** FIR sinc berjendela Hann untuk posisi pecahan [offset] di antara dua sampel tengah. */
    private fun interpolator(offset: Double): DoubleArray {
        val half = TAPS / 2
        val taps = DoubleArray(TAPS) { i ->
            val t = i - (half - 1) - offset
            val sinc = sin(PI * t) / (PI * t)
            sinc * (0.5 + 0.5 * cos(PI * t / half))
        }
        val total = taps.sum()
        for (i in taps.indices) taps[i] /= total
        return taps
    }

    private companion object {
        const val TAPS = 24
    }
}

// =====================================================================================
// DECODER PCM
// FLAC/MP3/OGG/AAC: MediaExtractor + MediaCodec.
// WAV: dibaca langsung. ALAC: decoder Kotlin (tidak semua HP punya codec ALAC).
// =====================================================================================

internal class PcmDecoder(private val context: Context) {

    fun measure(item: AudioItem, useTruePeak: Boolean, checkCancelled: () -> Unit): LoudnessMeasurement {
        val sink = MeterSink(useTruePeak)
        val handled = when (item.extension) {
            "wav", "m4a", "m4b", "mp4" -> {
                val descriptor = context.contentResolver.openFileDescriptor(item.uri, "r")
                    ?: throw IOException("File tidak dapat dibuka")
                descriptor.use { pfd ->
                    FileInputStream(pfd.fileDescriptor).use { stream ->
                        if (item.extension == "wav") {
                            WavPcmReader.decode(stream.channel, sink, checkCancelled)
                        } else {
                            AlacMp4Reader.decode(stream.channel, sink, checkCancelled)
                        }
                    }
                }
            }
            else -> false
        }
        if (!handled) decodeWithMediaCodec(item.uri, sink, checkCancelled)
        return sink.finish()
    }

    private fun decodeWithMediaCodec(uri: Uri, sink: PcmSink, checkCancelled: () -> Unit) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                if (format.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    extractor.selectTrack(i)
                    inputFormat = format
                    break
                }
            }
            val format = inputFormat ?: throw IOException("Tidak ada trek audio yang dikenali")
            val mime = format.getString(MediaFormat.KEY_MIME)!!

            // Minta keluaran float agar presisi Hi-Res dan puncak > 0 dBFS tidak hilang.
            // Decoder boleh mengabaikannya; format keluaran sebenarnya dibaca di bawah.
            format.setInteger(MediaFormat.KEY_PCM_ENCODING, PcmFormat.FLOAT)
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var outputFormat: MediaFormat? = null
            var scratch = FloatArray(0)
            var lastProgress = SystemClock.elapsedRealtime()

            while (!outputDone) {
                checkCancelled()
                if (!inputDone) {
                    val inIndex = codec.dequeueInputBuffer(TIMEOUT_US)
                    if (inIndex >= 0) {
                        val buffer = codec.getInputBuffer(inIndex)!!
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIndex, 0, size, max(0L, extractor.sampleTime), 0)
                            extractor.advance()
                        }
                        lastProgress = SystemClock.elapsedRealtime()
                    }
                }

                val outIndex = codec.dequeueOutputBuffer(info, TIMEOUT_US)
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    outputFormat = codec.outputFormat
                    lastProgress = SystemClock.elapsedRealtime()
                } else if (outIndex >= 0) {
                    if (info.size > 0) {
                        val out = outputFormat ?: codec.outputFormat.also { outputFormat = it }
                        val sampleRate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        val channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        val encoding = if (out.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                            out.getInteger(MediaFormat.KEY_PCM_ENCODING)
                        } else {
                            PcmFormat.INT16
                        }
                        val mask = if (out.containsKey("channel-mask")) out.getInteger("channel-mask") else 0
                        // Mask Android memakai bit 2.. (FL = 0x4); geser ke bit WAVE.
                        sink.onFormat(sampleRate, channels, Loudness.channelWeights(channels, mask ushr 2))

                        val buffer = codec.getOutputBuffer(outIndex)!!
                        buffer.position(info.offset)
                        buffer.limit(info.offset + info.size)
                        val data = buffer.slice().order(ByteOrder.nativeOrder())
                        val count = info.size / PcmFormat.bytesPerSample(encoding)
                        if (scratch.size < count) scratch = FloatArray(count)
                        PcmFormat.toFloat(data, encoding, scratch, count)
                        sink.onPcm(scratch, count / channels)
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    lastProgress = SystemClock.elapsedRealtime()
                }

                if (SystemClock.elapsedRealtime() - lastProgress > STALL_LIMIT_MS) {
                    throw IOException("Decoder macet (tidak ada keluaran)")
                }
            }
        } finally {
            codec?.let {
                runCatching { it.stop() }
                it.release()
            }
            extractor.release()
        }
    }

    private companion object {
        const val TIMEOUT_US = 5_000L
        const val STALL_LIMIT_MS = 15_000L
    }
}

internal interface PcmSink {
    fun onFormat(sampleRate: Int, channels: Int, weights: DoubleArray)
    fun onPcm(samples: FloatArray, frames: Int)
}

internal class MeterSink(private val useTruePeak: Boolean) : PcmSink {
    private var meter: LoudnessMeter? = null
    private var rate = 0
    private var channelCount = 0
    private var totalFrames = 0L

    override fun onFormat(sampleRate: Int, channels: Int, weights: DoubleArray) {
        if (meter == null || (totalFrames == 0L && (sampleRate != rate || channels != channelCount))) {
            meter = LoudnessMeter(sampleRate, channels, weights, useTruePeak)
            rate = sampleRate
            channelCount = channels
        } else if (sampleRate != rate || channels != channelCount) {
            throw IOException("Format audio berubah di tengah file")
        }
    }

    override fun onPcm(samples: FloatArray, frames: Int) {
        checkNotNull(meter) { "Format PCM belum diketahui" }.process(samples, frames)
        totalFrames += frames
    }

    fun finish(): LoudnessMeasurement {
        val active = meter
        if (active == null || totalFrames == 0L) throw IOException("Tidak ada data audio yang berhasil di-decode")
        return active.finish()
    }
}

/** Konstanta sama dengan android.media.AudioFormat.ENCODING_PCM_*. */
internal object PcmFormat {
    const val INT16 = 2
    const val UINT8 = 3
    const val FLOAT = 4
    const val INT24 = 21
    const val INT32 = 22
    const val FLOAT64 = -64 // khusus WAV

    fun bytesPerSample(encoding: Int): Int = when (encoding) {
        UINT8 -> 1
        INT16 -> 2
        INT24 -> 3
        INT32, FLOAT -> 4
        FLOAT64 -> 8
        else -> throw IOException("Encoding PCM tidak didukung: $encoding")
    }

    fun toFloat(source: ByteBuffer, encoding: Int, target: FloatArray, count: Int) {
        val base = source.position()
        val little = source.order() == ByteOrder.LITTLE_ENDIAN
        for (i in 0 until count) {
            val p = base + i * bytesPerSample(encoding)
            target[i] = when (encoding) {
                UINT8 -> ((source.get(p).toInt() and 0xFF) - 128) / 128f
                INT16 -> source.getShort(p) / 32768f
                INT24 -> {
                    val a = source.get(p).toInt() and 0xFF
                    val b = source.get(p + 1).toInt() and 0xFF
                    val c = source.get(p + 2).toInt() and 0xFF
                    val packed = if (little) (c shl 24) or (b shl 16) or (a shl 8)
                    else (a shl 24) or (b shl 16) or (c shl 8)
                    packed / 2147483648f
                }
                INT32 -> source.getInt(p) / 2147483648f
                FLOAT -> source.getFloat(p)
                else -> source.getDouble(p).toFloat()
            }
        }
    }
}

private fun FileChannel.readAt(position: Long, length: Int): ByteBuffer {
    val buffer = ByteBuffer.allocate(length)
    while (buffer.hasRemaining()) {
        if (read(buffer, position + buffer.position()) < 0) throw IOException("File terpotong")
    }
    buffer.flip()
    return buffer
}

private fun fourCc(value: Int): String =
    String(byteArrayOf((value ushr 24).toByte(), (value ushr 16).toByte(), (value ushr 8).toByte(), value.toByte()), Charsets.ISO_8859_1)

// -------------------------------------------------------------------------------- WAV

internal object WavPcmReader {

    /** Mengembalikan false bila isi WAV bukan PCM/float (mis. ADPCM), agar dicoba MediaCodec. */
    fun decode(channel: FileChannel, sink: PcmSink, checkCancelled: () -> Unit): Boolean {
        val size = channel.size()
        if (size < 12) return false
        val riff = channel.readAt(0, 12)
        if (fourCc(riff.getInt(0)) != "RIFF" || fourCc(riff.getInt(8)) != "WAVE") return false

        var position = 12L
        var encoding = 0
        var channels = 0
        var sampleRate = 0
        var mask = 0
        while (position + 8 <= size) {
            val head = channel.readAt(position, 8)
            val id = fourCc(head.getInt(0))
            val length = head.order(ByteOrder.LITTLE_ENDIAN).getInt(4).toLong() and 0xFFFFFFFFL
            val body = position + 8
            if (id == "fmt ") {
                if (length < 16 || body + length > size) return false
                val fmt = channel.readAt(body, minOf(length, 40L).toInt()).order(ByteOrder.LITTLE_ENDIAN)
                var tag = fmt.getShort(0).toInt() and 0xFFFF
                channels = fmt.getShort(2).toInt() and 0xFFFF
                sampleRate = fmt.getInt(4)
                val blockAlign = fmt.getShort(12).toInt() and 0xFFFF
                if (tag == 0xFFFE && length >= 40) {
                    mask = fmt.getInt(20)
                    tag = fmt.getShort(24).toInt() and 0xFFFF
                }
                // Lebar wadah per sampel (20-bit disimpan dalam 3 byte, dst).
                val width = if (channels > 0) blockAlign / channels else 0
                encoding = when {
                    tag == 1 && width == 1 -> PcmFormat.UINT8
                    tag == 1 && width == 2 -> PcmFormat.INT16
                    tag == 1 && width == 3 -> PcmFormat.INT24
                    tag == 1 && width == 4 -> PcmFormat.INT32
                    tag == 3 && width == 4 -> PcmFormat.FLOAT
                    tag == 3 && width == 8 -> PcmFormat.FLOAT64
                    else -> return false
                }
            } else if (id == "data") {
                if (encoding == 0) return false
                val frameBytes = PcmFormat.bytesPerSample(encoding) * channels
                var remaining = if (length == 0L || body + length > size) size - body else length
                sink.onFormat(sampleRate, channels, Loudness.channelWeights(channels, mask))
                val chunkFrames = 8192
                val buffer = ByteBuffer.allocate(chunkFrames * frameBytes).order(ByteOrder.LITTLE_ENDIAN)
                val floats = FloatArray(chunkFrames * channels)
                var offset = body
                while (remaining >= frameBytes) {
                    checkCancelled()
                    buffer.clear()
                    buffer.limit(minOf(buffer.capacity().toLong(), remaining - remaining % frameBytes).toInt())
                    while (buffer.hasRemaining()) {
                        if (channel.read(buffer, offset + buffer.position()) < 0) break
                    }
                    val frames = buffer.position() / frameBytes
                    if (frames == 0) break
                    buffer.flip()
                    PcmFormat.toFloat(buffer, encoding, floats, frames * channels)
                    sink.onPcm(floats, frames)
                    offset += (frames * frameBytes).toLong()
                    remaining -= (frames * frameBytes).toLong()
                }
                return true
            }
            position = body + length + (length and 1L)
        }
        return false
    }
}

// -------------------------------------------------------------------------------- ALAC

/** Pembaca tabel sampel MP4 minimal, khusus trek ALAC (M4A non-fragmented). */
internal object AlacMp4Reader {

    private class Box(val type: String, val start: Int, val end: Int)

    private class AlacTrack(val config: ByteArray, val offsets: LongArray, val sizes: IntArray)

    /** Mengembalikan false bila file tidak berisi ALAC (mis. AAC). */
    fun decode(channel: FileChannel, sink: PcmSink, checkCancelled: () -> Unit): Boolean {
        val moov = findMoov(channel) ?: return false
        val track = boxes(moov, 0, moov.limit())
            .filter { it.type == "trak" }
            .firstNotNullOfOrNull { parseTrack(moov, it) }
            ?: return false

        val decoder = AlacDecoder(track.config)
        sink.onFormat(decoder.sampleRate, decoder.channels, weightsFor(decoder.channels))
        val pcm = FloatArray(decoder.frameLength * decoder.channels)
        for (i in track.sizes.indices) {
            checkCancelled()
            val size = track.sizes[i]
            if (size <= 0 || size > MAX_PACKET) throw IOException("Ukuran paket ALAC tidak valid")
            val packet = channel.readAt(track.offsets[i], size).array()
            val frames = decoder.decode(packet, pcm)
            sink.onPcm(pcm, frames)
        }
        return true
    }

    /** Urutan kanal ALAC berbeda dari WAVE (center di depan). */
    private fun weightsFor(channels: Int): DoubleArray = when (channels) {
        3 -> doubleArrayOf(1.0, 1.0, 1.0)
        4 -> doubleArrayOf(1.0, 1.0, 1.0, 1.0)
        5 -> doubleArrayOf(1.0, 1.0, 1.0, 1.41, 1.41)
        6 -> doubleArrayOf(1.0, 1.0, 1.0, 1.41, 1.41, 0.0)
        7 -> doubleArrayOf(1.0, 1.0, 1.0, 1.41, 1.41, 1.0, 0.0)
        8 -> doubleArrayOf(1.0, 1.0, 1.0, 1.0, 1.0, 1.41, 1.41, 0.0)
        else -> DoubleArray(channels) { 1.0 }
    }

    private fun findMoov(channel: FileChannel): ByteBuffer? {
        val size = channel.size()
        var position = 0L
        while (position + 8 <= size) {
            val head = channel.readAt(position, 8)
            var length = head.getInt(0).toLong() and 0xFFFFFFFFL
            val type = fourCc(head.getInt(4))
            var header = 8L
            if (length == 1L) {
                length = channel.readAt(position + 8, 8).getLong(0)
                header = 16L
            } else if (length == 0L) {
                length = size - position
            }
            if (length < header || length > size - position) return null
            if (type == "moov") {
                if (length - header > MAX_MOOV) throw IOException("Metadata MP4 terlalu besar")
                return channel.readAt(position + header, (length - header).toInt())
            }
            position += length
        }
        return null
    }

    private fun boxes(data: ByteBuffer, start: Int, end: Int): List<Box> {
        val result = mutableListOf<Box>()
        var p = start
        while (p + 8 <= end) {
            var length = data.getInt(p).toLong() and 0xFFFFFFFFL
            var header = 8
            if (length == 1L && p + 16 <= end) {
                length = data.getLong(p + 8)
                header = 16
            } else if (length == 0L) {
                length = (end - p).toLong()
            }
            if (length < header || length > end - p) break
            result += Box(fourCc(data.getInt(p + 4)), p + header, p + length.toInt())
            p += length.toInt()
        }
        return result
    }

    private fun child(data: ByteBuffer, parent: Box, type: String): Box? =
        boxes(data, parent.start, parent.end).firstOrNull { it.type == type }

    private fun parseTrack(data: ByteBuffer, trak: Box): AlacTrack? {
        val mdia = child(data, trak, "mdia") ?: return null
        val minf = child(data, mdia, "minf") ?: return null
        val stbl = child(data, minf, "stbl") ?: return null
        val stsd = child(data, stbl, "stsd") ?: return null
        // stsd: versi/flag (4) + jumlah entri (4), lalu entri sampel.
        val entry = boxes(data, stsd.start + 8, stsd.end).firstOrNull { it.type == "alac" } ?: return null
        val version = data.getShort(entry.start + 8).toInt()
        val extensionStart = entry.start + 28 + when (version) {
            1 -> 16
            2 -> 36
            else -> 0
        }
        val children = boxes(data, extensionStart, entry.end)
        val cookie = children.firstOrNull { it.type == "alac" }
            ?: children.firstOrNull { it.type == "wave" }?.let { child(data, it, "alac") }
            ?: throw IOException("Konfigurasi ALAC tidak ditemukan")
        if (cookie.end - cookie.start < 28) throw IOException("Konfigurasi ALAC rusak")
        val config = ByteArray(24) { data.get(cookie.start + 4 + it) }

        val stsz = child(data, stbl, "stsz") ?: throw IOException("Tabel stsz tidak ada")
        val fixedSize = data.getInt(stsz.start + 4)
        val sampleCount = data.getInt(stsz.start + 8)
        if (sampleCount !in 1..MAX_SAMPLES) {
            throw IOException("MP4 terfragmentasi atau tabel sampel tidak valid")
        }
        val sizes = IntArray(sampleCount) { if (fixedSize != 0) fixedSize else data.getInt(stsz.start + 12 + it * 4) }

        val stco = child(data, stbl, "stco")
        val co64 = child(data, stbl, "co64")
        val chunkOffsets: LongArray = when {
            stco != null -> LongArray(data.getInt(stco.start + 4)) {
                data.getInt(stco.start + 8 + it * 4).toLong() and 0xFFFFFFFFL
            }
            co64 != null -> LongArray(data.getInt(co64.start + 4)) { data.getLong(co64.start + 8 + it * 8) }
            else -> throw IOException("Tabel offset chunk tidak ada")
        }

        val stsc = child(data, stbl, "stsc") ?: throw IOException("Tabel stsc tidak ada")
        val runs = data.getInt(stsc.start + 4)
        val offsets = LongArray(sampleCount)
        var sample = 0
        for (run in 0 until runs) {
            val base = stsc.start + 8 + run * 12
            val firstChunk = data.getInt(base)
            val perChunk = data.getInt(base + 4)
            val nextFirst = if (run + 1 < runs) data.getInt(base + 12) else chunkOffsets.size + 1
            for (chunk in firstChunk until nextFirst) {
                var offset = chunkOffsets[chunk - 1]
                var n = 0
                while (n < perChunk && sample < sampleCount) {
                    offsets[sample] = offset
                    offset += sizes[sample]
                    sample++
                    n++
                }
            }
        }
        if (sample != sampleCount) throw IOException("Tabel sampel MP4 tidak konsisten")
        return AlacTrack(config, offsets, sizes)
    }

    private const val MAX_MOOV = 64L * 1024 * 1024
    private const val MAX_PACKET = 8 * 1024 * 1024
    private const val MAX_SAMPLES = 4_000_000
}

/** Decoder ALAC, porting dari implementasi referensi Apple (lisensi Apache 2.0). */
internal class AlacDecoder(config: ByteArray) {
    val frameLength: Int
    private val bitDepth: Int
    private val pb: Int
    private val mb: Int
    private val kb: Int
    val channels: Int
    val sampleRate: Int

    init {
        val c = ByteBuffer.wrap(config)
        frameLength = c.getInt(0)
        bitDepth = c.get(5).toInt() and 0xFF
        pb = c.get(6).toInt() and 0xFF
        mb = c.get(7).toInt() and 0xFF
        kb = c.get(8).toInt() and 0xFF
        channels = c.get(9).toInt() and 0xFF
        sampleRate = c.getInt(20)
        if (c.get(4).toInt() != 0 || frameLength !in 1..65536 ||
            bitDepth !in intArrayOf(16, 20, 24, 32) || channels !in 1..8
        ) {
            throw IOException("Konfigurasi ALAC tidak didukung")
        }
    }

    private val residual = IntArray(frameLength)
    private val mixed = Array(2) { IntArray(frameLength) }
    private val shifted = IntArray(frameLength * 2)

    private class Bits(private val data: ByteArray) {
        var position = 0

        /** 32 bit berikutnya tanpa memajukan posisi (diisi nol setelah akhir data). */
        fun peek32(): Int {
            val byte = position ushr 3
            var value = 0L
            for (i in 0 until 5) {
                val b = if (byte + i < data.size) data[byte + i].toInt() and 0xFF else 0
                value = (value shl 8) or b.toLong()
            }
            return (value ushr (8 - (position and 7))).toInt()
        }

        fun peek(count: Int): Int = if (count == 0) 0 else peek32() ushr (32 - count)

        fun read(count: Int): Int {
            if (position + count > data.size * 8) throw IOException("Paket ALAC terpotong")
            val value = peek(count)
            position += count
            return value
        }

        fun skip(count: Int) {
            position += count
            if (position < 0 || position > data.size * 8) throw IOException("Paket ALAC terpotong")
        }
    }

    /** Men-decode satu paket ke [out] (interleaved, -1..1) dan mengembalikan jumlah frame. */
    fun decode(packet: ByteArray, out: FloatArray): Int {
        val bits = Bits(packet)
        var channel = 0
        var frames = 0
        val scale = (1L shl (bitDepth - 1)).toFloat()
        while (channel < channels) {
            when (val element = bits.read(3)) {
                0, 1, 3 -> {
                    val count = if (element == 1) 2 else 1
                    if (channel + count > channels) throw IOException("Susunan kanal ALAC tidak valid")
                    val decoded = decodeElement(bits, count)
                    if (frames != 0 && decoded != frames) throw IOException("Panjang kanal ALAC berbeda")
                    frames = decoded
                    for (c in 0 until count) {
                        val source = mixed[c]
                        for (i in 0 until decoded) out[i * channels + channel + c] = source[i] / scale
                    }
                    channel += count
                }
                4 -> { // data stream element
                    bits.read(4)
                    val align = bits.read(1)
                    var length = bits.read(8)
                    if (length == 255) length += bits.read(8)
                    if (align != 0) bits.skip((8 - (bits.position and 7)) and 7)
                    bits.skip(length * 8)
                }
                6 -> { // fill element
                    var length = bits.read(4)
                    if (length == 15) length += bits.read(8) - 1
                    bits.skip(length * 8)
                }
                else -> throw IOException("Elemen ALAC tidak didukung atau paket rusak")
            }
        }
        return frames
    }

    private fun decodeElement(bits: Bits, count: Int): Int {
        bits.read(4) // instance tag
        if (bits.read(12) != 0) throw IOException("Header ALAC tidak valid")
        val header = bits.read(4)
        val partial = header ushr 3
        val bytesShifted = (header ushr 1) and 3
        val escape = header and 1
        if (bytesShifted == 3) throw IOException("Header ALAC tidak valid")

        var samples = frameLength
        if (partial != 0) samples = (bits.read(16) shl 16) or bits.read(16)
        if (samples !in 1..frameLength) throw IOException("Panjang frame ALAC tidak valid")

        if (escape != 0) {
            // Data tidak dikompresi.
            for (i in 0 until samples) {
                for (c in 0 until count) mixed[c][i] = signExtend(bits.read(bitDepth), bitDepth)
            }
            return samples
        }

        val shiftBits = bytesShifted * 8
        val chanBits = bitDepth - shiftBits + (count - 1)
        if (chanBits !in 1..32) throw IOException("Kedalaman bit ALAC tidak valid")

        val mixBits = bits.read(8)
        val mixRes = signExtend(bits.read(8), 8)
        val modes = IntArray(count)
        val denShifts = IntArray(count)
        val pbFactors = IntArray(count)
        val coefficients = Array(count) { IntArray(0) }
        for (c in 0 until count) {
            modes[c] = bits.read(4)
            denShifts[c] = bits.read(4)
            pbFactors[c] = bits.read(3)
            val order = bits.read(5)
            coefficients[c] = IntArray(order) { signExtend(bits.read(16), 16) }
        }

        val shiftStart = bits.position
        if (shiftBits != 0) bits.skip(shiftBits * count * samples)

        for (c in 0 until count) {
            entropyDecode(bits, samples, chanBits, (pb * pbFactors[c]) / 4)
            if (modes[c] != 0) predict(residual, residual, samples, IntArray(0), 31, chanBits, 0)
            predict(residual, mixed[c], samples, coefficients[c], coefficients[c].size, chanBits, denShifts[c])
        }

        if (shiftBits != 0) {
            val end = bits.position
            bits.position = shiftStart
            for (i in 0 until samples * count) shifted[i] = bits.read(shiftBits)
            bits.position = end
        }

        if (count == 2 && mixRes != 0) {
            val u = mixed[0]
            val v = mixed[1]
            for (i in 0 until samples) {
                val left = u[i] + v[i] - ((mixRes * v[i]) shr mixBits)
                val right = left - v[i]
                u[i] = left
                v[i] = right
            }
        }

        if (shiftBits != 0) {
            for (i in 0 until samples) {
                for (c in 0 until count) mixed[c][i] = (mixed[c][i] shl shiftBits) or shifted[i * count + c]
            }
        }
        return samples
    }

    /** Adaptive Golomb-Rice (ag_dec). */
    private fun entropyDecode(bits: Bits, samples: Int, maxBits: Int, pbLocal: Int) {
        var mean = mb
        var zeroMode = 0
        val wideMask = (1 shl kb) - 1
        var i = 0
        while (i < samples) {
            var k = 31 - Integer.numberOfLeadingZeros((mean ushr 9) + 3)
            if (k > kb) k = kb
            var m = (1 shl k) - 1

            var prefix = Integer.numberOfLeadingZeros(bits.peek32().inv())
            val n: Int
            if (prefix >= MAX_PREFIX) {
                bits.skip(MAX_PREFIX)
                n = bits.read(maxBits)
            } else {
                bits.skip(prefix + 1)
                var value = prefix
                if (k != 1) {
                    val v = bits.peek(k)
                    value = prefix * m
                    if (v >= 2) {
                        value += v - 1
                        bits.skip(k)
                    } else {
                        bits.skip(k - 1)
                    }
                }
                n = value
            }

            val decoded = n + zeroMode
            val sign = -(decoded and 1) or 1
            residual[i++] = ((decoded + 1) ushr 1) * sign

            mean = pbLocal * (n + zeroMode) + mean - ((pbLocal * mean) shr 9)
            if (n > 0xFFFF) mean = 0xFFFF
            zeroMode = 0

            // Mode deretan nol.
            if ((mean shl 2) < 512 && i < samples) {
                zeroMode = 1
                k = Integer.numberOfLeadingZeros(mean) - 24 + ((mean + 16) shr 6)
                m = ((1 shl k) - 1) and wideMask
                prefix = Integer.numberOfLeadingZeros(bits.peek32().inv())
                val run: Int
                if (prefix >= MAX_PREFIX) {
                    bits.skip(MAX_PREFIX)
                    run = bits.read(16)
                } else {
                    bits.skip(prefix + 1)
                    val v = bits.peek(k)
                    if (v >= 2) {
                        run = prefix * m + v - 1
                        bits.skip(k)
                    } else {
                        run = prefix * m
                        bits.skip(k - 1)
                    }
                }
                if (run > samples - i) throw IOException("Data ALAC rusak")
                residual.fill(0, i, i + run)
                i += run
                if (run >= 65535) zeroMode = 0
                mean = 0
            }
        }
    }

    /** Prediktor linier adaptif (dp_dec). */
    private fun predict(
        input: IntArray,
        output: IntArray,
        samples: Int,
        coefficients: IntArray,
        order: Int,
        chanBits: Int,
        denShift: Int,
    ) {
        output[0] = input[0]
        if (order == 0) {
            input.copyInto(output, 1, 1, samples)
            return
        }
        if (order == 31) {
            var previous = output[0]
            for (j in 1 until samples) {
                previous = signExtend(input[j] + previous, chanBits)
                output[j] = previous
            }
            return
        }
        var j = 1
        while (j <= order && j < samples) {
            output[j] = signExtend(input[j] + output[j - 1], chanBits)
            j++
        }
        val half = if (denShift > 0) 1 shl (denShift - 1) else 0
        val first = order + 1
        for (n in first until samples) {
            val top = output[n - first]
            var sum = 0
            for (k in 0 until order) sum += coefficients[k] * (output[n - 1 - k] - top)
            var error = input[n]
            val direction = Integer.signum(error)
            output[n] = signExtend(error + top + ((sum + half) shr denShift), chanBits)
            if (direction == 0) continue
            for (k in order - 1 downTo 0) {
                val difference = top - output[n - 1 - k]
                val sign = Integer.signum(difference)
                coefficients[k] = signExtend(coefficients[k] - direction * sign, 16)
                error -= (order - k) * ((direction * sign * difference) shr denShift)
                if (direction > 0 && error <= 0) break
                if (direction < 0 && error >= 0) break
            }
        }
    }

    private fun signExtend(value: Int, bits: Int): Int {
        val shift = 32 - bits
        return (value shl shift) shr shift
    }

    private companion object {
        const val MAX_PREFIX = 9
    }
}
