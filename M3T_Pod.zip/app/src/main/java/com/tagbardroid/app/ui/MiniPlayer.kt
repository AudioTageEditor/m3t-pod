// File: app/src/main/java/com/tagbardroid/app/ui/MiniPlayer.kt
package com.tagbardroid.app.ui

import androidx.compose.animation.AnimatedContent
import com.tagbardroid.app.TechInfo
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.layout.heightIn
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.snap
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.key
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.StrokeCap
import kotlinx.coroutines.launch
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.scale
import kotlinx.coroutines.CoroutineStart
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tagbardroid.app.MainViewModel
import com.tagbardroid.app.PlayerMode
import com.tagbardroid.app.library.LibraryTrack
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sign

private const val REFLECTION_FRACTION = 0.30f
private val COVER_RADIUS = 6.dp
private val CARD_MARGIN = 8.dp
private val CARD_SHAPE = RoundedCornerShape(10.dp)

// Ukuran jendela pemutar penuh. Batas minimum menjaga tombol dan Cover Flow tetap proporsional;
// batas maksimum adalah seluruh layar dikurangi margin.
private val MIN_CARD_WIDTH = 300.dp
private val MIN_CARD_HEIGHT = 380.dp
private val DEFAULT_CARD_WIDTH = 380.dp
private val DEFAULT_CARD_HEIGHT = 470.dp
private val RESIZE_HANDLE = 28.dp

// Carousel sampul audioTag: sampul aktif besar dan lurus di tengah, sampul samping mengecil,
// sedikit miring ke belakang, dan meredup.
/** Kemiringan sampul samping; tepi luarnya menjauh dari layar. */
private const val SIDE_TILT = 24f
/** Skala sampul tetangga pertama dan kedua terhadap sampul tengah. */
private const val NEAR_SCALE = 0.78f
private const val FAR_SCALE = 0.62f
/** Jarak titik tengah sampul tetangga dari tengah, dalam lebar sampul. */
private const val NEAR_OFFSET = 0.74f
private const val FAR_OFFSET = 1.20f
private const val NEAR_ALPHA = 0.88f
private const val FAR_ALPHA = 0.55f
/** Banyaknya sampul yang disiapkan di tiap sisi (yang ketiga masih transparan, siap meluncur masuk). */
private const val VISIBLE_SIDE = 3
private const val REFLECTION_GAP = 0.012f
private val MAX_COVER_SIDE = 210.dp

private fun Modifier.hairline(color: Color, top: Boolean): Modifier = drawBehind {
    val w = 1.dp.toPx()
    drawRect(color, topLeft = Offset(0f, if (top) 0f else size.height - w), size = Size(size.width, w))
}

private fun frameBrush() = Brush.verticalGradient(listOf(Classic.borderLight, Classic.border))

/**
 * Pemutar melayang di dalam aplikasi. Seluruh kartu bisa ditarik ke mana saja (kecuali bilah
 * progres dan tombol), selalu dijepit di dalam layar. Pemutar penuh bisa diubah ukurannya dengan
 * menyeret gagang di pojok kanan bawah. Bisa dikecilkan menjadi kapsul atau disembunyikan.
 * Suara berjalan terus karena pemutarnya hidup di ViewModel.
 */
@Composable
fun MiniPlayer(vm: MainViewModel) {
    val player = vm.player
    val track = player.current
    val mode = vm.state.playerMode
    if (track == null || mode == PlayerMode.HIDDEN) return

    // NaN = belum pernah digeser: kartu berada di posisi awal (tengah bawah).
    var posX by remember { mutableFloatStateOf(Float.NaN) }
    var posY by remember { mutableFloatStateOf(Float.NaN) }
    var cardSize by remember { mutableStateOf(IntSize.Zero) }
    // Ukuran pemutar penuh dalam piksel; NaN = ukuran bawaan.
    var sizeW by remember { mutableFloatStateOf(Float.NaN) }
    var sizeH by remember { mutableFloatStateOf(Float.NaN) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val containerW = constraints.maxWidth.toFloat()
        val containerH = constraints.maxHeight.toFloat()
        val margin = with(density) { CARD_MARGIN.toPx() }

        // Batas ukuran: minimum tetap proporsional, maksimum seluruh layar kecuali margin.
        val maxW = max(1f, containerW - margin * 2)
        val maxH = max(1f, containerH - margin * 2)
        val minW = min(with(density) { MIN_CARD_WIDTH.toPx() }, maxW)
        val minH = min(with(density) { MIN_CARD_HEIGHT.toPx() }, maxH)
        val defaultW = min(with(density) { DEFAULT_CARD_WIDTH.toPx() }, maxW)
        val defaultH = with(density) { DEFAULT_CARD_HEIGHT.toPx() }
        fun expandedW() = (if (sizeW.isNaN()) defaultW else sizeW).coerceIn(minW, maxW)
        fun expandedH() = (if (sizeH.isNaN()) defaultH else sizeH).coerceIn(minH, maxH)

        // Batas dihitung dari ukuran kartu saat ini, jadi tetap benar ketika kartu berganti
        // antara kapsul dan pemutar penuh, atau ketika layar diputar.
        fun clampX(x: Float) = x.coerceIn(margin, max(margin, containerW - cardSize.width - margin))
        fun clampY(y: Float) = y.coerceIn(margin, max(margin, containerH - cardSize.height - margin))
        fun currentX() = if (posX.isNaN()) (containerW - cardSize.width) / 2f else posX
        fun currentY() = if (posY.isNaN()) containerH - cardSize.height - margin * 1.5f else posY

        // Gagang resize di pojok kanan bawah. Bila kartu melewati tepi layar, posisinya didorong
        // masuk sehingga kartu tetap bisa diperbesar dari posisi mana pun.
        fun resizeBy(dx: Float, dy: Float) {
            val w = (expandedW() + dx).coerceIn(minW, maxW)
            val h = (expandedH() + dy).coerceIn(minH, maxH)
            val x = currentX()
            val y = currentY()
            sizeW = w
            sizeH = h
            posX = x.coerceIn(margin, max(margin, containerW - w - margin))
            posY = y.coerceIn(margin, max(margin, containerH - h - margin))
        }

        Box(
            modifier = Modifier
                .offset { IntOffset(clampX(currentX()).roundToInt(), clampY(currentY()).roundToInt()) }
                .onSizeChanged { cardSize = it }
                .pointerInput(containerW, containerH, margin) {
                    // Anak yang menangani gestur sendiri (bilah progres, tombol, gagang resize) sudah
                    // menandai event sebagai terpakai, jadi hanya area kosong kartu yang menggeser overlay.
                    detectDragGestures { change, amount ->
                        change.consume()
                        posX = clampX(currentX() + amount.x)
                        posY = clampY(currentY() + amount.y)
                    }
                },
        ) {
            AnimatedContent(
                targetState = mode,
                transitionSpec = {
                    // Ukuran dilompatkan (snap), bukan dianimasikan, supaya menyeret gagang resize
                    // langsung diikuti kartu tanpa terasa tertinggal.
                    ContentTransform(
                        targetContentEnter = fadeIn(tween(220)) + scaleIn(tween(220), initialScale = 0.9f),
                        initialContentExit = fadeOut(tween(150)) + scaleOut(tween(150), targetScale = 0.9f),
                        sizeTransform = SizeTransform(clip = false) { _, _ -> snap() },
                    )
                },
                label = "player-mode",
            ) { current ->
                if (current == PlayerMode.CAPSULE) {
                    Capsule(vm, track)
                } else {
                    ExpandedPlayer(
                        vm = vm,
                        track = track,
                        width = with(density) { expandedW().toDp() },
                        height = with(density) { expandedH().toDp() },
                        onResize = { dx, dy -> resizeBy(dx, dy) },
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Tombol logam

/** Tombol logam glossy; [active] membuatnya biru seperti tombol Play yang menyala. */
@Composable
private fun MetalButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    content: @Composable () -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val shape = RoundedCornerShape(8.dp)
    val brush = when {
        active && pressed -> Classic.bluePressed
        active -> Classic.blueGloss
        pressed -> Classic.metalPressed
        else -> Classic.metal
    }
    Box(
        modifier = modifier
            .clip(shape)
            .background(brush)
            .border(1.dp, frameBrush(), shape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
        content = { content() },
    )
}

@Composable
private fun PlayPauseButton(playing: Boolean, onClick: () -> Unit, modifier: Modifier, iconSize: Dp) {
    MetalButton(onClick, modifier, active = true) {
        Crossfade(targetState = playing, animationSpec = tween(160), label = "play-pause") { isPlaying ->
            Icon(
                imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = if (isPlaying) "Jeda" else "Putar",
                tint = Color.White,
                modifier = Modifier.size(iconSize),
            )
        }
    }
}

@Composable
private fun TransportButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    MetalButton(onClick, Modifier.size(width = 58.dp, height = 42.dp)) {
        Icon(icon, contentDescription = description, tint = Classic.text, modifier = Modifier.size(28.dp))
    }
}

/** Tombol kecil di bilah judul, seperti tombol jendela desktop. */
@Composable
private fun BarButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier.size(34.dp).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = Classic.text, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun Chip(label: String, active: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(5.dp)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val brush = when {
        active -> Classic.blueGloss
        pressed -> Classic.metalPressed
        else -> Classic.metal
    }
    Box(
        modifier = Modifier
            .clip(shape)
            .background(brush)
            .border(1.dp, frameBrush(), shape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            style = Classic.body.copy(
                fontSize = 12.sp,
                color = if (active) Color.White else Classic.text,
                fontWeight = FontWeight.SemiBold,
            ),
        )
    }
}

// ------------------------------------------------------------------ Sampul

/** Sampul dari cache; bila belum ada dimuat di latar, dan dibatalkan bila tidak lagi dibutuhkan. */
@Composable
private fun rememberCover(vm: MainViewModel, track: LibraryTrack): ImageBitmap? {
    val current by remember(track) { derivedStateOf { vm.latestTrack(track) } }
    val key = remember(current) { vm.covers.key(current) }
    var bitmap by remember(key) { mutableStateOf(vm.covers.peek(key)) }
    LaunchedEffect(key) {
        if (bitmap == null) bitmap = vm.covers.load(current, key)
    }
    return bitmap
}

@Composable
private fun CoverImage(vm: MainViewModel, track: LibraryTrack, modifier: Modifier, radius: Dp) {
    val bitmap = rememberCover(vm, track)
    Box(
        modifier = modifier.clip(RoundedCornerShape(radius)).background(Classic.rowAlternate),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            Image(bitmap, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
        } else {
            Text("♪", style = Classic.body.copy(color = Classic.dim, fontSize = 22.sp))
        }
    }
}

// ------------------------------------------------------------------ Kapsul

@Composable
private fun Capsule(vm: MainViewModel, track: LibraryTrack) {
    val player = vm.player
    Row(
        modifier = Modifier
            .shadow(10.dp, CARD_SHAPE)
            .clip(CARD_SHAPE)
            .background(Classic.metal)
            .border(1.dp, frameBrush(), CARD_SHAPE)
            .clickable { vm.setPlayerMode(PlayerMode.EXPANDED) }
            .padding(5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        CoverImage(vm, track, Modifier.size(38.dp), radius = 3.dp)
        Text(
            track.displayTitle,
            modifier = Modifier.widthIn(max = 130.dp),
            style = Classic.body.copy(fontWeight = FontWeight.SemiBold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        PlayPauseButton(player.isPlaying, { player.toggle() }, Modifier.size(38.dp), iconSize = 24.dp)
        BarButton(Icons.Rounded.Close, "Tutup") { vm.setPlayerMode(PlayerMode.HIDDEN) }
    }
}

private fun formatMs(ms: Int): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}

// ------------------------------------------------------------------ Pemutar penuh

@Composable
private fun ExpandedPlayer(
    vm: MainViewModel,
    track: LibraryTrack,
    width: Dp,
    height: Dp,
    onResize: (dx: Float, dy: Float) -> Unit,
) {
    val player = vm.player
    val resize by rememberUpdatedState(onResize)
    val surface = Classic.panel

    Box(
        modifier = Modifier
            .size(width, height)
            .shadow(14.dp, CARD_SHAPE)
            .clip(CARD_SHAPE)
            .background(Classic.chrome)
            .border(1.dp, frameBrush(), CARD_SHAPE),
    ) {
        Column(Modifier.fillMaxSize()) {
            // Bilah judul logam ala jendela desktop dengan header "Now Playing".
            Row(
                modifier = Modifier.fillMaxWidth().height(34.dp).background(Classic.bar).hairline(Classic.border, top = false),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BarButton(Icons.Rounded.KeyboardArrowDown, "Kecilkan") { vm.setPlayerMode(PlayerMode.CAPSULE) }
                Text(
                    "Now Playing",
                    modifier = Modifier.weight(1f),
                    style = Classic.heading.copy(textAlign = TextAlign.Center),
                    maxLines = 1,
                )
                BarButton(Icons.Rounded.Close, "Tutup") { vm.setPlayerMode(PlayerMode.HIDDEN) }
            }

            // Carousel mengisi sisa tinggi, di bawahnya judul dan bilah progres. Warnanya mengikuti tema.
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(surface)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                CoverFlow(vm, surface, Modifier.fillMaxWidth().weight(1f))
                Spacer(Modifier.height(6.dp))
                Text(
                    track.displayTitle,
                    style = Classic.body.copy(color = Classic.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (track.tags.artist.isNotBlank()) {
                    Text(
                        track.tags.artist,
                        style = Classic.body.copy(color = Classic.dim, textAlign = TextAlign.Center),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                // Pilih Album: berganti album langsung dari pemutar; Cover Flow ikut berisi album baru.
                var pickingAlbum by remember { mutableStateOf(false) }
                AlbumPill(track.tags.album.ifBlank { "Pilih Album" }, enabled = vm.state.snapshot != null) { pickingAlbum = true }
                if (pickingAlbum) {
                    AlbumPicker(vm, onDismiss = { pickingAlbum = false })
                }
                // Format file: sample rate dan bit depth (Hi-Res bila di atas 48 kHz atau 16-bit).
                LaunchedEffect(track.documentId) { vm.requestTech(track) }
                audioFormatLine(vm.techFor(track))?.let { line ->
                    Text(
                        line,
                        modifier = Modifier.padding(top = 2.dp),
                        style = Classic.small.copy(color = Classic.accent, textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold),
                        maxLines = 1,
                    )
                }
                Spacer(Modifier.height(8.dp))
                ProgressRow(vm)
            }

            // Panel kontrol logam.
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Classic.chrome)
                    .hairline(Classic.border, top = true)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    TransportButton(Icons.Rounded.SkipPrevious, "Sebelumnya") { player.previous() }
                    PlayPauseButton(player.isPlaying, { player.toggle() }, Modifier.size(width = 72.dp, height = 46.dp), iconSize = 32.dp)
                    TransportButton(Icons.Rounded.SkipNext, "Berikutnya") { player.next() }
                }
                Row(
                    Modifier.padding(top = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Chip("Shuffle", player.shuffle) { player.applyShuffle(!player.shuffle) }
                    Chip("Album Play", player.albumMode) { vm.playAlbumOfCurrent() }
                    Chip("+ Playlist", false) { vm.addCurrentToPlaylist() }
                }
                player.error?.let {
                    Text(it, style = Classic.small.copy(color = Classic.error), modifier = Modifier.padding(top = 6.dp))
                }
            }
        }

        ResizeHandle(
            modifier = Modifier.align(Alignment.BottomEnd),
            onDrag = { dx, dy -> resize(dx, dy) },
        )
    }
}

/** Pil kecil bernama album dengan panah; diketuk untuk membuka pemilih album. */
@Composable
private fun AlbumPill(label: String, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = Modifier
            .padding(top = 3.dp)
            .clip(shape)
            .border(1.dp, Classic.grid, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(start = 10.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            modifier = Modifier.widthIn(max = 220.dp),
            style = Classic.small.copy(color = Classic.dim),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Pilih album", tint = Classic.dim, modifier = Modifier.size(18.dp))
    }
}

/** Daftar semua album pustaka. LazyColumn, jadi tetap ringan walau albumnya ribuan. */
@Composable
private fun AlbumPicker(vm: MainViewModel, onDismiss: () -> Unit) {
    val albums = remember(vm.state.snapshot) { vm.albumGroups() }
    val currentKey = remember(albums, vm.player.current, vm.player.albumMode) { vm.currentAlbumKey() }
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = albums.indexOfFirst { it.key == currentKey }.coerceAtLeast(0),
    )
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            modifier = Modifier
                .padding(horizontal = 24.dp)
                .fillMaxWidth()
                .widthIn(max = 420.dp)
                .heightIn(max = 460.dp)
                .shadow(14.dp, CARD_SHAPE)
                .clip(CARD_SHAPE)
                .background(Classic.panel)
                .border(1.dp, frameBrush(), CARD_SHAPE),
        ) {
            Row(
                Modifier.fillMaxWidth().background(Classic.bar).hairline(Classic.border, top = false).padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Pilih Album (${albums.size})", modifier = Modifier.weight(1f), style = Classic.heading)
                BarButton(Icons.Rounded.Close, "Tutup", onDismiss)
            }
            if (albums.isEmpty()) {
                Text("Belum ada album di pustaka.", modifier = Modifier.padding(16.dp), style = Classic.small)
            } else {
                LazyColumn(state = listState, modifier = Modifier.fillMaxWidth()) {
                    itemsIndexed(albums, key = { _, g -> g.key }) { index, group ->
                        val selected = group.key == currentKey
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (selected) Classic.selection else if (index % 2 == 1) Classic.rowAlternate else Classic.panel)
                                .clickable {
                                    vm.playAlbumGroup(group)
                                    onDismiss()
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    (if (selected) "▶ " else "") + group.title,
                                    style = Classic.body.copy(fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                if (group.subtitle.isNotBlank()) {
                                    Text(group.subtitle, style = Classic.small, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            Text("${group.tracks.size}", style = Classic.mono, modifier = Modifier.padding(start = 8.dp))
                        }
                    }
                }
            }
        }
    }
}

/** "Hi-Res · 96 kHz / 24-bit" dari info teknis file; null bila belum terbaca. */
private fun audioFormatLine(tech: TechInfo?): String? {
    if (tech == null) return null
    val rate = tech.sampleRate.toIntOrNull()?.takeIf { it > 0 } ?: return null
    val depth = tech.bitDepth.toIntOrNull()
    val khz = rate / 1000.0
    val rateText = (if (khz == khz.toInt().toDouble()) "%d".format(khz.toInt()) else "%.1f".format(khz)) + " kHz"
    val format = if (depth != null) "$rateText / $depth-bit" else rateText
    val hiRes = depth != null && (rate > 48000 || depth > 16)
    return if (hiRes) "Hi-Res · $format" else format
}

/** Gagang tarik di pojok kanan bawah: tiga garis diagonal ala jendela desktop. */
@Composable
private fun ResizeHandle(modifier: Modifier, onDrag: (Float, Float) -> Unit) {
    val drag by rememberUpdatedState(onDrag)
    val color = Classic.dim
    Box(
        modifier = modifier
            .size(RESIZE_HANDLE)
            .pointerInput(Unit) {
                detectDragGestures { change, amount ->
                    change.consume()
                    drag(amount.x, amount.y)
                }
            }
            .drawBehind {
                val stroke = 1.5.dp.toPx()
                val pad = 6.dp.toPx()
                val gap = 4.dp.toPx()
                for (i in 1..3) {
                    val d = pad + gap * i
                    drawLine(
                        color = color,
                        start = Offset(size.width - pad, size.height - d),
                        end = Offset(size.width - d, size.height - pad),
                        strokeWidth = stroke,
                        cap = StrokeCap.Round,
                    )
                }
            },
    )
}

/** Waktu berjalan, bilah progres, dan sisa waktu. Dipisah supaya detak posisi tidak merender ulang kartu. */
@Composable
private fun ProgressRow(vm: MainViewModel) {
    val player = vm.player
    var position by remember { mutableIntStateOf(0) }
    var seeking by remember { mutableStateOf(false) }
    LaunchedEffect(player.index) {
        while (true) {
            if (!seeking) position = player.positionMs()
            delay(300)
        }
    }
    val total = max(player.durationMs, 1)
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(formatMs(position), style = Classic.mono.copy(color = Classic.dim))
        SeekBar(
            fraction = position.coerceIn(0, total).toFloat() / total,
            onChange = { fraction ->
                seeking = true
                position = (fraction * total).toInt()
            },
            onFinish = {
                player.seekTo(position)
                seeking = false
            },
            modifier = Modifier.weight(1f),
        )
        Text("-" + formatMs(total - position), style = Classic.mono.copy(color = Classic.dim))
    }
}

/** Bilah progres biru dengan alur yang mengikuti tema. */
@Composable
private fun SeekBar(
    fraction: Float,
    onChange: (Float) -> Unit,
    onFinish: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var widthPx by remember { mutableFloatStateOf(1f) }
    val change by rememberUpdatedState(onChange)
    val finish by rememberUpdatedState(onFinish)
    val shape = RoundedCornerShape(5.dp)
    Box(
        modifier = modifier
            .height(26.dp)
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    change((offset.x / widthPx).coerceIn(0f, 1f))
                    finish()
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { offset -> change((offset.x / widthPx).coerceIn(0f, 1f)) },
                    onDragEnd = { finish() },
                    onDragCancel = { finish() },
                ) { pointer, _ ->
                    pointer.consume()
                    change((pointer.position.x / widthPx).coerceIn(0f, 1f))
                }
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(shape)
                .background(Classic.rowAlternate)
                .border(1.dp, Classic.border, shape),
        )
        Box(
            Modifier
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .height(10.dp)
                .clip(shape)
                .background(Classic.blueGloss),
        )
    }
}

// ------------------------------------------------------------------ Cover Flow

/** Nilai antara [near] dan [far] menurut jarak [distance] dari tengah (0, 1, 2, lalu 3). */
private fun byDistance(distance: Float, center: Float, near: Float, far: Float, beyond: Float): Float = when {
    distance <= 1f -> center + (near - center) * distance
    distance <= 2f -> near + (far - near) * (distance - 1f)
    else -> far + (beyond - far) * min(distance - 2f, 1f)
}

/**
 * Satu kartu carousel: sampul dan pantulan cerminnya digambar dalam satu lapisan. Pantulan dibuat
 * dengan membalik gambar lalu menimpanya dengan gradasi warna latar. Cara ini tidak memerlukan
 * lapisan offscreen, sehingga ringan saat digeser.
 */
@Composable
private fun CarouselCard(
    bitmap: ImageBitmap?,
    side: Dp,
    surface: Color,
    onClick: () -> Unit,
    modifier: Modifier,
) {
    val placeholder = Classic.rowAlternate
    val outline = Classic.border
    Box(modifier.size(side, side * (1f + REFLECTION_GAP + REFLECTION_FRACTION))) {
        Box(
            Modifier
                .fillMaxSize()
                .drawWithCache {
                    val width = size.width
                    val top = width * (1f + REFLECTION_GAP)
                    val shadeHeight = size.height - top
                    val fade = Brush.verticalGradient(
                        0f to surface.copy(alpha = 0.55f),
                        1f to surface,
                        startY = top,
                        endY = size.height,
                    )
                    val corner = CornerRadius(COVER_RADIUS.toPx())
                    val clip = Path().apply { addRoundRect(RoundRect(0f, 0f, width, width, corner)) }
                    val mirrorClip = Path().apply { addRoundRect(RoundRect(0f, top, width, size.height, corner)) }
                    val line = Stroke(1.dp.toPx())
                    // Potong bagian tengah gambar agar sampul tidak persegi tidak gepeng.
                    val crop = bitmap?.let { min(it.width, it.height) } ?: 0
                    val source = bitmap?.let { IntOffset((it.width - crop) / 2, (it.height - crop) / 2) } ?: IntOffset.Zero
                    val target = IntSize(width.roundToInt(), width.roundToInt())

                    fun DrawScope.face() {
                        if (bitmap != null) {
                            drawImage(
                                image = bitmap,
                                srcOffset = source,
                                srcSize = IntSize(crop, crop),
                                dstSize = target,
                                filterQuality = FilterQuality.Medium,
                            )
                        } else {
                            drawRect(placeholder, size = Size(width, width))
                        }
                    }

                    onDrawBehind {
                        clipPath(clip) { face() }
                        drawRoundRect(outline, size = Size(width, width), cornerRadius = corner, style = line)
                        clipPath(mirrorClip) {
                            // Dibalik terhadap garis di tengah celah antara sampul dan pantulan.
                            scale(scaleX = 1f, scaleY = -1f, pivot = Offset(width / 2f, (width + top) / 2f)) {
                                face()
                            }
                        }
                        drawRect(fade, topLeft = Offset(0f, top), size = Size(width, shadeHeight + 1f))
                    }
                },
        )
        // Area ketuk hanya pada sampul, bukan pantulannya.
        Box(Modifier.size(side).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
            if (bitmap == null) Text("♪", style = Classic.body.copy(color = Classic.dim, fontSize = 40.sp))
        }
    }
}

/**
 * Carousel sampul. Satu nilai [Animatable] `position` (dalam satuan indeks antrean) menggerakkan
 * semuanya: geser jari mengubahnya langsung, lepas jari menyelesaikannya ke sampul terdekat dengan
 * pegas lalu memutar lagu itu. Nilai hanya dibaca di fase gambar, jadi tidak ada komposisi ulang
 * tiap frame.
 */
@Composable
private fun CoverFlow(vm: MainViewModel, surface: Color, modifier: Modifier = Modifier) {
    val player = vm.player
    val queue = player.queue
    val scope = rememberCoroutineScope()
    val position = remember { Animatable(player.index.coerceAtLeast(0).toFloat()) }

    // Satu pegas dipakai untuk lepas jari dan pindah lagu otomatis, jadi geraknya seragam.
    val settleSpring = remember { spring<Float>(dampingRatio = 0.86f, stiffness = Spring.StiffnessMediumLow) }

    // Lagu berganti lewat tombol, selesai otomatis, atau antrean diacak: sampul ikut berpindah.
    LaunchedEffect(player.index, queue) {
        val target = player.index
        if (target < 0 || target >= queue.size || position.targetValue == target.toFloat()) return@LaunchedEffect
        val gap = target - position.value
        // Lompatan jauh: loncat sampai tinggal 2 sampul lagi, lalu animasikan sisanya.
        if (abs(gap) > 2f) position.snapTo(target - gap.sign * 2f)
        position.animateTo(target.toFloat(), settleSpring)
    }

    val last = max(queue.lastIndex, 0)
    val center by remember(last) { derivedStateOf { position.value.roundToInt().coerceIn(0, last) } }

    BoxWithConstraints(modifier.clipToBounds()) {
        // Sampul tengah sebesar mungkin sambil menyisakan tempat untuk pantulan dan tetangganya.
        val side = minOf(
            MAX_COVER_SIDE,
            (maxHeight - 4.dp) / (1f + REFLECTION_GAP + REFLECTION_FRACTION),
            maxWidth * 0.56f,
        ).coerceAtLeast(48.dp)
        val pagePx = with(LocalDensity.current) { side.toPx() * NEAR_OFFSET }

        Box(
            Modifier
                .fillMaxSize()
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        // UNDISPATCHED: posisi berubah pada frame yang sama dengan gerak jari.
                        scope.launch(start = CoroutineStart.UNDISPATCHED) {
                            position.snapTo((position.value - delta / pagePx).coerceIn(0f, last.toFloat()))
                        }
                    },
                    onDragStopped = { velocity ->
                        scope.launch {
                            val pagesPerSecond = (-velocity / pagePx).coerceIn(-12f, 12f)
                            val from = position.value
                            val base = from.roundToInt()
                            val target = (from + pagesPerSecond * 0.16f).roundToInt()
                                .coerceIn(base - 3, base + 3)
                                .coerceIn(0, last)
                            position.animateTo(target.toFloat(), settleSpring, initialVelocity = pagesPerSecond)
                            // Hanya tercapai bila geser tidak disela gestur baru.
                            if (target != player.index) player.playIndex(target)
                        }
                    },
                ),
            contentAlignment = Alignment.Center,
        ) {
            for (i in (center - VISIBLE_SIDE)..(center + VISIBLE_SIDE)) {
                val item = queue.getOrNull(i) ?: continue
                key(i, item.documentId) {
                    CarouselCard(
                        bitmap = rememberCover(vm, item),
                        side = side,
                        surface = surface,
                        onClick = { if (i != player.index) player.playIndex(i) },
                        modifier = Modifier
                            // Sampul yang lebih dekat ke tengah menutupi yang lebih jauh.
                            .zIndex(-abs(i - center).toFloat())
                            .graphicsLayer {
                                // p < 0: di kiri sampul aktif; p > 0: di kanan.
                                val p = i - position.value
                                val d = abs(p)
                                val factor = byDistance(d, 1f, NEAR_SCALE, FAR_SCALE, 0.5f)
                                scaleX = factor
                                scaleY = factor
                                translationX = sign(p) * byDistance(d, 0f, NEAR_OFFSET, FAR_OFFSET, 1.5f) * size.width
                                // Skala berpusat di tengah sampul, bukan di tengah sampul + pantulan.
                                transformOrigin = TransformOrigin(0.5f, 0.5f * size.width / size.height)
                                rotationY = p.coerceIn(-1f, 1f) * SIDE_TILT
                                cameraDistance = 14f * density
                                alpha = byDistance(d, 1f, NEAR_ALPHA, FAR_ALPHA, 0f)
                            },
                    )
                }
            }
        }
    }
}
