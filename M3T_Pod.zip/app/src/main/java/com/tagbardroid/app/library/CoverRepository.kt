// File: app/src/main/java/com/tagbardroid/app/library/CoverRepository.kt
package com.tagbardroid.app.library

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.tagbardroid.app.engine.TagAndReplayGainEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Thumbnail sampul dengan dua lapis cache:
 * 1. memori ([LruCache], dibatasi ukuran byte), supaya sampul langsung tampil saat digeser;
 * 2. disk (JPEG kecil di cacheDir), supaya file musik tidak dibaca ulang setelah aplikasi dibuka lagi.
 *
 * Semua pembacaan dan decode berjalan di luar thread UI, maksimal dua sekaligus, dan dibatalkan
 * bila sampulnya sudah tidak terlihat. Kunci cache memuat ukuran dan waktu ubah file, jadi sampul
 * yang baru diganti otomatis dimuat ulang.
 */
class CoverRepository(context: Context, private val engine: TagAndReplayGainEngine) {

    private val appContext = context.applicationContext
    private val directory = File(appContext.cacheDir, "covers")

    private val memory = object : LruCache<String, ImageBitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 10).toInt().coerceIn(8 * 1024, 48 * 1024),
    ) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = (value.width * value.height * 4 / 1024).coerceAtLeast(1)
    }

    /** Lagu yang sudah dipastikan tidak punya sampul (atau gagal dibaca) selama sesi ini. */
    private val missing: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val readGate = Semaphore(2)

    /** Pembacaan cadangan menyalin seluruh file, jadi dijalankan satu per satu. */
    private val copyGate = Semaphore(1)
    private var writes = 0

    fun key(track: LibraryTrack): String {
        val source = "${track.item.uri}|${track.item.sizeBytes}|${track.lastModified}"
        return MessageDigest.getInstance("SHA-1").digest(source.toByteArray())
            .joinToString("") { "%02x".format(it.toInt() and 0xFF) }
    }

    /** Warna dominan per cover (ARGB), supaya ekstraksi piksel hanya dilakukan sekali per cover. */
    private val dominant = ConcurrentHashMap<String, Int>()

    /**
     * Warna dominan cover untuk mode Dynamic Color: cover diperkecil ke ~32 px, piksel dikelompokkan
     * per rona, dan rona yang paling kuat (jenuh, tidak terlalu gelap/terang) dipilih. Cover abu-abu
     * menghasilkan abu-abu. Berjalan di luar thread UI.
     */
    suspend fun dominantColor(key: String, image: ImageBitmap): Int? {
        dominant[key]?.let { return it }
        return withContext(Dispatchers.Default) {
            val color = runCatching { extractDominant(image.asAndroidBitmap()) }.getOrNull()
            if (color != null) dominant[key] = color
            color
        }
    }

    private fun extractDominant(source: Bitmap): Int? {
        val largest = maxOf(source.width, source.height)
        if (largest <= 0) return null
        val scale = SEED_SAMPLE_SIZE.toFloat() / largest
        val width = (source.width * scale).toInt().coerceIn(1, SEED_SAMPLE_SIZE)
        val height = (source.height * scale).toInt().coerceIn(1, SEED_SAMPLE_SIZE)
        val small = if (scale < 1f) Bitmap.createScaledBitmap(source, width, height, true) else source
        val w = small.width
        val h = small.height
        val pixels = IntArray(w * h)
        small.getPixels(pixels, 0, w, 0, 0, w, h)
        if (small !== source) small.recycle()

        val bins = 24
        val weight = DoubleArray(bins)
        val hueSum = DoubleArray(bins)
        val satSum = DoubleArray(bins)
        val valSum = DoubleArray(bins)
        var brightness = 0.0
        var counted = 0
        val hsv = FloatArray(3)
        for (pixel in pixels) {
            if (android.graphics.Color.alpha(pixel) < 200) continue
            android.graphics.Color.colorToHSV(pixel, hsv)
            brightness += hsv[2]
            counted++
            if (hsv[2] < 0.15f) continue
            // Piksel jenuh dengan kecerahan sedang paling berpengaruh; hampir putih/abu bobotnya kecil.
            val w8 = (hsv[1] * hsv[1] + 0.02) * (1.0 - Math.abs(hsv[2] - 0.6) * 0.8)
            val bin = (hsv[0] / 360f * bins).toInt().coerceIn(0, bins - 1)
            weight[bin] += w8
            hueSum[bin] += hsv[0] * w8
            satSum[bin] += hsv[1] * w8
            valSum[bin] += hsv[2] * w8
        }
        if (counted == 0) return null
        var best = 0
        for (i in 1 until bins) if (weight[i] > weight[best]) best = i
        val gray = (brightness / counted).toFloat().coerceIn(0f, 1f)
        if (weight[best] <= 0.0) return android.graphics.Color.HSVToColor(floatArrayOf(0f, 0f, gray))
        val hue = (hueSum[best] / weight[best]).toFloat()
        val sat = (satSum[best] / weight[best]).toFloat()
        val value = (valSum[best] / weight[best]).toFloat()
        if (sat < 0.12f) return android.graphics.Color.HSVToColor(floatArrayOf(0f, 0f, gray))
        return android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, value))
    }

    /** Hanya melihat cache memori; aman dipanggil dari thread UI. */
    fun peek(key: String): ImageBitmap? = memory.get(key)

    suspend fun load(track: LibraryTrack, key: String): ImageBitmap? {
        memory.get(key)?.let { return it }
        if (key in missing) return null
        return withContext(Dispatchers.IO) {
            readGate.withPermit {
                ensureActive()
                memory.get(key) ?: try {
                    readThrough(track, key)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    missing.add(key)
                    null
                } catch (e: OutOfMemoryError) {
                    memory.evictAll()
                    null
                }
            }
        }
    }

    private suspend fun readThrough(track: LibraryTrack, key: String): ImageBitmap? {
        val file = File(directory, "$key.jpg")
        val none = File(directory, "$key.none")
        if (none.isFile) {
            missing.add(key)
            return null
        }
        if (file.isFile) {
            val cached = BitmapFactory.decodeFile(file.path)
            if (cached != null) return remember(key, cached)
            file.delete()
        }

        val attempt = runCatching { embeddedPicture(track) }
        var bytes = attempt.getOrNull()
        if (bytes == null) {
            if (track.item.extension.lowercase() in RETRIEVER_IS_ENOUGH) {
                // Gagal membaca (bukan sekadar tanpa sampul) tidak dicatat permanen di disk.
                attempt.getOrThrow()
            } else {
                // MediaMetadataRetriever tidak selalu membaca sampul FLAC, OGG, atau WAV.
                bytes = copyGate.withPermit {
                    engine.readMetadata(track.item, includeCover = true).coverArt
                }
            }
        }
        val bitmap = bytes?.let { decodeThumbnail(it) }
        directory.mkdirs()
        if (bitmap == null) {
            missing.add(key)
            runCatching { none.createNewFile() }
            return null
        }
        runCatching {
            val temp = File(directory, "$key.tmp")
            temp.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            if (!temp.renameTo(file)) temp.delete()
        }
        if (++writes % 40 == 1) trimDisk()
        return remember(key, bitmap)
    }

    private fun remember(key: String, bitmap: Bitmap): ImageBitmap {
        // Tekstur disiapkan sekarang, bukan pada frame pertama saat digambar.
        bitmap.prepareToDraw()
        val image = bitmap.asImageBitmap()
        memory.put(key, image)
        return image
    }

    private fun embeddedPicture(track: LibraryTrack): ByteArray? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(appContext, track.item.uri)
            retriever.embeddedPicture
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun decodeThumbnail(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val largest = maxOf(bounds.outWidth, bounds.outHeight)
        if (largest <= 0) return null
        val options = BitmapFactory.Options()
        var sample = 1
        while (largest / (sample * 2) >= THUMBNAIL_SIZE) sample *= 2
        options.inSampleSize = sample
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) ?: return null
        val size = maxOf(decoded.width, decoded.height)
        if (size <= THUMBNAIL_SIZE) return decoded
        val scaled = Bitmap.createScaledBitmap(
            decoded,
            (decoded.width * THUMBNAIL_SIZE / size).coerceAtLeast(1),
            (decoded.height * THUMBNAIL_SIZE / size).coerceAtLeast(1),
            true,
        )
        if (scaled !== decoded) decoded.recycle()
        return scaled
    }

    /** Menjaga cache disk tetap kecil: file terlama dihapus lebih dulu. */
    private fun trimDisk() {
        val files = directory.listFiles() ?: return
        var total = files.sumOf { it.length() }
        if (total <= DISK_LIMIT && files.size <= MAX_FILES) return
        var count = files.size
        for (old in files.sortedBy { it.lastModified() }) {
            if (total <= DISK_LIMIT * 3 / 4 && count <= MAX_FILES * 3 / 4) break
            val length = old.length()
            if (old.delete()) {
                total -= length
                count--
            }
        }
    }

    private companion object {
        const val THUMBNAIL_SIZE = 512
        const val SEED_SAMPLE_SIZE = 32
        const val DISK_LIMIT = 80L * 1024 * 1024
        const val MAX_FILES = 6000
        val RETRIEVER_IS_ENOUGH = setOf("mp3", "m4a", "mp4", "aac", "alac")
    }
}
