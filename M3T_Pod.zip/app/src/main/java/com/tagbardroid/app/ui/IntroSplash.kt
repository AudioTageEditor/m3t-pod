// File: app/src/main/java/com/tagbardroid/app/ui/IntroSplash.kt
package com.tagbardroid.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tagbardroid.app.R
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

private val SPLASH_TOP = Color(0xFF0B0B12)
private val SPLASH_BOTTOM = Color(0xFF1B0F1E)
private val SPLASH_PINK = Color(0xFFFA2D48)
private val SPLASH_ORANGE = Color(0xFFFF9F43)
private val SPLASH_DIM = Color(0xFF8E8E93)
private val TAG_FIELDS = listOf("Title", "Artist", "Album", "Year", "Genre", "Cover")

private const val MIN_SHOW_MS = 2400L
private const val MAX_SHOW_MS = 8000L

/**
 * Layar pembuka: ikon aplikasi, equalizer gelombang yang bergerak, dan deretan kolom tag yang
 * menyala satu per satu seolah file musik sedang disunting. Judul aplikasi dan nama developer
 * ada di bagian bawah. Tampil minimal ~2,4 dtk dan menunggu sampai [ready] (pemuatan awal
 * selesai), dengan batas ~8 dtk, lalu memudar ke layar utama.
 */
@Composable
fun IntroSplash(ready: Boolean, onFinished: () -> Unit) {
    val finished by rememberUpdatedState(onFinished)
    val isReady by rememberUpdatedState(ready)
    val appear = remember { Animatable(0f) }
    val scale = remember { Animatable(0.6f) }
    val exit = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { appear.animateTo(1f, tween(600)) }
            launch {
                scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
            }
        }
        var elapsed = 600L
        while (elapsed < MAX_SHOW_MS && !(isReady && elapsed >= MIN_SHOW_MS)) {
            delay(100)
            elapsed += 100
        }
        exit.animateTo(0f, tween(350, easing = FastOutSlowInEasing))
        finished()
    }

    val transition = rememberInfiniteTransition(label = "splash")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing)),
        label = "wave",
    )
    val cycle by transition.animateFloat(
        initialValue = 0f,
        targetValue = TAG_FIELDS.size.toFloat(),
        animationSpec = infiniteRepeatable(tween(TAG_FIELDS.size * 450, easing = LinearEasing)),
        label = "tags",
    )
    val activeField = cycle.toInt().coerceIn(0, TAG_FIELDS.lastIndex)
    val glow by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "glow",
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = exit.value }
            .background(Brush.verticalGradient(listOf(SPLASH_TOP, SPLASH_BOTTOM))),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = appear.value },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(1f))

            // Ikon adaptif (dua lapisan vektor) dengan cahaya berdenyut.
            Box(contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(190.dp)) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(SPLASH_PINK.copy(alpha = glow * 0.55f), Color.Transparent),
                        ),
                    )
                }
                Box(
                    Modifier
                        .size(112.dp)
                        .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
                        .clip(RoundedCornerShape(26.dp)),
                ) {
                    Image(painterResource(R.drawable.ic_launcher_background), null, Modifier.fillMaxSize())
                    Image(
                        painterResource(R.drawable.ic_launcher_foreground),
                        contentDescription = stringResource(R.string.app_name),
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            // Equalizer: tinggi batang bergerak mengikuti gelombang, paling tinggi di tengah.
            Canvas(Modifier.padding(horizontal = 40.dp).fillMaxWidth().height(56.dp)) {
                val bars = 29
                val gap = 5.dp.toPx()
                val barWidth = (size.width - gap * (bars - 1)) / bars
                for (i in 0 until bars) {
                    val center = 1f - abs(i - (bars - 1) / 2f) / ((bars - 1) / 2f)
                    val wave = abs(sin((phase * 2f * PI + i * 0.55).toFloat()))
                    val h = size.height * (0.12f + 0.88f * wave * (0.35f + 0.65f * center))
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            listOf(SPLASH_ORANGE, SPLASH_PINK),
                            startY = size.height - h,
                            endY = size.height,
                        ),
                        topLeft = Offset(i * (barWidth + gap), (size.height - h) / 2f),
                        size = Size(barWidth, h),
                        cornerRadius = CornerRadius(barWidth / 2f),
                    )
                }
            }

            Spacer(Modifier.height(22.dp))

            // Kolom tag yang menyala bergantian, seolah sedang ditulis ke file.
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TAG_FIELDS.forEachIndexed { index, name ->
                    val on = index == activeField
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (on) SPLASH_PINK else Color(0x22FFFFFF))
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                    ) {
                        Text(
                            name,
                            style = TextStyle(
                                color = if (on) Color.White else SPLASH_DIM,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                            ),
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Menyiapkan pustaka musik…", style = TextStyle(color = SPLASH_DIM, fontSize = 12.sp))

            Spacer(Modifier.weight(1f))

            // Bagian bawah: judul aplikasi dan nama developer.
            Column(
                modifier = Modifier.navigationBarsPadding().padding(bottom = 36.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    "M3T Pod",
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp,
                    ),
                )
                Spacer(Modifier.height(6.dp))
                Box(Modifier.width(36.dp).height(3.dp).clip(RoundedCornerShape(50)).background(SPLASH_PINK))
                Spacer(Modifier.height(8.dp))
                Text("Developer: S. GreArd", style = TextStyle(color = SPLASH_DIM, fontSize = 13.sp))
            }
        }
    }
}
