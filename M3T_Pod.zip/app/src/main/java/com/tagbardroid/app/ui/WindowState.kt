// File: app/src/main/java/com/tagbardroid/app/ui/WindowState.kt
package com.tagbardroid.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.max
import kotlin.math.min

// =====================================================================================
// GEOMETRI JENDELA (satuan piksel, relatif terhadap area desktop)
// =====================================================================================

data class WindowRect(val x: Float, val y: Float, val width: Float, val height: Float)

/** Tepi yang sedang ditarik saat mengubah ukuran. */
data class ResizeEdges(
    val left: Boolean = false,
    val top: Boolean = false,
    val right: Boolean = false,
    val bottom: Boolean = false,
)

object WindowGeometry {

    /** Menyesuaikan jendela agar ukurannya sah dan seluruhnya berada di dalam area. */
    fun fit(rect: WindowRect, areaWidth: Float, areaHeight: Float, minWidth: Float, minHeight: Float): WindowRect {
        val width = rect.width.coerceIn(min(minWidth, areaWidth), areaWidth)
        val height = rect.height.coerceIn(min(minHeight, areaHeight), areaHeight)
        return WindowRect(
            x = rect.x.coerceIn(0f, areaWidth - width),
            y = rect.y.coerceIn(0f, areaHeight - height),
            width = width,
            height = height,
        )
    }

    /** [rect] harus sudah melalui [fit]. */
    fun move(rect: WindowRect, dx: Float, dy: Float, areaWidth: Float, areaHeight: Float): WindowRect = rect.copy(
        x = (rect.x + dx).coerceIn(0f, max(0f, areaWidth - rect.width)),
        y = (rect.y + dy).coerceIn(0f, max(0f, areaHeight - rect.height)),
    )

    /** Menggeser hanya tepi yang ditarik; tepi seberangnya tetap di tempat. [rect] harus sudah melalui [fit]. */
    fun resize(
        rect: WindowRect,
        edges: ResizeEdges,
        dx: Float,
        dy: Float,
        areaWidth: Float,
        areaHeight: Float,
        minWidth: Float,
        minHeight: Float,
    ): WindowRect {
        val smallestWidth = min(minWidth, areaWidth)
        val smallestHeight = min(minHeight, areaHeight)
        var left = rect.x
        var top = rect.y
        var right = rect.x + rect.width
        var bottom = rect.y + rect.height
        // max/min menjaga rentang tetap sah walau ada selisih pembulatan angka pecahan.
        if (edges.left) left = (left + dx).coerceIn(0f, max(0f, right - smallestWidth))
        if (edges.right) right = (right + dx).coerceIn(min(left + smallestWidth, areaWidth), areaWidth)
        if (edges.top) top = (top + dy).coerceIn(0f, max(0f, bottom - smallestHeight))
        if (edges.bottom) bottom = (bottom + dy).coerceIn(min(top + smallestHeight, areaHeight), areaHeight)
        return WindowRect(left, top, right - left, bottom - top)
    }

    /** Posisi awal: berdampingan di layar lebar, bertumpuk berundak di layar tegak. */
    fun initial(second: Boolean, areaWidth: Float, areaHeight: Float): WindowRect =
        if (areaWidth > areaHeight) {
            val width = areaWidth * 0.49f
            WindowRect(if (second) areaWidth - width else 0f, areaHeight * 0.04f, width, areaHeight * 0.92f)
        } else {
            val width = areaWidth * 0.94f
            WindowRect(
                x = if (second) areaWidth - width else 0f,
                y = areaHeight * if (second) 0.46f else 0.03f,
                width = width,
                height = areaHeight * 0.52f,
            )
        }
}

// =====================================================================================
// STATUS JENDELA
// =====================================================================================

enum class PanelId(val title: String) {
    SOURCE("Sumber Lagu"),
    PLAYLIST("Susunan Playlist"),
}

class PanelWindow {
    /** false = panel menempel di ruang kerja; true = menjadi jendela terpisah. */
    var floating by mutableStateOf(false)
    var minimized by mutableStateOf(false)
    var maximized by mutableStateOf(false)

    // NaN = belum pernah diatur, pakai posisi awal. Dipisah per nilai supaya menggeser jendela
    // hanya memicu penataan posisi, tanpa menyusun ulang isinya.
    var x by mutableFloatStateOf(Float.NaN)
    var y by mutableFloatStateOf(Float.NaN)
    var width by mutableFloatStateOf(Float.NaN)
    var height by mutableFloatStateOf(Float.NaN)

    fun rectOr(fallback: WindowRect) = WindowRect(
        if (x.isNaN()) fallback.x else x,
        if (y.isNaN()) fallback.y else y,
        if (width.isNaN()) fallback.width else width,
        if (height.isNaN()) fallback.height else height,
    )

    fun set(rect: WindowRect) {
        x = rect.x
        y = rect.y
        width = rect.width
        height = rect.height
    }
}

/** Semua jendela floating beserta urutan tumpukannya. Disimpan di ViewModel agar bertahan antar tab. */
class DesktopState {
    private val windows = PanelId.entries.associateWith { PanelWindow() }

    /** Urutan tumpukan; yang terakhir berada paling depan. */
    var order by mutableStateOf(PanelId.entries.toList())
        private set

    fun window(id: PanelId): PanelWindow = windows.getValue(id)

    /** Jendela terdepan yang sedang terlihat. */
    val active: PanelId?
        get() = order.lastOrNull { window(it).floating && !window(it).minimized }

    fun bringToFront(id: PanelId) {
        if (order.last() != id) order = order - id + id
    }

    fun open(id: PanelId) {
        window(id).floating = true
        window(id).minimized = false
        bringToFront(id)
    }

    /** Menutup jendela: panelnya kembali menempel di ruang kerja. Posisi dan ukuran diingat. */
    fun close(id: PanelId) {
        window(id).floating = false
        window(id).minimized = false
        window(id).maximized = false
    }

    fun minimize(id: PanelId) {
        window(id).minimized = true
    }

    fun toggleMaximize(id: PanelId) {
        window(id).maximized = !window(id).maximized
        bringToFront(id)
    }

    /** Perilaku tombol di bilah tugas: tampilkan, bawa ke depan, atau kecilkan bila sudah di depan. */
    fun taskbarClick(id: PanelId) {
        when {
            window(id).minimized -> open(id)
            active == id -> minimize(id)
            else -> bringToFront(id)
        }
    }
}
